


import React, { useState, useEffect, useRef } from 'react';
import Sidebar from './components/Sidebar';
import Overview from './pages/Overview';
import Trends from './pages/Trends';
import FamilyConnect from './pages/FamilyConnect';
import Settings from './pages/Settings';
import LoginPage from './pages/LoginPage';
import VitalsScan from './pages/VitalsScan';
import AIChat from './pages/AIChat';
import Alerts from './pages/Alerts';
import AlertToast from './components/AlertToast';
import DoctorDashboard from './pages/DoctorDashboard';
import PatientDetailView from './pages/PatientDetailView';
import ConfirmationModal from './components/ConfirmationModal';
import PrivacyCurtain from './components/PrivacyCurtain';
import DoctorSidebar from './components/DoctorSidebar';
import Medication from './pages/Medication';
import LabReports from './pages/LabReports';
import VoiceAssistantButton from './components/VoiceAssistantButton';
import Analytics from './pages/Analytics';
import Appointments from './pages/Appointments';
import Prescriptions from './pages/Prescriptions';
import Gamification from './pages/Gamification';
import CaregiverSidebar from './components/CaregiverSidebar';
import CaregiverDashboard from './pages/CaregiverDashboard';
import SharedNotes from './pages/SharedNotes';


import type { Page, Patient } from './types';
import { LanguageProvider } from './contexts/LanguageContext';
import { SettingsProvider } from './contexts/SettingsContext';
import { AlertsProvider, useAlerts } from './contexts/AlertsContext';
import { UserProvider, useUser } from './contexts/UserContext';
import { patientDataService } from './services/patientDataService';
import { ThemeProvider } from './contexts/ThemeContext';

const useIdleTimer = (onIdle: () => void, onPrompt: () => void, idleTime: number, promptTime: number) => {
    const timeoutRef = useRef<number | null>(null);
    const promptTimeoutRef = useRef<number | null>(null);

    const resetTimer = () => {
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        if (promptTimeoutRef.current) clearTimeout(promptTimeoutRef.current);

        promptTimeoutRef.current = window.setTimeout(onPrompt, promptTime);
        timeoutRef.current = window.setTimeout(onIdle, idleTime);
    };

    useEffect(() => {
        const events = ['mousemove', 'mousedown', 'keypress', 'touchstart', 'scroll'];
        const eventListener = () => resetTimer();

        events.forEach(event => window.addEventListener(event, eventListener));
        resetTimer();

        return () => {
            if (timeoutRef.current) clearTimeout(timeoutRef.current);
            if (promptTimeoutRef.current) clearTimeout(promptTimeoutRef.current);
            events.forEach(event => window.removeEventListener(event, eventListener));
        };
    }, [onIdle, onPrompt, idleTime, promptTime]);

    return resetTimer;
};


const AppLoader = (): React.ReactNode => (
    <div className="bg-white dark:bg-slate-900 min-h-screen text-slate-700 dark:text-slate-200 font-sans flex items-center justify-center">
        <div className="absolute inset-0 z-[-1] h-full w-full bg-white dark:bg-slate-900 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] dark:bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:32px_32px]"></div>
        <div className="flex flex-col items-center space-y-4">
            <div className="relative h-20 w-20">
                <div className="absolute inset-0 rounded-full border-4 border-cyan-500/50"></div>
                <div className="absolute inset-0 rounded-full border-t-4 border-cyan-400 animate-spin"></div>
            </div>
            <p className="text-lg text-slate-600 dark:text-slate-300">Initializing LifeTrack...</p>
        </div>
    </div>
);


function PatientApp({ onLogout }: { onLogout: () => void }): React.ReactNode {
  const [activePage, setActivePage] = useState<Page>('overview');

  const renderPage = () => {
    switch (activePage) {
      case 'overview': return <Overview />;
      case 'trends': return <Trends />;
      case 'family': return <FamilyConnect />;
      case 'alerts': return <Alerts />;
      case 'vitalsScan': return <VitalsScan />;
      case 'aiChat': return <AIChat />;
      case 'medication': return <Medication />;
      case 'labReports': return <LabReports />;
      case 'achievements': return <Gamification />;
      case 'sharedNotes': return <SharedNotes />;
      case 'settings': return <Settings />;
      default: return <Overview />;
    }
  };

  return (
    <div className="flex">
        <Sidebar activePage={activePage} setActivePage={setActivePage} onLogout={onLogout} />
        <div className="flex-1 lg:pl-24 transition-all duration-300">
            <main className="p-4 sm:p-6 lg:p-8 pb-20">
                {renderPage()}
            </main>
        </div>
        <VoiceAssistantButton />
    </div>
  );
}

type DoctorPage = 'dashboard' | 'analytics' | 'appointments' | 'prescriptions' | 'settings';

function DoctorApp({ onLogout }: { onLogout: () => void }): React.ReactNode {
    const [activePage, setActivePage] = useState<DoctorPage>('dashboard');
    const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

    // If a patient is selected, show the detail view which takes over the whole screen
    if (selectedPatient) {
        return <PatientDetailView patient={selectedPatient} onBack={() => setSelectedPatient(null)} />;
    }

    const renderPage = () => {
        switch (activePage) {
          case 'dashboard': return <DoctorDashboard onSelectPatient={setSelectedPatient} />;
          case 'analytics': return <Analytics />;
          case 'appointments': return <Appointments />;
          case 'prescriptions': return <Prescriptions />;
          case 'settings': return <Settings />;
          default: return <DoctorDashboard onSelectPatient={setSelectedPatient} />;
        }
    };

    return (
        <div className="flex">
            <DoctorSidebar activePage={activePage} setActivePage={setActivePage} onLogout={onLogout} />
            <div className="flex-1 lg:pl-24 transition-all duration-300">
                <main className="p-4 sm:p-6 lg:p-8 pb-20">
                    {renderPage()}
                </main>
            </div>
        </div>
    );
}

type CaregiverPage = 'dashboard' | 'sharedNotes' | 'settings';

function CaregiverApp({ onLogout }: { onLogout: () => void }): React.ReactNode {
    const [activePage, setActivePage] = useState<CaregiverPage>('dashboard');
    const [allPatients, setAllPatients] = useState(() => patientDataService.getPatients());
    
    const MONITORED_PATIENT_IDS = ['patient-john-doe', 'patient-sarah-doe'];
    const monitoredPatients = allPatients.filter(p => MONITORED_PATIENT_IDS.includes(p.id));

    const [activePatientId, setActivePatientId] = useState<string>(monitoredPatients.length > 0 ? monitoredPatients[0].id : '');
    
    useEffect(() => {
        const unsubscribe = patientDataService.subscribe(updatedPatients => {
            setAllPatients([...updatedPatients]);
        });
        return unsubscribe;
    }, []);

    const activePatient = allPatients.find(p => p.id === activePatientId);

    const renderPage = () => {
        if (!activePatient) {
            return <div className="text-center p-10 text-slate-600 dark:text-slate-300">Select a patient to monitor.</div>;
        }
        
        switch (activePage) {
            case 'dashboard': return <CaregiverDashboard patient={activePatient} />;
            case 'sharedNotes': return <SharedNotes patient={activePatient} />;
            case 'settings': return <Settings />;
            default: return <CaregiverDashboard patient={activePatient} />;
        }
    };
    
    return (
        <div className="flex">
            <CaregiverSidebar activePage={activePage} setActivePage={setActivePage} onLogout={onLogout} />
            <div className="flex-1 lg:pl-24 transition-all duration-300">
                <header className="p-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-slate-700/50 bg-white/80 dark:bg-slate-800/20 backdrop-blur-sm">
                    <div className="flex items-center justify-between">
                        <h2 className="text-xl font-bold text-slate-800 dark:text-white hidden sm:block">
                            Monitoring: <span className="text-cyan-500 dark:text-cyan-400">{activePatient?.name}</span>
                        </h2>
                        <div>
                            <label htmlFor="patient-switcher" className="sr-only">Switch Patient</label>
                            <select
                                id="patient-switcher"
                                value={activePatientId}
                                onChange={e => setActivePatientId(e.target.value)}
                                className="bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 text-sm"
                            >
                                {monitoredPatients.map(p => (
                                    <option key={p.id} value={p.id}>{p.name}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                </header>
                <main className="p-4 sm:p-6 lg:p-8 pb-20">
                    {renderPage()}
                </main>
            </div>
        </div>
    );
}


function LifeTrackApp(): React.ReactNode {
  const { user, logout } = useUser();
  const [isLoaded, setIsLoaded] = useState(false);
  const { confirmation } = useAlerts();
  const [isPrivacyCurtainVisible, setPrivacyCurtainVisible] = useState(false);

  useEffect(() => {
    // Simulate loading assets, fonts, etc.
    setTimeout(() => setIsLoaded(true), 1000);
  }, []);

  const handleIdle = () => {
    if (user) {
      logout();
    }
  };

  const showPrivacyCurtain = () => {
    if (user) {
      setPrivacyCurtainVisible(true);
    }
  };

  const resetIdleTimer = useIdleTimer(
    handleIdle, 
    showPrivacyCurtain, 
    5 * 60 * 1000, // 5 minutes to logout
    1 * 60 * 1000  // 1 minute to privacy screen
  );

  const handleResume = () => {
    setPrivacyCurtainVisible(false);
    resetIdleTimer();
  }

  useEffect(() => {
    if (user) {
        // Request permissions on login
        navigator.mediaDevices.getUserMedia({ video: true, audio: true })
            .then(stream => stream.getTracks().forEach(track => track.stop()))
            .catch(err => console.error('Camera/mic access denied.', err));
        navigator.geolocation.getCurrentPosition(
            () => console.log('Location access granted.'),
            (err) => console.error('Location access denied.', err)
        );
    }
  }, [user]);

  if (!isLoaded) {
    return <AppLoader />;
  }

  return (
    <div className="bg-slate-100 dark:bg-slate-900 min-h-screen text-slate-800 dark:text-slate-200 font-sans">
      <div className="absolute inset-0 z-[-1] h-full w-full bg-slate-100 dark:bg-slate-900 dark:bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:32px_32px]"></div>
      
      {!user ? (
        <LoginPage />
      ) : (
        <>
            {user.role === 'Patient' && <PatientApp onLogout={logout} />}
            {user.role === 'Doctor' && <DoctorApp onLogout={logout} />}
            {user.role === 'Caregiver' && <CaregiverApp onLogout={logout} />}
        </>
      )}

      <AlertToast />
      {confirmation.isOpen && <ConfirmationModal />}
      {isPrivacyCurtainVisible && <PrivacyCurtain onResume={handleResume} />}

      <footer className="fixed bottom-0 left-0 right-0 text-center p-2 text-xs text-slate-500 dark:text-slate-500 bg-slate-100/50 dark:bg-slate-900/50 backdrop-blur-sm">
        <p>LifeTrack © 2024. All vitals are simulated. This is not for medical use.</p>
      </footer>
    </div>
  );
}

function App(): React.ReactNode {
  return (
    <LanguageProvider>
      <UserProvider>
        <SettingsProvider>
          <AlertsProvider>
            <ThemeProvider>
                <LifeTrackApp />
            </ThemeProvider>
          </AlertsProvider>
        </SettingsProvider>
      </UserProvider>
    </LanguageProvider>
  );
}

export default App;