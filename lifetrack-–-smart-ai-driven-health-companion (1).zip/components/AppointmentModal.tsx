

import React, { useState } from 'react';
import { Patient, Appointment } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { patientDataService } from '../services/patientDataService';


interface AppointmentModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (appointment: Omit<Appointment, 'id' | 'patientName' | 'status'>) => void;
    patient?: Patient; // Optional: if scheduling from patient detail
}

const AppointmentModal = ({ isOpen, onClose, onSave, patient }: AppointmentModalProps) => {
    const { t } = useLanguage();
    const allPatients = patientDataService.getPatients();
    
    // Pre-select patient if provided, otherwise default to first patient or empty
    const [patientId, setPatientId] = useState(patient?.id || (allPatients.length > 0 ? allPatients[0].id : ''));
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [reason, setReason] = useState('');
    const [error, setError] = useState('');

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!patientId || !date || !reason.trim()) {
            setError('All fields are required.');
            return;
        }
        onSave({ patientId, date: new Date(date), reason });
        // Reset form
        if (!patient) setPatientId(allPatients.length > 0 ? allPatients[0].id : '');
        setDate(new Date().toISOString().split('T')[0]);
        setReason('');
        setError('');
    };
    
    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-6 w-full max-w-md border border-slate-300 dark:border-slate-700 animate-fadeInUp" onClick={(e) => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-4">{t('doctor.appointments.modal.title')}</h3>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="patient-select" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('doctor.appointments.modal.patientLabel')}</label>
                            <select
                                id="patient-select"
                                value={patientId}
                                onChange={(e) => setPatientId(e.target.value)}
                                disabled={!!patient}
                                className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm disabled:bg-slate-100 dark:disabled:bg-slate-900 disabled:text-slate-500 dark:disabled:text-slate-400"
                            >
                                {allPatients.map(p => (
                                    <option key={p.id} value={p.id}>{p.name}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="appointment-date" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('doctor.appointments.modal.dateLabel')}</label>
                            <input
                                type="date" id="appointment-date" value={date} onChange={(e) => setDate(e.target.value)}
                                className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                            />
                        </div>
                         <div>
                            <label htmlFor="reason" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('doctor.appointments.modal.reasonLabel')}</label>
                            <input
                                type="text" id="reason" value={reason} onChange={(e) => setReason(e.target.value)}
                                className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                                placeholder={t('doctor.appointments.modal.reasonPlaceholder')}
                            />
                        </div>
                        {error && <p className="text-red-500 dark:text-red-400 text-sm text-center">{error}</p>}
                    </div>
                     <div className="mt-6 flex justify-end space-x-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-white rounded-md hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors">
                            {t('common.cancel')}
                        </button>
                        <button type="submit" className="px-4 py-2 text-sm font-medium bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors">
                            {t('doctor.appointments.modal.schedule')}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AppointmentModal;