import React, { useState, useEffect, useRef } from 'react';
import { chatService } from '../services/geminiService';
import { useVitalsData } from '../hooks/useVitalsData';
import { useLanguage } from '../contexts/LanguageContext';
import { marked } from 'marked';

interface Message {
    sender: 'user' | 'ai';
    text: string;
}

const PageHeader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-4 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{t('aiChat.header')}</h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">{t('aiChat.subHeader')}</p>
        </div>
    </div>
);

const UserMessage = ({ text }: { text: string }) => (
    <div className="flex justify-end mb-4">
        <div className="mr-2 py-3 px-4 bg-cyan-500 rounded-2xl text-white max-w-lg">
            {text}
        </div>
    </div>
);

const AiMessage = ({ text }: { text: string }) => {
     // Basic markdown parsing for bold and lists
    const htmlText = marked.parse(text);
    return (
     <div className="flex justify-start mb-4">
        <div className="ml-2 py-3 px-4 bg-slate-200 dark:bg-slate-700 rounded-2xl text-slate-700 dark:text-slate-200 max-w-lg">
           <div className="prose prose-sm dark:prose-invert" dangerouslySetInnerHTML={{ __html: htmlText }} />
        </div>
    </div>
)};

const TypingIndicator = () => (
    <div className="flex justify-start mb-4">
        <div className="ml-2 py-3 px-4 bg-slate-200 dark:bg-slate-700 rounded-2xl">
            <div className="flex items-center space-x-1">
                <span className="w-2 h-2 bg-slate-400 dark:bg-slate-400 rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                <span className="w-2 h-2 bg-slate-400 dark:bg-slate-400 rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                <span className="w-2 h-2 bg-slate-400 dark:bg-slate-400 rounded-full animate-pulse"></span>
            </div>
        </div>
    </div>
)


const AIChat = (): React.ReactNode => {
    const { latestVitals } = useVitalsData();
    const [messages, setMessages] = useState<Message[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const { t } = useLanguage();

    useEffect(() => {
        chatService.startChatSession(latestVitals);
        setMessages([{
            sender: 'ai',
            text: t('aiChat.initialMessage')
        }]);
    }, [latestVitals, t]);

     useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, isLoading]);

    const handleSendMessage = async (e?: React.FormEvent, prompt?: string) => {
        e?.preventDefault();
        const text = prompt || userInput;
        if (!text.trim() || isLoading) return;

        const newUserMessage: Message = { sender: 'user', text };
        setMessages(prev => [...prev, newUserMessage]);
        setUserInput('');
        setIsLoading(true);
        setError('');

        try {
            const stream = await chatService.sendMessageStream(text);
            let aiResponse = '';
            // Add an empty AI message to the list, which we'll update with streaming content
            setMessages(prev => [...prev, { sender: 'ai', text: '' }]); 
            
            for await (const chunk of stream) {
                aiResponse += chunk.text;
                // Update the last message in the array with the new chunk
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1].text = aiResponse;
                    return newMessages;
                });
            }
        } catch (err) {
            console.error("Error sending message:", err);
            const errorMessage = { sender: 'ai' as const, text: t('aiChat.error') };
            // Replace the empty AI message with the error message
            setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = errorMessage;
                return newMessages;
            });
            setError(t('aiChat.error'));
        } finally {
            setIsLoading(false);
        }
    };
    
    const suggestionPrompts = [
        t('aiChat.suggestions.s1'),
        t('aiChat.suggestions.s2'),
        t('aiChat.suggestions.s3')
    ]

    return (
        <div className="flex flex-col h-[calc(100vh-120px)]">
            <PageHeader t={t} />
            <div className="flex-grow bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg p-4 overflow-y-auto">
                {messages.map((msg, index) =>
                    msg.sender === 'user' ? <UserMessage key={index} text={msg.text} /> : <AiMessage key={index} text={msg.text} />
                )}
                 {isLoading && messages[messages.length - 1]?.sender === 'user' && <TypingIndicator />}
                 {error && !isLoading && <div className="text-red-500 dark:text-red-400 text-center text-sm">{error}</div>}
                 <div ref={messagesEndRef} />
            </div>

             {messages.length <= 1 && (
                <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-2 animate-fadeInUp animation-delay-200">
                    {suggestionPrompts.map(prompt => (
                        <button key={prompt} onClick={() => handleSendMessage(undefined, prompt)} className="p-3 bg-slate-200 dark:bg-slate-700/80 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors text-left">
                            {prompt}
                        </button>
                    ))}
                </div>
            )}
            
            <div className="mt-4">
                <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
                    <input
                        type="text"
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        placeholder={t('aiChat.placeholder')}
                        className="flex-grow bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg shadow-sm py-3 px-4 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !userInput.trim()}
                        className="bg-cyan-500 text-white font-bold p-3 rounded-lg hover:bg-cyan-600 transition-colors duration-300 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed flex items-center justify-center"
                        aria-label={t('aiChat.send')}
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.428A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
                    </button>
                </form>
            </div>
        </div>
    );
};

export default AIChat;