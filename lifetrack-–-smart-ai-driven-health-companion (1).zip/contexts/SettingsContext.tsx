
import React, { createContext, useState, useContext, useMemo } from 'react';

interface Settings {
  heartRateThreshold: number;
  spo2Threshold: number;
  smsAlerts: boolean;
  emailAlerts: boolean;
  setHeartRateThreshold: (value: number) => void;
  setSpo2Threshold: (value: number) => void;
  setSmsAlerts: (value: boolean) => void;
  setEmailAlerts: (value: boolean) => void;
}

const SettingsContext = createContext<Settings | undefined>(undefined);

export const SettingsProvider = ({ children }: { children: React.ReactNode }) => {
  const [heartRateThreshold, setHeartRateThreshold] = useState(100);
  const [spo2Threshold, setSpo2Threshold] = useState(92);
  const [smsAlerts, setSmsAlerts] = useState(true);
  const [emailAlerts, setEmailAlerts] = useState(true);

  const value = useMemo(() => ({
    heartRateThreshold,
    spo2Threshold,
    smsAlerts,
    emailAlerts,
    setHeartRateThreshold,
    setSpo2Threshold,
    setSmsAlerts,
    setEmailAlerts,
  }), [heartRateThreshold, spo2Threshold, smsAlerts, emailAlerts]);

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = (): Settings => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
