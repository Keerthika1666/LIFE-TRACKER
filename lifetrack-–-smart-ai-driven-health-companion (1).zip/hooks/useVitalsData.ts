
import { useState, useEffect } from 'react';
import { VitalData } from '../types';
import { generateNewVitals } from '../data/mockData';

const MAX_HISTORY = 30; // Keep the last 30 data points
const UPDATE_INTERVAL = 3000; // Update every 3 seconds

// A simple in-memory cache to keep vitals data consistent for different patients in the doctor's view
const patientDataCache: { [key: string]: { history: VitalData[], latest: VitalData } } = {};

export const useVitalsData = (patientId: string = 'patient-john-doe') => {
  const getInitialState = () => {
    if (patientDataCache[patientId]) {
      return patientDataCache[patientId];
    }
    const initialData = generateNewVitals();
    patientDataCache[patientId] = { history: [initialData], latest: initialData };
    return patientDataCache[patientId];
  };

  const [vitalsHistory, setVitalsHistory] = useState<VitalData[]>(getInitialState().history);
  const [latestVitals, setLatestVitals] = useState<VitalData | null>(getInitialState().latest);

  useEffect(() => {
    const updateVitalsForPatient = () => {
      const newVitalData = generateNewVitals();
      
      setLatestVitals(newVitalData);
      setVitalsHistory((prevHistory) => {
        const newHistory = [...prevHistory, newVitalData];
        const slicedHistory = newHistory.length > MAX_HISTORY ? newHistory.slice(1) : newHistory;
        
        // Update cache
        patientDataCache[patientId] = {
            history: slicedHistory,
            latest: newVitalData,
        };

        return slicedHistory;
      });
    };

    // Set initial state from cache or generate new
    const initialState = getInitialState();
    setVitalsHistory(initialState.history);
    setLatestVitals(initialState.latest);

    const intervalId = setInterval(updateVitalsForPatient, UPDATE_INTERVAL);

    return () => clearInterval(intervalId);
  }, [patientId]);

  return { vitalsHistory, latestVitals };
};
