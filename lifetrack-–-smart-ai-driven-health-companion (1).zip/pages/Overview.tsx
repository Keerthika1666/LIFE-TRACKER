

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useVitalsData } from '../hooks/useVitalsData';
import { getHealthPrediction } from '../services/geminiService';
import { Prediction, VitalData, RiskLevel, Alert, AlertType } from '../types';
import VitalsCard from '../components/VitalsCard';
import VitalsChart from '../components/VitalsChart';
import LifestyleCard from '../components/LifestyleCard';
import HealthTipCard from '../components/HealthTipCard';
import { ICONS } from '../constants';
import { useLanguage } from '../contexts/LanguageContext';
import { useSettings } from '../contexts/SettingsContext';
import { useAlerts } from '../contexts/AlertsContext';
import { useUser } from '../contexts/UserContext';

const riskStyles = {
  [RiskLevel.Low]: {
    card: 'border-green-500',
    glow: 'shadow-[0_0_20px_theme(colors.glow-green)]',
    text: 'text-green-500 dark:text-green-400',
  },
  [RiskLevel.Medium]: {
    card: 'border-yellow-500',
    glow: 'shadow-[0_0_20px_theme(colors.glow-yellow)] animate-pulse',
    text: 'text-yellow-500 dark:text-yellow-400',
  },
  [RiskLevel.High]: {
    card: 'border-red-500',
    glow: 'shadow-[0_0_30px_theme(colors.glow-red)] animate-pulse',
    text: 'text-red-500 dark:text-red-400',
  },
  [RiskLevel.Unknown]: {
    card: 'border-slate-500',
    glow: '',
    text: 'text-slate-500 dark:text-slate-400',
  },
};

const AnalyzingLoader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex flex-col items-center justify-center space-y-3">
        <div className="relative h-16 w-16">
            <div className="absolute inset-0 rounded-full border-2 border-cyan-500/50"></div>
            <div className="absolute inset-0 rounded-full border-t-2 border-cyan-400 animate-spin"></div>
        </div>
        <p className="text-slate-500 dark:text-slate-400">{t('overview.aiCompanion.analyzing')}</p>
    </div>
)

const AIPredictionCard = ({ prediction, isLoading, t }: { prediction: Prediction, isLoading: boolean, t: (key: string, options?: any) => string }): React.ReactNode => {
  const styles = riskStyles[prediction.riskLevel];
  return (
    <div className={`bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg p-6 shadow-lg border-l-4 transition-all duration-500 h-full ${styles.card} ${!isLoading && styles.glow}`}>
      <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-3">{t('overview.aiCompanion.title')}</h3>
      {isLoading ? (
        <AnalyzingLoader t={t} />
      ) : (
        <>
          <p className={`text-3xl font-bold ${styles.text}`}>{t('overview.aiCompanion.risk', { riskLevel: prediction.riskLevel })}</p>
          <p className="text-slate-600 dark:text-slate-300 mt-2 min-h-[40px]">{prediction.prediction}</p>
        </>
      )}
    </div>
  );
};

const SOSButton = ({ onSOS, t }: { onSOS: () => void, t: (key: string) => string }): React.ReactNode => (
  <button 
    onClick={onSOS}
    className="group w-full h-full bg-red-600/90 dark:bg-red-600/80 backdrop-blur-sm rounded-lg shadow-lg text-white flex flex-col items-center justify-center transition-all duration-300 hover:bg-red-600 hover:shadow-[0_0_30px_theme(colors.glow-red)] active:scale-95 animate-pulse-slow"
  >
    <div className="relative">
      <div className="absolute -inset-2 rounded-full bg-white/20 blur-lg animate-pulse opacity-0 group-hover:opacity-100 transition-opacity"></div>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mb-2 transition-transform duration-300 group-hover:scale-110" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    </div>
    <span className="text-2xl font-bold tracking-wider">{t('overview.sos.title')}</span>
    <span className="text-sm opacity-80">{t('overview.sos.subTitle')}</span>
  </button>
);

const PageHeader = ({ user, t }: { user: any, t: (key: string, options?: any) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{t('overview.header')}</h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">{t('overview.subHeader', { patientName: user.name })}</p>
        </div>
        <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-slate-600 dark:text-slate-300 hidden sm:block">{t('overview.patientLabel', { patientName: user.name })}</span>
            <img
            className="w-12 h-12 rounded-full border-2 border-cyan-500 object-cover"
            src={user.avatarUrl}
            alt="Patient profile"
            />
        </div>
    </div>
)

const RATE_LIMIT_MESSAGE = 'AI analysis is temporarily paused due to high request volume. It will resume shortly.';
const PREDICTION_INTERVAL = 30000; // 30 seconds
const API_COOLDOWN_PERIOD = 60000; // 60 seconds
const ABNORMAL_VITAL_COUNT_THRESHOLD = 3; // require 3 consecutive abnormal readings

const Overview = (): React.ReactNode => {
  const { user } = useUser();
  const { vitalsHistory, latestVitals } = useVitalsData(user?.id);
  const [prediction, setPrediction] = useState<Prediction>({ riskLevel: RiskLevel.Unknown, prediction: 'Awaiting vitals data...' });
  const [isLoadingPrediction, setIsLoadingPrediction] = useState(true);
  const { t } = useLanguage();
  const { heartRateThreshold, spo2Threshold } = useSettings();
  const { initiateSOS } = useAlerts();

  const latestVitalsRef = useRef<VitalData | null>(null);
  const abnormalCountsRef = useRef<Record<keyof Omit<VitalData, 'time' | 'systolicBP' | 'diastolicBP'>, number>>({
      heartRate: 0, spo2: 0, temperature: 0
  });

  const isApiCoolingDown = useRef(false);
  
  // Alert Generation Logic with confirmation
  const checkVitalsForAlerts = useCallback((vitals: VitalData) => {
    let triggered = false;

    // High Heart Rate
    if (vitals.heartRate > heartRateThreshold) {
      abnormalCountsRef.current.heartRate++;
    } else {
      abnormalCountsRef.current.heartRate = 0;
    }
    if (abnormalCountsRef.current.heartRate === ABNORMAL_VITAL_COUNT_THRESHOLD) {
        initiateSOS(t('sos.reasons.hr', { value: vitals.heartRate }));
        triggered = true;
    }

    // Low SpO2
    if (vitals.spo2 < spo2Threshold) {
      abnormalCountsRef.current.spo2++;
    } else {
      abnormalCountsRef.current.spo2 = 0;
    }
    if (abnormalCountsRef.current.spo2 === ABNORMAL_VITAL_COUNT_THRESHOLD && !triggered) {
      initiateSOS(t('sos.reasons.spo2', { value: vitals.spo2 }));
    }
    
    // reset count after triggering to prevent re-triggering
    if (triggered) {
        abnormalCountsRef.current.heartRate = 0;
        abnormalCountsRef.current.spo2 = 0;
    }

  }, [initiateSOS, heartRateThreshold, spo2Threshold, t]);

  useEffect(() => {
    if (latestVitals) {
        latestVitalsRef.current = latestVitals;
        checkVitalsForAlerts(latestVitals);
    }
  }, [latestVitals, checkVitalsForAlerts]);

  // AI Prediction Logic
  useEffect(() => {
    const fetchPrediction = async () => {
      if (isApiCoolingDown.current || !latestVitalsRef.current) return;

      setIsLoadingPrediction(true);
      const result = await getHealthPrediction(latestVitalsRef.current);
      
      if (result.prediction === RATE_LIMIT_MESSAGE) {
        if (!isApiCoolingDown.current) {
          isApiCoolingDown.current = true;
          setPrediction(result);
          setTimeout(() => { isApiCoolingDown.current = false; fetchPrediction(); }, API_COOLDOWN_PERIOD);
        }
      } else {
        setPrediction(result);
      }
      setIsLoadingPrediction(false);
    };

    fetchPrediction(); // Fetch immediately on mount
    const intervalId = setInterval(fetchPrediction, PREDICTION_INTERVAL);
    return () => clearInterval(intervalId);
  }, []);

  if (!latestVitals || !user) {
    return (
        <div className="flex items-center justify-center h-[80vh]">
            <div className="flex flex-col items-center space-y-4">
                <div className="relative h-20 w-20">
                    <div className="absolute inset-0 rounded-full border-4 border-cyan-500/50"></div>
                    <div className="absolute inset-0 rounded-full border-t-4 border-cyan-400 animate-spin"></div>
                </div>
                <p className="text-lg text-slate-600 dark:text-slate-300">{t('overview.loading')}</p>
            </div>
        </div>
    );
  }

  return (
    <>
      <PageHeader user={user} t={t} />
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Vitals Cards: Full Width */}
        <div className="lg:col-span-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          <div className="animate-fadeInUp animation-delay-100"><VitalsCard label={t('overview.vitals.heartRate')} vitalKey="heartRate" value={latestVitals.heartRate} unit={t('overview.units.bpm')} icon={ICONS.heartRate} /></div>
          <div className="animate-fadeInUp animation-delay-200"><VitalsCard label={t('overview.vitals.spo2')} vitalKey="spo2" value={latestVitals.spo2} unit={t('overview.units.percent')} icon={ICONS.spo2} /></div>
          <div className="animate-fadeInUp animation-delay-300"><VitalsCard label={t('overview.vitals.bloodPressure')} vitalKey="bloodPressure" value={`${latestVitals.systolicBP}/${latestVitals.diastolicBP}`} unit={t('overview.units.mmhg')} icon={ICONS.bloodPressure} /></div>
          <div className="animate-fadeInUp animation-delay-400"><VitalsCard label={t('overview.vitals.temperature')} vitalKey="temperature" value={latestVitals.temperature} unit={t('overview.units.celsius')} icon={ICONS.temperature} /></div>
        </div>

        {/* AI Prediction: Half Width */}
        <div className="lg:col-span-2 animate-fadeInUp animation-delay-200">
            <AIPredictionCard prediction={prediction} isLoading={isLoadingPrediction && !isApiCoolingDown.current} t={t} />
        </div>
        
        {/* Lifestyle Tracker: Half Width */}
        <div className="lg:col-span-2 animate-fadeInUp animation-delay-300">
            <LifestyleCard />
        </div>

        {/* Mini Charts & Action Cards: Full Width */}
        <div className="lg:col-span-4 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="animate-fadeInUp animation-delay-400 bg-white dark:bg-slate-800/50 backdrop-blur-sm p-4 rounded-lg shadow-lg h-64">
                <VitalsChart type="single" vitalKey="heartRate" data={vitalsHistory} title={t('overview.vitals.heartRate')} latestValue={latestVitals.heartRate} unit={t('overview.units.bpm')} threshold={heartRateThreshold} />
            </div>
             <div className="animate-fadeInUp animation-delay-500 bg-white dark:bg-slate-800/50 backdrop-blur-sm p-4 rounded-lg shadow-lg h-64">
                <VitalsChart type="single" vitalKey="spo2" data={vitalsHistory} title={t('overview.vitals.spo2')} latestValue={latestVitals.spo2} unit={t('overview.units.percent')} threshold={spo2Threshold} />
            </div>
            <div className="animate-fadeInUp animation-delay-600 h-64 md:h-auto md:row-span-2 space-y-6">
                <div className="h-40"><SOSButton onSOS={() => initiateSOS(t('sos.reasons.manual'))} t={t} /></div>
                <HealthTipCard />
            </div>
             <div className="animate-fadeInUp animation-delay-500 md:col-span-2 bg-white dark:bg-slate-800/50 backdrop-blur-sm p-4 rounded-lg shadow-lg h-64">
                <VitalsChart type="single" vitalKey="temperature" data={vitalsHistory} title={t('overview.vitals.temperature')} latestValue={latestVitals.temperature} unit={t('overview.units.celsius')} threshold={37.5} />
            </div>
        </div>

      </div>
    </>
  );
};

export default Overview;