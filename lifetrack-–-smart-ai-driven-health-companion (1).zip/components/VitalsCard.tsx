

import React from 'react';
import { useSettings } from '../contexts/SettingsContext';
import { useLanguage } from '../contexts/LanguageContext';

type VitalKey = 'heartRate' | 'spo2' | 'bloodPressure' | 'temperature';
type Status = 'normal' | 'warning' | 'danger';
type StatusDetails = {
    status: Status;
    labelKey: string;
    percentage: number;
};


interface VitalsCardProps {
  label: string;
  value: string | number;
  unit: string;
  icon: React.ReactNode;
  vitalKey: VitalKey;
}

const statusClasses: Record<Status, { border: string, bg: string, text: string, anim: string, gauge: string }> = {
    normal: {
        border: 'border-green-500',
        bg: 'bg-green-500/10',
        text: 'text-green-500 dark:text-green-400',
        anim: '',
        gauge: 'bg-green-500',
    },
    warning: {
        border: 'border-yellow-500',
        bg: 'bg-yellow-500/10',
        text: 'text-yellow-500 dark:text-yellow-400',
        anim: 'animate-pulse-glow-yellow',
        gauge: 'bg-yellow-500',
    },
    danger: {
        border: 'border-red-500',
        bg: 'bg-red-500/10',
        text: 'text-red-500 dark:text-red-400',
        anim: 'animate-pulse-glow-red',
        gauge: 'bg-red-500',
    }
};

const VitalsCard = ({ label, value, unit, icon, vitalKey }: VitalsCardProps): React.ReactNode => {
    const { heartRateThreshold, spo2Threshold } = useSettings();
    const { t } = useLanguage();
    
    const getStatusDetails = (): StatusDetails => {
        const numValue = typeof value === 'string' ? parseFloat(value.split('/')[0]) : value;
        if (isNaN(numValue)) return { status: 'normal', labelKey: 'vitals.status.normal', percentage: 50 };

        switch (vitalKey) {
            case 'heartRate':
                if (numValue > heartRateThreshold + 15 || numValue < 40) return { status: 'danger', labelKey: 'vitals.status.veryHigh', percentage: 100 };
                if (numValue > heartRateThreshold) return { status: 'warning', labelKey: 'vitals.status.high', percentage: 75 };
                if (numValue < 50) return { status: 'warning', labelKey: 'vitals.status.low', percentage: 25 };
                return { status: 'normal', labelKey: 'vitals.status.normal', percentage: 50 };
            case 'spo2':
                if (numValue < spo2Threshold - 3) return { status: 'danger', labelKey: 'vitals.status.veryLow', percentage: 0 };
                if (numValue < spo2Threshold) return { status: 'warning', labelKey: 'vitals.status.low', percentage: 25 };
                return { status: 'normal', labelKey: 'vitals.status.normal', percentage: 100 };
            case 'bloodPressure':
                 if (numValue > 140) return { status: 'danger', labelKey: 'vitals.status.high', percentage: 100 };
                 if (numValue > 130) return { status: 'warning', labelKey: 'vitals.status.elevated', percentage: 75 };
                 return { status: 'normal', labelKey: 'vitals.status.normal', percentage: 50 };
            case 'temperature':
                 if (numValue > 38.5) return { status: 'danger', labelKey: 'vitals.status.highFever', percentage: 100 };
                 if (numValue > 37.5) return { status: 'warning', labelKey: 'vitals.status.fever', percentage: 75 };
                 return { status: 'normal', labelKey: 'vitals.status.normal', percentage: 50 };
            default:
                return { status: 'normal', labelKey: 'vitals.status.normal', percentage: 50 };
        }
    };

    const { status, labelKey, percentage } = getStatusDetails();
    const classes = statusClasses[status];

    return (
        <div className={`bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg p-4 shadow-lg flex flex-col justify-between border-l-4 transition-all duration-300 hover:bg-slate-50 dark:hover:bg-slate-700/50 ${classes.border} ${classes.bg} ${classes.anim} h-full`}>
            <div className="flex items-start justify-between">
                <div>
                    <p className="text-slate-500 dark:text-slate-400 text-sm">{label}</p>
                    <p className="text-3xl font-bold text-slate-800 dark:text-white mt-1">
                        {value} <span className="text-lg font-normal text-slate-600 dark:text-slate-300">{unit}</span>
                    </p>
                </div>
                <div className={`p-2 rounded-full ${status !== 'normal' ? 'bg-slate-200 dark:bg-slate-700' : ''} ${classes.text}`}>
                    {icon}
                </div>
            </div>
            <div className="mt-3">
                <p className={`text-sm font-semibold ${classes.text}`}>{t(labelKey)}</p>
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 mt-2">
                    <div className={`${classes.gauge} h-1.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
                </div>
            </div>
        </div>
    );
};

export default VitalsCard;