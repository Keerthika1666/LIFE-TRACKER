
import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { patientDataService } from '../services/patientDataService';
import { Appointment } from '../types';
import AppointmentModal from '../components/AppointmentModal';

const PageHeader = ({ onSchedule, t }: { onSchedule: () => void, t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-white tracking-tight">{t('doctor.appointments.header')}</h1>
            <p className="text-slate-400 mt-1">{t('doctor.appointments.subHeader')}</p>
        </div>
        <button onClick={onSchedule} className="px-4 py-2 text-sm font-medium bg-cyan-500 rounded-md hover:bg-cyan-600 transition-colors flex items-center space-x-2">
            <span>{t('doctor.appointments.scheduleNew')}</span>
        </button>
    </div>
);

const statusStyles = {
    Scheduled: 'bg-blue-500/20 text-blue-300',
    Completed: 'bg-green-500/20 text-green-300',
    Cancelled: 'bg-red-500/20 text-red-300',
};

const Appointments = (): React.ReactNode => {
    const { t } = useLanguage();
    const [appointments, setAppointments] = useState<Appointment[]>(patientDataService.getAppointments());
    const [isModalOpen, setIsModalOpen] = useState(false);

    const handleSaveAppointment = (appointmentData: Omit<Appointment, 'id' | 'patientName' | 'status'>) => {
        patientDataService.addPatientAppointment(appointmentData.patientId, appointmentData);
        setAppointments(patientDataService.getAppointments()); // Refresh list
        setIsModalOpen(false);
    };

    const upcomingAppointments = appointments
        .filter(a => a.status === 'Scheduled')
        .sort((a, b) => a.date.getTime() - b.date.getTime());

    return (
        <>
            <PageHeader onSchedule={() => setIsModalOpen(true)} t={t} />
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg animate-fadeInUp animation-delay-100">
                <div className="p-4 border-b border-slate-700">
                    <h3 className="text-lg font-semibold text-white">{t('doctor.appointments.upcoming')}</h3>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-300">
                        <thead className="text-xs text-slate-400 uppercase bg-slate-800/60">
                            <tr>
                                <th scope="col" className="px-6 py-3">{t('doctor.appointments.patient')}</th>
                                <th scope="col" className="px-6 py-3">{t('doctor.appointments.date')}</th>
                                <th scope="col" className="px-6 py-3">{t('doctor.appointments.reason')}</th>
                                <th scope="col" className="px-6 py-3 text-center">{t('doctor.appointments.status')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {upcomingAppointments.length > 0 ? upcomingAppointments.map(appt => (
                                <tr key={appt.id} className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors">
                                    <td className="px-6 py-4 font-medium text-white whitespace-nowrap">{appt.patientName}</td>
                                    <td className="px-6 py-4">{appt.date.toLocaleString()}</td>
                                    <td className="px-6 py-4">{appt.reason}</td>
                                    <td className="px-6 py-4 text-center">
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusStyles[appt.status]}`}>
                                            {appt.status}
                                        </span>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={4} className="text-center py-10 text-slate-500">{t('doctor.appointments.noAppointments')}</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
            <AppointmentModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSaveAppointment}
            />
        </>
    );
};

export default Appointments;
