import React from 'react';

const Header = (): React.ReactNode => {
  return null;
};

export default Header;
