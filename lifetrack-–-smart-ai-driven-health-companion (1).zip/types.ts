
export type Page = 
  | 'overview' | 'trends' | 'family' | 'settings' 
  | 'vitalsScan' | 'aiChat' | 'alerts'
  | 'medication' | 'labReports'
  | 'achievements' | 'sharedNotes'
  | 'doctorDashboard' | 'patientDetail';

export interface VitalData {
  time: string;
  heartRate: number;
  spo2: number;
  systolicBP: number;
  diastolicBP: number;
  temperature: number;
}

export type VitalSign = 'heartRate' | 'spo2' | 'bloodPressure' | 'temperature';

export interface Prediction {
  riskLevel: 'Low' | 'Medium' | 'High' | 'Unknown';
  prediction: string;
}

export enum RiskLevel {
    Low = 'Low',
    Medium = 'Medium',
    High = 'High',
    Unknown = 'Unknown',
}

export interface Contact {
    id: number | string;
    name: string;
    age?: number;
    relation: 'Primary Doctor' | 'Cardiologist' | 'Specialist' | 'Spouse' | 'Mother' | 'Father' | 'Daughter' | 'Son' | 'Friend' | 'Other Family';
    avatarUrl: string;
    status: 'Online' | 'Offline';
    lastContact: string;
}

export enum AlertType {
  HIGH_HEART_RATE = 'High Heart Rate',
  LOW_HEART_RATE = 'Low Heart Rate',
  LOW_SPO2 = 'Low SpO₂',
  HIGH_BP = 'High Blood Pressure',
  HIGH_TEMPERATURE = 'High Temperature',
  SOS_MANUAL = 'Manual SOS',
}

export interface Alert {
  id: string;
  timestamp: Date;
  type: AlertType;
  value: string;
  threshold: string;
  status: 'new' | 'viewed';
}

export type UserRole = 'Patient' | 'Doctor' | 'Caregiver';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  avatarUrl: string;
}

// New Type for Prescriptions
export interface Prescription {
    id: string;
    patientId: string;
    patientName: string;
    medicationName: string;
    dosage: string;
    frequency: string;
    dateIssued: Date;
    status: 'Active' | 'Completed';
}

// New Type for Appointments
export interface Appointment {
    id: string;
    patientId: string;
    patientName: string;
    date: Date;
    reason: string;
    status: 'Scheduled' | 'Completed' | 'Cancelled';
}

// New Type for Voice Notes
export interface VoiceNote {
    id: string;
    timestamp: Date;
    audioUrl: string;
    duration: number; // in seconds
}

// New Type for Shared Notes
export interface SharedNote {
    id: string;
    authorId: string;
    authorName: string;
    authorRole: UserRole;
    timestamp: Date;
    text: string;
}


export interface Patient {
    id: string;
    name: string;
    age: number;
    avatarUrl: string;
    lastVitals: VitalData;
    riskLevel: RiskLevel;
    lastAlert?: Alert;
    vitalsHistory: VitalData[];
    prescriptions?: Prescription[];
    appointments?: Appointment[];
    voiceNotes?: VoiceNote[];
    sharedNotes?: SharedNote[];
}

// New Type for Medication
export interface Medication {
    id: string;
    name: string;
    dosage: string;
    frequency: string;
    time: string[]; // e.g., ["08:00", "20:00"]
    status: 'due' | 'taken' | 'skipped';
}

// New Type for Lab Reports
export interface LabReport {
    id: string;
    name:string;
    type: 'Blood Test' | 'ECG' | 'MRI Scan';
    date: Date;
    fileUrl?: string; // a mock url
    summary?: string; // AI generated summary
}

// New Type for Lifestyle Data
export interface LifestyleData {
    steps: { current: number; goal: number };
    sleep: { hours: number; goal: number };
    calories: { current: number; goal: number };
}

// New Types for Gamification
export interface Badge {
    id: string;
    nameKey: string; // key for translation
    descriptionKey: string; // key for translation
    icon: string; // name of the icon component
    earned: boolean;
    earnedDate?: Date;
}

export interface GamificationData {
    points: number;
    badges: Badge[];
}