





import React, { useState, useMemo, useEffect } from 'react';
import { useVitalsData } from '../hooks/useVitalsData';
import { Patient, VitalData, Prescription, Appointment } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { ICONS } from '../constants';
import VitalsCard from '../components/VitalsCard';
import VitalsChart from '../components/VitalsChart';
import { useSettings } from '../contexts/SettingsContext';
import CallModal from '../components/CallModal';
import MessageModal from '../components/MessageModal';
import PrescriptionModal from '../components/PrescriptionModal';
import AppointmentModal from '../components/AppointmentModal';
import VoiceNotes from '../components/VoiceNotes';
import SharedNotesCard from '../components/SharedNotesCard';
import { getPatientSummary } from '../services/geminiService';
import { patientDataService } from '../services/patientDataService';

const PatientHeader = ({ patient, onBack, onCall, onMessage, onWritePrescription, onScheduleAppointment, t }: {
    patient: Patient,
    onBack: () => void,
    onCall: () => void,
    onMessage: () => void,
    onWritePrescription: () => void;
    onScheduleAppointment: () => void;
    t: (key: string, options?: any) => string
}) => (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 animate-fadeInUp">
        <div className="flex items-center space-x-4">
            <button onClick={onBack} className="p-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-full hover:bg-cyan-500 hover:text-white dark:hover:text-white transition-colors flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            </button>
            <img
                className="w-14 h-14 rounded-full border-2 border-cyan-500 object-cover"
                src={patient.avatarUrl}
                alt="Patient profile"
            />
            <div>
                <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{patient.name}</h1>
                <p className="text-slate-500 dark:text-slate-400 mt-1">{t('doctor.patientDetail.subHeader', { age: patient.age })}</p>
            </div>
        </div>

        <div className="flex items-center space-x-3 mt-4 sm:mt-0 self-end sm:self-center">
            <button onClick={onWritePrescription} className="hidden lg:flex items-center space-x-2 px-4 py-2 text-sm font-medium bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-md hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors">{ICONS.prescriptions}<span>{t('doctor.patientDetail.writePrescription')}</span></button>
            <button onClick={onScheduleAppointment} className="hidden lg:flex items-center space-x-2 px-4 py-2 text-sm font-medium bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-md hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors">{ICONS.appointments}<span>{t('doctor.patientDetail.scheduleAppointment')}</span></button>
            <button onClick={onMessage} className="flex items-center space-x-2 px-4 py-2 text-sm font-medium bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-md hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 5a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm3.707 2.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0l5-5a1 1 0 00-1.414-1.414L10 9.586 5.707 7.293z" /></svg></button>
            <button onClick={onCall} className="flex items-center space-x-2 px-4 py-2 text-sm font-medium bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors"><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" /></svg></button>
        </div>
    </div>
);

const VitalHistoryDetailCard = ({ title, data, dataKey, unit, threshold }: {
    title: string;
    data: VitalData[];
    dataKey: keyof Pick<VitalData, 'heartRate' | 'spo2' | 'temperature'>;
    unit: string;
    threshold?: number;
}) => {
    const { t } = useLanguage();

    const stats = useMemo(() => {
        if (!data || data.length === 0) return { avg: 0, min: 0, max: 0 };
        const values = data.map(v => v[dataKey]);
        const numericValues = values.filter(v => typeof v === 'number') as number[];
        if (numericValues.length === 0) return { avg: 0, min: 0, max: 0 };

        return {
            avg: Math.round(numericValues.reduce((a, b) => a + b) / numericValues.length),
            min: Math.min(...numericValues),
            max: Math.max(...numericValues),
        };
    }, [data, dataKey]);

    return (
        <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg p-4 shadow-lg h-full flex flex-col">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-2">{title}</h3>
            <div className="h-40 flex-grow">
                <VitalsChart type="single" vitalKey={dataKey} data={data} threshold={threshold} showSingleHeader={false} />
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center text-sm border-t border-slate-200 dark:border-slate-700 pt-3">
                <div>
                    <p className="text-slate-500 dark:text-slate-400">{t('doctor.patientDetail.avg')}</p>
                    <p className="font-bold text-slate-800 dark:text-white text-lg">{stats.avg} <span className="text-xs text-slate-500 dark:text-slate-400">{unit}</span></p>
                </div>
                <div>
                    <p className="text-slate-500 dark:text-slate-400">{t('doctor.patientDetail.min')}</p>
                    <p className="font-bold text-slate-800 dark:text-white text-lg">{stats.min} <span className="text-xs text-slate-500 dark:text-slate-400">{unit}</span></p>
                </div>
                <div>
                    <p className="text-slate-500 dark:text-slate-400">{t('doctor.patientDetail.max')}</p>
                    <p className="font-bold text-slate-800 dark:text-white text-lg">{stats.max} <span className="text-xs text-slate-500 dark:text-slate-400">{unit}</span></p>
                </div>
            </div>
        </div>
    );
};

const PatientSummaryCard = ({ patient }: { patient: Patient }) => {
    const [summary, setSummary] = useState('');
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchSummary = async () => {
            setIsLoading(true);
            const result = await getPatientSummary(patient);
            setSummary(result);
            setIsLoading(false);
        };
        fetchSummary();
    }, [patient]);

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="space-y-3">
                    <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4 animate-pulse"></div>
                    <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-full animate-pulse" style={{ animationDelay: '100ms' }}></div>
                    <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-5/6 animate-pulse" style={{ animationDelay: '200ms' }}></div>
                </div>
            );
        }
        const formattedSummary = summary
            .replace(/\n/g, '<br />')
            .replace(/\*\*|__(.*?)\1/g, '<strong>$2</strong>')
            .replace(/(\* |- )/g, '&bull; ');

        return <div className="prose prose-sm dark:prose-invert" dangerouslySetInnerHTML={{ __html: formattedSummary }} />;
    };

    return (
        <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg p-6 shadow-lg h-full">
            <div className="flex items-center mb-4">
                <div className="text-cyan-500 dark:text-cyan-400 mr-3">{ICONS.sparkles}</div>
                <h3 className="text-lg font-semibold text-slate-800 dark:text-white">AI-Generated 24-Hour Summary</h3>
            </div>
            <div className="min-h-[80px]">
                {renderContent()}
            </div>
        </div>
    );
};


const PatientDetailView = ({ patient: initialPatient, onBack }: { patient: Patient; onBack: () => void }): React.ReactNode => {
    const { vitalsHistory, latestVitals } = useVitalsData(initialPatient.id);
    const { t } = useLanguage();
    const { heartRateThreshold, spo2Threshold } = useSettings();
    const [isCallModalOpen, setIsCallModalOpen] = useState(false);
    const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
    const [isPrescriptionModalOpen, setIsPrescriptionModalOpen] = useState(false);
    const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
    
    // Use state to manage patient data to reflect updates (like new notes)
    const [patient, setPatient] = useState<Patient>(initialPatient);

    useEffect(() => {
        const unsubscribe = patientDataService.subscribe(patients => {
            const updatedPatient = patients.find(p => p.id === initialPatient.id);
            if (updatedPatient) {
                setPatient(updatedPatient);
            }
        });
        return unsubscribe;
    }, [initialPatient.id]);

    if (!latestVitals) {
        return (
             <div className="flex items-center justify-center h-screen">
                <div className="relative h-20 w-20">
                    <div className="absolute inset-0 rounded-full border-4 border-cyan-500/50"></div>
                    <div className="absolute inset-0 rounded-full border-t-4 border-cyan-400 animate-spin"></div>
                </div>
            </div>
        );
    }
    
    const animationClasses = [
      'animate-fadeInUp animation-delay-100', 'animate-fadeInUp animation-delay-200',
      'animate-fadeInUp animation-delay-300', 'animate-fadeInUp animation-delay-400',
      'animate-fadeInUp animation-delay-500', 'animate-fadeInUp animation-delay-600',
      'animate-fadeInUp animation-delay-700'
    ];
    
    const handleSavePrescription = (prescription: Omit<Prescription, 'id' | 'patientName' | 'dateIssued' | 'status'>) => {
        // In a real app, this would be an API call. Here we simulate.
        console.log('New Prescription:', prescription);
        patientDataService.addPatientPrescription(patient.id, prescription);
        setIsPrescriptionModalOpen(false);
    };

    const handleSaveAppointment = (appointment: Omit<Appointment, 'id' | 'patientName' | 'status'>) => {
        console.log('New Appointment:', appointment);
        patientDataService.addPatientAppointment(patient.id, appointment);
        setIsAppointmentModalOpen(false);
    };

    return (
        <div className="p-4 sm:p-6 lg:p-8 pb-20">
            <PatientHeader 
                patient={patient} 
                onBack={onBack} 
                onCall={() => setIsCallModalOpen(true)}
                onMessage={() => setIsMessageModalOpen(true)}
                onWritePrescription={() => setIsPrescriptionModalOpen(true)}
                onScheduleAppointment={() => setIsAppointmentModalOpen(true)}
                t={t}
            />
            
            <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className={animationClasses[0]}><VitalsCard label={t('overview.vitals.heartRate')} vitalKey="heartRate" value={latestVitals.heartRate} unit={t('overview.units.bpm')} icon={ICONS.heartRate} /></div>
                    <div className={animationClasses[1]}><VitalsCard label={t('overview.vitals.spo2')} vitalKey="spo2" value={latestVitals.spo2} unit={t('overview.units.percent')} icon={ICONS.spo2} /></div>
                    <div className={animationClasses[2]}><VitalsCard label={t('overview.vitals.bloodPressure')} vitalKey="bloodPressure" value={`${latestVitals.systolicBP}/${latestVitals.diastolicBP}`} unit={t('overview.units.mmhg')} icon={ICONS.bloodPressure} /></div>
                    <div className={animationClasses[3]}><VitalsCard label={t('overview.vitals.temperature')} vitalKey="temperature" value={latestVitals.temperature} unit={t('overview.units.celsius')} icon={ICONS.temperature} /></div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className={`${animationClasses[4]} lg:col-span-2`}>
                        <PatientSummaryCard patient={{...patient, vitalsHistory, lastVitals: latestVitals}} />
                    </div>
                     <div className={animationClasses[5]}>
                        <VoiceNotes patient={patient} />
                    </div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                     <div className={`${animationClasses[5]} lg:col-span-2`}>
                        <SharedNotesCard patient={patient} />
                    </div>
                     <div className={`${animationClasses[6]}`}>
                        {/* Placeholder for now or another card */}
                    </div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                     <div className={animationClasses[4]}>
                        <VitalHistoryDetailCard 
                            title={t('doctor.patientDetail.historyTitle', { vitalName: t('overview.vitals.heartRate')})}
                            data={vitalsHistory}
                            dataKey="heartRate"
                            unit={t('overview.units.bpm')}
                            threshold={heartRateThreshold}
                        />
                    </div>
                     <div className={animationClasses[5]}>
                        <VitalHistoryDetailCard 
                            title={t('doctor.patientDetail.historyTitle', { vitalName: t('overview.vitals.spo2')})}
                            data={vitalsHistory}
                            dataKey="spo2"
                            unit={t('overview.units.percent')}
                            threshold={spo2Threshold}
                        />
                    </div>
                     <div className={animationClasses[6]}>
                        <VitalHistoryDetailCard 
                            title={t('doctor.patientDetail.historyTitle', { vitalName: t('overview.vitals.temperature')})}
                            data={vitalsHistory}
                            dataKey="temperature"
                            unit={t('overview.units.celsius')}
                            threshold={37.5}
                        />
                    </div>
                </div>
            </div>


            <CallModal person={isCallModalOpen ? patient : null} onClose={() => setIsCallModalOpen(false)} />
            <MessageModal person={isMessageModalOpen ? patient : null} onClose={() => setIsMessageModalOpen(false)} />
            <PrescriptionModal 
                isOpen={isPrescriptionModalOpen}
                onClose={() => setIsPrescriptionModalOpen(false)}
                onSave={handleSavePrescription}
                patient={patient}
            />
            <AppointmentModal 
                isOpen={isAppointmentModalOpen}
                onClose={() => setIsAppointmentModalOpen(false)}
                onSave={handleSaveAppointment}
                patient={patient}
            />
        </div>
    );
};

export default PatientDetailView;