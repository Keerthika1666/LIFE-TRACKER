import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';

type Language = 'en' | 'ta';
type Translations = { [key: string]: any };

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string, options?: { [key: string]: string | number }) => string;
  isLoaded: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const getNestedTranslation = (translations: Translations | undefined, key: string): string | undefined => {
    if (!translations) return undefined;
    return key.split('.').reduce((obj, k) => {
        return obj && obj[k] ? obj[k] : undefined;
    }, translations);
};

export const LanguageProvider = ({ children }: { children: React.ReactNode }) => {
  const [language, setLanguageState] = useState<Language>('en');
  const [translations, setTranslations] = useState<Translations | undefined>(undefined);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const browserLang = navigator.language.split('-')[0];
    if (browserLang === 'ta') {
      setLanguageState('ta');
    } else {
      setLanguageState('en');
    }
  }, []);

  useEffect(() => {
    const loadTranslations = async () => {
      setIsLoaded(false);
      try {
        const response = await fetch(`../i18n/locales/${language}.json`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setTranslations(data);
      } catch (error) {
        console.error(`Could not load translations for ${language}:`, error);
        if (language !== 'en') {
            setLanguageState('en');
        } else {
            setTranslations({});
        }
      } finally {
        setIsLoaded(true);
      }
    };

    loadTranslations();
  }, [language]);

  const t = useCallback((key: string, options?: { [key:string]: string | number }): string => {
    if (!isLoaded || !translations) {
        return key;
    }

    let translation = getNestedTranslation(translations, key);

    if (translation === undefined) {
        console.warn(`Translation key "${key}" not found for language "${language}".`);
        return key;
    }

    if (options) {
        Object.keys(options).forEach(k => {
            const regex = new RegExp(`{{${k}}}`, 'g');
            translation = translation!.replace(regex, String(options[k]));
        });
    }

    return translation!;
  }, [language, translations, isLoaded]);

  const value = { language, setLanguage: setLanguageState, t, isLoaded };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};