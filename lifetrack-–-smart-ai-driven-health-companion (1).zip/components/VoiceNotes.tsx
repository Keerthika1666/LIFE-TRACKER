
import React, { useState, useRef, useEffect } from 'react';
import { Patient, VoiceNote } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { ICONS } from '../constants';
import { patientDataService } from '../services/patientDataService';

const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
};

const VoiceNotes = ({ patient }: { patient: Patient }): React.ReactNode => {
    const { t } = useLanguage();
    const [isRecording, setIsRecording] = useState(false);
    const [recordingTime, setRecordingTime] = useState(0);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const timerRef = useRef<number | null>(null);

    const stopRecording = () => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
            mediaRecorderRef.current.stop();
        }
        setIsRecording(false);
        if (timerRef.current) clearInterval(timerRef.current);
        setRecordingTime(0);
    };

    const handleStartRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorderRef.current = new MediaRecorder(stream);
            audioChunksRef.current = [];

            mediaRecorderRef.current.ondataavailable = event => {
                audioChunksRef.current.push(event.data);
            };

            mediaRecorderRef.current.onstop = () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                const audioUrl = URL.createObjectURL(audioBlob);
                const newNote: Omit<VoiceNote, 'id'> = {
                    timestamp: new Date(),
                    audioUrl,
                    duration: recordingTime,
                };
                patientDataService.addPatientVoiceNote(patient.id, newNote);
                stream.getTracks().forEach(track => track.stop());
            };

            mediaRecorderRef.current.start();
            setIsRecording(true);
            setRecordingTime(0);
            timerRef.current = window.setInterval(() => {
                setRecordingTime(prev => prev + 1);
            }, 1000);

        } catch (err) {
            console.error("Error starting recording:", err);
            alert("Could not start recording. Please ensure microphone permissions are granted.");
        }
    };

    const handleStopRecording = () => {
        stopRecording();
    };
    
    // Cleanup on unmount
    useEffect(() => {
        return () => {
           stopRecording();
        };
    }, []);

    return (
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg p-6 shadow-lg h-full flex flex-col">
            <h3 className="text-lg font-semibold text-white mb-4">{t('doctor.voiceNotes.title')}</h3>
            <div className="flex-grow space-y-2 overflow-y-auto max-h-48 pr-2">
                {patient.voiceNotes && patient.voiceNotes.length > 0 ? (
                    patient.voiceNotes.map(note => (
                        <div key={note.id} className="flex items-center justify-between bg-slate-700/50 p-2 rounded-md">
                            <div>
                                <p className="text-sm font-semibold text-white">{t('doctor.voiceNotes.note')} #{note.id.slice(-4)}</p>
                                <p className="text-xs text-slate-400">{note.timestamp.toLocaleString()}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                                <span className="text-xs text-slate-300 font-mono">{formatDuration(note.duration)}</span>
                                <audio src={note.audioUrl} controls className="h-8 w-32" />
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="flex items-center justify-center h-full">
                        <p className="text-slate-500 text-sm">No voice notes recorded.</p>
                    </div>
                )}
            </div>
            <div className="mt-4 pt-4 border-t border-slate-700">
                {isRecording ? (
                    <button onClick={handleStopRecording} className="w-full flex items-center justify-center space-x-2 px-4 py-3 text-lg font-bold bg-red-600 rounded-md hover:bg-red-700 transition-colors">
                        <span className="relative flex h-3 w-3"><span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span><span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span></span>
                        <span>{t('doctor.voiceNotes.stop')} ({formatDuration(recordingTime)})</span>
                    </button>
                ) : (
                    <button onClick={handleStartRecording} className="w-full flex items-center justify-center space-x-2 px-4 py-3 text-lg font-bold bg-cyan-500 rounded-md hover:bg-cyan-600 transition-colors">
                        {ICONS.mic}
                        <span>{t('doctor.voiceNotes.start')}</span>
                    </button>
                )}
            </div>
        </div>
    );
};

export default VoiceNotes;
