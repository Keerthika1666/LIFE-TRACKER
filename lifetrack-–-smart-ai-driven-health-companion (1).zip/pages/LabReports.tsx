
import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { mockLabReports } from '../data/mockData';
import { LabReport } from '../types';
import { ICONS } from '../constants';

const PageHeader = ({ onUpload, t }: { onUpload: () => void, t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-white tracking-tight">{t('labReports.header')}</h1>
            <p className="text-slate-400 mt-1">{t('labReports.subHeader')}</p>
        </div>
        <button onClick={onUpload} className="px-4 py-2 text-sm font-medium bg-cyan-500 rounded-md hover:bg-cyan-600 transition-colors flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
            <span>{t('labReports.upload')}</span>
        </button>
    </div>
);

const ReportDetailModal = ({ report, onClose, t }: { report: LabReport | null, onClose: () => void, t: (key: string) => string }) => {
    if (!report) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-slate-800 rounded-lg shadow-xl p-6 w-full max-w-2xl border border-slate-700 animate-fadeInUp" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-start">
                    <div>
                        <h3 className="text-2xl font-bold text-white">{report.name}</h3>
                        <p className="text-cyan-400">{report.type} &bull; {report.date.toLocaleDateString()}</p>
                    </div>
                     <button onClick={onClose} className="text-slate-400 hover:text-white text-3xl font-bold">&times;</button>
                </div>
                <div className="mt-6">
                    <h4 className="font-semibold text-white mb-2 flex items-center space-x-2">
                        {ICONS.sparkles}
                        <span>{t('labReports.summary')}</span>
                    </h4>
                    <div className="bg-slate-700/50 p-4 rounded-lg text-slate-300">
                        <p>{report.summary || t('labReports.noSummary')}</p>
                    </div>
                </div>
                <div className="mt-6 text-right">
                     <button onClick={onClose} className="px-5 py-2 text-sm font-medium bg-slate-600 rounded-md hover:bg-slate-700 transition-colors">
                        {t('labReports.close')}
                    </button>
                </div>
            </div>
        </div>
    );
};

const LabReports = (): React.ReactNode => {
    const { t } = useLanguage();
    const [reports] = useState<LabReport[]>(mockLabReports);
    const [selectedReport, setSelectedReport] = useState<LabReport | null>(null);

    const handleUploadClick = () => {
        // This is a simulation
        alert(t('labReports.uploadMessage'));
    };

    return (
        <>
            <PageHeader onUpload={handleUploadClick} t={t} />
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg animate-fadeInUp animation-delay-100">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-300">
                        <thead className="text-xs text-slate-400 uppercase bg-slate-800/60">
                            <tr>
                                <th scope="col" className="px-6 py-3">{t('labReports.table.name')}</th>
                                <th scope="col" className="px-6 py-3">{t('labReports.table.type')}</th>
                                <th scope="col" className="px-6 py-3">{t('labReports.table.date')}</th>
                                <th scope="col" className="px-6 py-3"><span className="sr-only">View</span></th>
                            </tr>
                        </thead>
                        <tbody>
                            {reports.map((report) => (
                                <tr key={report.id} className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors">
                                    <th scope="row" className="px-6 py-4 font-medium text-white whitespace-nowrap">{report.name}</th>
                                    <td className="px-6 py-4">{report.type}</td>
                                    <td className="px-6 py-4">{report.date.toLocaleDateString()}</td>
                                    <td className="px-6 py-4 text-right">
                                        <button onClick={() => setSelectedReport(report)} className="font-medium text-cyan-400 hover:underline">{t('labReports.table.view')}</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            <ReportDetailModal report={selectedReport} onClose={() => setSelectedReport(null)} t={t} />
        </>
    );
};

export default LabReports;
