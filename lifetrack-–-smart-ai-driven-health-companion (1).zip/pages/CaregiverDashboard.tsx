
import React, { useEffect, useState } from 'react';
import { Patient, RiskLevel } from '../types';
import { useVitalsData } from '../hooks/useVitalsData';
import { useLanguage } from '../contexts/LanguageContext';
import VitalsCard from '../components/VitalsCard';
import { ICONS } from '../constants';
import { formatDistanceToNow } from 'date-fns';

const riskStyles = {
  [RiskLevel.Low]: {
    card: 'border-green-500 bg-green-500/10',
    glow: 'shadow-[0_0_20px_theme(colors.glow-green)]',
    text: 'text-green-400',
  },
  [RiskLevel.Medium]: {
    card: 'border-yellow-500 bg-yellow-500/10',
    glow: 'shadow-[0_0_20px_theme(colors.glow-yellow)] animate-pulse',
    text: 'text-yellow-400',
  },
  [RiskLevel.High]: {
    card: 'border-red-500 bg-red-500/10',
    glow: 'shadow-[0_0_30px_theme(colors.glow-red)] animate-pulse',
    text: 'text-red-400',
  },
  [RiskLevel.Unknown]: {
    card: 'border-slate-500 bg-slate-500/10',
    glow: '',
    text: 'text-slate-400',
  },
};

const CaregiverDashboard = ({ patient }: { patient: Patient }): React.ReactNode => {
    const { t } = useLanguage();
    // Use a derived state to ensure latest vitals are always fresh for the current patient
    const { latestVitals } = useVitalsData(patient.id);
    const [currentPatientData, setCurrentPatientData] = useState(patient);

    useEffect(() => {
        // When patient prop changes or latestVitals update, merge them
        if(latestVitals) {
            setCurrentPatientData(p => ({...p, ...patient, lastVitals: latestVitals}))
        } else {
            setCurrentPatientData(patient);
        }
    }, [patient, latestVitals]);

    const { lastVitals, riskLevel, lastAlert } = currentPatientData;
    const styles = riskStyles[riskLevel];

    return (
        <>
            <div className="flex items-center justify-between mb-6 animate-fadeInUp">
                <div>
                    <h1 className="text-3xl font-bold text-white tracking-tight">{t('caregiver.dashboard.header')}</h1>
                    <p className="text-slate-400 mt-1">{t('caregiver.dashboard.subHeader')}</p>
                </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Vitals */}
                <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="animate-fadeInUp animation-delay-100"><VitalsCard label={t('overview.vitals.heartRate')} vitalKey="heartRate" value={lastVitals.heartRate} unit={t('overview.units.bpm')} icon={ICONS.heartRate} /></div>
                    <div className="animate-fadeInUp animation-delay-200"><VitalsCard label={t('overview.vitals.spo2')} vitalKey="spo2" value={lastVitals.spo2} unit={t('overview.units.percent')} icon={ICONS.spo2} /></div>
                    <div className="animate-fadeInUp animation-delay-300"><VitalsCard label={t('overview.vitals.bloodPressure')} vitalKey="bloodPressure" value={`${lastVitals.systolicBP}/${lastVitals.diastolicBP}`} unit={t('overview.units.mmhg')} icon={ICONS.bloodPressure} /></div>
                    <div className="animate-fadeInUp animation-delay-400"><VitalsCard label={t('overview.vitals.temperature')} vitalKey="temperature" value={lastVitals.temperature} unit={t('overview.units.celsius')} icon={ICONS.temperature} /></div>
                </div>

                {/* Risk and Alert Status */}
                <div className="space-y-6">
                    <div className={`bg-slate-800/50 rounded-lg p-6 shadow-lg border-l-4 transition-all duration-500 h-full ${styles.card} ${styles.glow} animate-fadeInUp animation-delay-500`}>
                        <h3 className="text-lg font-semibold text-white mb-3">Current Risk Level</h3>
                        <p className={`text-3xl font-bold ${styles.text}`}>{t('overview.aiCompanion.risk', { riskLevel: riskLevel })}</p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-6 shadow-lg animate-fadeInUp animation-delay-600">
                        <h3 className="text-lg font-semibold text-white mb-3">Last Alert</h3>
                        {lastAlert ? (
                             <div>
                                <p className={`font-semibold ${lastAlert.status === 'new' ? 'text-yellow-400' : 'text-slate-300'}`}>{lastAlert.type}</p>
                                <p className="text-sm text-slate-400">{formatDistanceToNow(lastAlert.timestamp, { addSuffix: true })}</p>
                            </div>
                        ) : (
                            <p className="text-sm text-green-400">{t('overview.alerts.stable')}</p>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
};

export default CaregiverDashboard;
