import React, { useState, useRef, useEffect } from 'react';
import type { Contact, Patient } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { doctorChatService } from '../services/geminiService';

interface MessageModalProps {
    person: (Contact | Patient) | null;
    onClose: () => void;
}

const MessageModal = ({ person, onClose }: MessageModalProps) => {
    const { t } = useLanguage();
    const [messages, setMessages] = useState([
        { text: t('family.messageModal.initialMessage1'), sender: 'contact' },
    ]);
    const [newMessage, setNewMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        // Reset chat when a new person is selected
        if (person) {
            setMessages([
                { text: t('family.messageModal.initialMessage1'), sender: 'contact' },
            ]);
        }
    }, [person, t]);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, isLoading]);

    if (!person) return null;

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || !person || isLoading) return;

        const userMessage = { text: newMessage, sender: 'user' };
        setMessages(prev => [...prev, userMessage]);
        setNewMessage('');
        setIsLoading(true);

        // Check if the person is a patient (and not just a contact) to use AI
        if ('riskLevel' in person) {
            try {
                const stream = await doctorChatService.sendMessage(person as Patient, newMessage);
                let aiResponse = '';
                setMessages(prev => [...prev, { sender: 'contact', text: '' }]); // Add empty AI message
                
                for await (const chunk of stream) {
                    aiResponse += chunk.text;
                    setMessages(prev => {
                        const newMessages = [...prev];
                        newMessages[newMessages.length - 1].text = aiResponse;
                        return newMessages;
                    });
                }
            } catch (error) {
                console.error("AI chat error:", error);
                const errorMessage = { text: "Sorry, I'm having trouble responding right now.", sender: 'contact' };
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = errorMessage;
                    return newMessages;
                });
            } finally {
                setIsLoading(false);
            }
        } else { // Fallback for regular contacts with a simple canned reply
            setTimeout(() => {
                const reply = { text: t('family.messageModal.automatedReply'), sender: 'contact' };
                setMessages(prev => [...prev, reply]);
                setIsLoading(false);
            }, 1000);
        }
    };
    
    const contactStatus = 'status' in person ? person.status : 'Online';

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-lg h-[70vh] flex flex-col border border-slate-300 dark:border-slate-700 animate-fadeInUp" onClick={(e) => e.stopPropagation()}>
                <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
                    <div className="flex items-center space-x-3">
                        <img src={person.avatarUrl} alt={person.name} className="w-10 h-10 rounded-full object-cover"/>
                        <div>
                            <h3 className="font-bold text-slate-800 dark:text-white">{person.name}</h3>
                            <p className={`text-xs ${contactStatus === 'Online' ? 'text-green-500' : 'text-slate-500'}`}>{contactStatus}</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white text-2xl font-bold">&times;</button>
                </div>
                <div className="flex-grow p-4 overflow-y-auto space-y-4 bg-slate-50 dark:bg-slate-900/50">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                            {msg.sender === 'contact' && <img src={person.avatarUrl} className="w-6 h-6 rounded-full"/>}
                            <div className={`py-2 px-4 rounded-2xl max-w-sm ${msg.sender === 'user' ? 'bg-cyan-500 text-white rounded-br-none' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-bl-none'}`}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                        <div className="flex items-end gap-2 justify-start">
                            <img src={person.avatarUrl} className="w-6 h-6 rounded-full"/>
                            <div className="py-2 px-4 rounded-2xl bg-slate-200 dark:bg-slate-700">
                                <div className="flex items-center space-x-1">
                                    <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                                    <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                                    <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse"></span>
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
                <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-200 dark:border-slate-700 flex items-center space-x-2 flex-shrink-0">
                    <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder={t('family.messageModal.placeholder')}
                        className="flex-grow bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg py-2 px-4 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        autoFocus
                    />
                    <button type="submit" className="bg-cyan-500 text-white p-2 rounded-lg hover:bg-cyan-600 transition-colors disabled:bg-slate-400 dark:disabled:bg-slate-600" disabled={!newMessage.trim() || isLoading}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.428A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
                    </button>
                </form>
            </div>
        </div>
    );
};

export default MessageModal;