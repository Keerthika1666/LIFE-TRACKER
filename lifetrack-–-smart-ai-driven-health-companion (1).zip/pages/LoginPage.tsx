


import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useUser } from '../contexts/UserContext';
import { UserRole } from '../types';

const LoginPage = (): React.ReactNode => {
  const [role, setRole] = useState<UserRole>('Patient');
  const [identity, setIdentity] = useState('');
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [step, setStep] = useState<'identity' | 'verification'>('identity');
  const [verificationMode, setVerificationMode] = useState<'otp' | 'password'>('otp');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { t } = useLanguage();
  const { login } = useUser();

  const handleIdentitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (role === 'Patient' && identity.replace(/\D/g, '').length < 10) {
      setError(t('login.phoneError'));
      return;
    }
    if (role === 'Doctor' && !identity.includes('@')) {
      setError(t('login.emailError'));
      return;
    }
     if (role === 'Caregiver' && !identity.includes('@')) {
      setError(t('login.emailError'));
      return;
    }
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setStep('verification');
    }, 1000);
  };

  const handleVerificationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      const isOtpValid = verificationMode === 'otp' && otp === '1666';
      const isPasswordValid = verificationMode === 'password' && password === '1234';

      if (isOtpValid || isPasswordValid) {
        login(role);
      } else {
        setError(verificationMode === 'otp' ? t('login.otpError') : t('login.passwordError'));
      }
      setIsLoading(false);
      setOtp('');
      setPassword('');
    }, 1000);
  };

  const handleBack = () => {
    setStep('identity');
    setError('');
    setOtp('');
    setPassword('');
  };

  const getPlaceholder = () => {
      switch (role) {
          case 'Patient': return t('login.phonePlaceholder');
          case 'Doctor': return t('login.emailPlaceholder');
          case 'Caregiver': return t('login.emailPlaceholder');
          default: return '';
      }
  }

  const renderIdentityStep = () => (
    <form onSubmit={handleIdentitySubmit}>
      <div className="space-y-4">
        <input
          type={role === 'Patient' ? 'tel' : 'email'}
          placeholder={getPlaceholder()}
          value={identity}
          onChange={(e) => setIdentity(e.target.value)}
          className="block w-full text-center bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-3 px-4 text-slate-800 dark:text-white text-lg tracking-wider focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
          disabled={isLoading}
          aria-label={role === 'Patient' ? "Mobile Number" : "Email Address"}
        />
        {error && <p className="text-red-500 dark:text-red-400 text-sm">{error}</p>}
      </div>
      <button
        type="submit"
        disabled={isLoading || identity.length < 5}
        className="w-full mt-6 bg-cyan-500 text-white font-bold py-3 px-4 rounded-md hover:bg-cyan-600 transition-all duration-300 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
      >
        {isLoading ? ( <LoadingSpinner /> ) : ( <span>{t('login.sendOtp')}</span> )}
      </button>
    </form>
  );

  const renderVerificationStep = () => (
    <form onSubmit={handleVerificationSubmit}>
      <div className="space-y-4">
        <p className="text-slate-500 dark:text-slate-400 text-sm">{t('login.otpSent', { identity })}</p>
        {verificationMode === 'otp' ? (
            <input
              type="password"
              placeholder={t('login.otpPlaceholder')}
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="block w-full text-center bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-3 px-4 text-slate-800 dark:text-white text-lg tracking-widest focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
              disabled={isLoading}
              maxLength={4}
              autoFocus
            />
        ) : (
             <input
              type="password"
              placeholder={t('login.passwordPlaceholder')}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="block w-full text-center bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-3 px-4 text-slate-800 dark:text-white text-lg tracking-widest focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
              disabled={isLoading}
              autoFocus
            />
        )}
        {error && <p className="text-red-500 dark:text-red-400 text-sm">{error}</p>}
      </div>
       <button type="button" onClick={() => setVerificationMode(verificationMode === 'otp' ? 'password' : 'otp')} className="text-sm text-cyan-500 dark:text-cyan-400 hover:underline mt-4">
            {verificationMode === 'otp' ? t('login.usePassword') : t('login.useOtp')}
        </button>
      <button
        type="submit"
        disabled={isLoading || (verificationMode === 'otp' && otp.length < 4) || (verificationMode === 'password' && password.length < 4)}
        className="w-full mt-4 bg-cyan-500 text-white font-bold py-3 px-4 rounded-md hover:bg-cyan-600 transition-all duration-300 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
      >
        {isLoading ? ( <LoadingSpinner /> ) : ( <span>{t('login.secureLogin')}</span> )}
      </button>
      <button type="button" onClick={handleBack} className="text-sm text-slate-500 dark:text-slate-400 hover:text-cyan-500 dark:hover:text-cyan-400 mt-4">
        {t('login.changeIdentity')}
      </button>
    </form>
  );
  
  const LoadingSpinner = () => (<svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>);

  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-full max-w-md mx-auto p-6 animate-fadeInUp">
        <div className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm border border-slate-200 dark:border-slate-700 rounded-2xl shadow-2xl p-8 text-center">
          <div className="flex items-center justify-center w-20 h-20 mb-6 mx-auto">
             <svg className="w-16 h-16 text-cyan-500 dark:text-cyan-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z" />
             </svg>
          </div>
          <h1 className="text-3xl font-bold text-slate-800 dark:text-white mb-2">{t('login.welcome')}</h1>
          <p className="text-slate-600 dark:text-slate-400 mb-8">{t('login.tagline')}</p>

          <div className="flex items-center justify-center space-x-2 bg-slate-200/50 dark:bg-slate-700/50 p-1 rounded-lg mb-6">
            {(['Patient', 'Doctor', 'Caregiver'] as UserRole[]).map(r => (
              <button
                key={r}
                onClick={() => { setRole(r); setIdentity(''); setError(''); }}
                className={`w-full px-4 py-2 text-sm font-medium rounded-md transition-colors duration-300 ${role === r ? 'bg-cyan-500 text-white shadow-md' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'}`}
              >
                {t(`login.${r.toLowerCase()}`)}
              </button>
            ))}
          </div>
          
          {step === 'identity' ? renderIdentityStep() : renderVerificationStep()}
          
          <div className="text-xs text-slate-500 dark:text-slate-500 mt-8 border-t border-slate-300 dark:border-slate-700 pt-4">
            <p className="font-bold">{t('login.demoInfo')}</p>
            <p>{t('login.demoPatient')} <span className="font-mono">1234567890</span></p>
            <p>{t('login.demoDoctor')} <span className="font-mono">doctor@lifetrack.app</span></p>
            <p>{t('login.demoCaregiver')} <span className="font-mono">caregiver@lifetrack.app</span></p>
            <p>{t('login.demoOtp')} <span className="font-mono">1666</span> or Password: <span className="font-mono">1234</span></p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;