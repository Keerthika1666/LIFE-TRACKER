
import { User, Patient, Contact, VitalData, RiskLevel, AlertType, Medication, LabReport, LifestyleData, Prescription, Appointment, VoiceNote, GamificationData, Badge, SharedNote } from '../types';

export const mockPatientUser: User = {
    id: 'patient-john-doe',
    name: 'John Doe',
    role: 'Patient',
    avatarUrl: 'https://picsum.photos/100'
};

export const mockDoctorUser: User = {
    id: 'doctor-emily-carter',
    name: 'Dr. Emily Carter',
    role: 'Doctor',
    avatarUrl: 'https://picsum.photos/id/1027/100'
};

export const mockCaregiverUser: User = {
    id: 'caregiver-alex-doe',
    name: 'Alex Doe',
    role: 'Caregiver',
    avatarUrl: 'https://picsum.photos/id/1011/100'
};


export const mockFamilyContacts: Contact[] = [
    { id: 1, name: 'Dr. Emily Carter', age: 45, relation: 'Primary Doctor', avatarUrl: 'https://picsum.photos/id/1027/100', status: 'Online', lastContact: 'Yesterday' },
    { id: 2, name: 'Dr. Marcus Thorne', age: 52, relation: 'Cardiologist', avatarUrl: 'https://picsum.photos/id/1005/100', status: 'Offline', lastContact: '3 days ago' },
    { id: 3, name: 'Sarah Doe', age: 68, relation: 'Spouse', avatarUrl: 'https://picsum.photos/id/1014/100', status: 'Online', lastContact: '2 hours ago' },
    { id: 4, name: 'Alex Doe', age: 42, relation: 'Daughter', avatarUrl: 'https://picsum.photos/id/1011/100', status: 'Offline', lastContact: 'Today' },
];


// --- Vitals Simulation ---
const generateRandomVital = (base: number, variance: number): number => {
    return parseFloat((base + (Math.random() - 0.5) * variance).toFixed(1));
};

export const generateNewVitals = (): VitalData => {
    return {
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        heartRate: Math.round(Math.random() > 0.9 ? generateRandomVital(105, 10) : generateRandomVital(75, 10)),
        spo2: Math.round(Math.random() > 0.85 ? generateRandomVital(93, 2) : generateRandomVital(98, 1)),
        systolicBP: Math.round(generateRandomVital(120, 15)),
        diastolicBP: Math.round(generateRandomVital(80, 10)),
        temperature: parseFloat((Math.random() > 0.9 ? generateRandomVital(38.0, 0.5) : generateRandomVital(37.0, 0.3)).toFixed(1)),
    };
};

const generatePatientHistory = (points: number = 30): VitalData[] => {
    const data: VitalData[] = [];
    const baseTime = new Date();
    // Simulate slight variations for each patient's history
    const hrVariance = 10 + Math.random() * 10;
    const spo2Base = 96 + Math.random() * 2;
    for (let i = 0; i < points; i++) {
        data.push({
            time: new Date(baseTime.getTime() - (points - i) * 60000).toLocaleTimeString(),
            heartRate: Math.round(generateRandomVital(75, hrVariance)),
            spo2: Math.round(generateRandomVital(spo2Base, 1)),
            systolicBP: Math.round(generateRandomVital(120, 15)),
            diastolicBP: Math.round(generateRandomVital(80, 10)),
            temperature: parseFloat(generateRandomVital(37.0, 0.3).toFixed(1)),
        });
    }
    return data;
};

// --- Doctor's Mock Data ---

export const mockPrescriptions: Prescription[] = [
    { id: 'presc1', patientId: 'patient-jane-smith', patientName: 'Jane Smith', medicationName: 'Metoprolol', dosage: '25mg', frequency: 'Twice a day', dateIssued: new Date('2024-07-15'), status: 'Active' },
    { id: 'presc2', patientId: 'patient-robert-jones', patientName: 'Robert Jones', medicationName: 'Amlodipine', dosage: '5mg', frequency: 'Once a day', dateIssued: new Date('2024-07-10'), status: 'Active' },
    { id: 'presc3', patientId: 'patient-robert-jones', patientName: 'Robert Jones', medicationName: 'Rosuvastatin', dosage: '10mg', frequency: 'Once daily at night', dateIssued: new Date('2024-06-20'), status: 'Active' },
    { id: 'presc4', patientId: 'patient-john-doe', patientName: 'John Doe', medicationName: 'Lisinopril', dosage: '10mg', frequency: 'Once a day', dateIssued: new Date('2024-05-01'), status: 'Completed' },
];

export const mockAppointments: Appointment[] = [
    { id: 'appt1', patientId: 'patient-jane-smith', patientName: 'Jane Smith', date: new Date(new Date().setDate(new Date().getDate() + 2)), reason: 'Follow-up on BP readings', status: 'Scheduled' },
    { id: 'appt2', patientId: 'patient-robert-jones', patientName: 'Robert Jones', date: new Date(new Date().setDate(new Date().getDate() + 5)), reason: 'Check-up after medication change', status: 'Scheduled' },
    { id: 'appt3', patientId: 'patient-mary-williams', patientName: 'Mary Williams', date: new Date(new Date().setDate(new Date().getDate() - 7)), reason: 'Annual physical exam', status: 'Completed' },
];

export const mockVoiceNotes: { [patientId: string]: VoiceNote[] } = {
    'patient-jane-smith': [
        { id: 'vn1', timestamp: new Date(Date.now() - 86400000), audioUrl: '', duration: 15 }, // Placeholder URL
        { id: 'vn2', timestamp: new Date(Date.now() - 172800000), audioUrl: '', duration: 22 },
    ],
    'patient-robert-jones': [
        { id: 'vn3', timestamp: new Date(Date.now() - 3600000), audioUrl: '', duration: 31 },
    ]
};

export const mockSharedNotes: { [patientId: string]: SharedNote[] } = {
    'patient-john-doe': [
        { id: 'sn1', authorId: 'caregiver-alex-doe', authorName: 'Alex Doe', authorRole: 'Caregiver', timestamp: new Date(Date.now() - 3600000), text: 'Gave Dad his 10 AM medication. He took it with breakfast.' },
        { id: 'sn2', authorId: 'doctor-emily-carter', authorName: 'Dr. Emily Carter', authorRole: 'Doctor', timestamp: new Date(Date.now() - 86400000), text: 'Patient reports feeling well. Continue current medication plan. Follow up in 2 weeks.' }
    ],
    'patient-sarah-doe': [
        { id: 'sn3', authorId: 'caregiver-alex-doe', authorName: 'Alex Doe', authorRole: 'Caregiver', timestamp: new Date(Date.now() - 86400000 * 2), text: 'Mom seems to be in good spirits today. Went for a short walk in the garden.' }
    ]
};

// --- Doctor's Patient List ---
export const mockPatients: Patient[] = [
    {
        id: 'patient-john-doe',
        name: 'John Doe',
        age: 72,
        avatarUrl: 'https://picsum.photos/100',
        lastVitals: generateNewVitals(),
        riskLevel: RiskLevel.Low,
        vitalsHistory: generatePatientHistory(),
        prescriptions: mockPrescriptions.filter(p => p.patientId === 'patient-john-doe'),
        appointments: mockAppointments.filter(a => a.patientId === 'patient-john-doe'),
        voiceNotes: mockVoiceNotes['patient-john-doe'] || [],
        sharedNotes: mockSharedNotes['patient-john-doe'] || []
    },
    {
        id: 'patient-jane-smith',
        name: 'Jane Smith',
        age: 65,
        avatarUrl: 'https://picsum.photos/id/1011/100',
        lastVitals: { time: '10:30 AM', heartRate: 95, spo2: 94, systolicBP: 135, diastolicBP: 85, temperature: 37.1 },
        riskLevel: RiskLevel.Medium,
        lastAlert: { id: 'a1', type: AlertType.LOW_SPO2, value: '91%', threshold: '<92%', timestamp: new Date(Date.now() - 3600000), status: 'viewed' },
        vitalsHistory: generatePatientHistory(),
        prescriptions: mockPrescriptions.filter(p => p.patientId === 'patient-jane-smith'),
        appointments: mockAppointments.filter(a => a.patientId === 'patient-jane-smith'),
        voiceNotes: mockVoiceNotes['patient-jane-smith'] || [],
    },
    {
        id: 'patient-robert-jones',
        name: 'Robert Jones',
        age: 81,
        avatarUrl: 'https://picsum.photos/id/1005/100',
        lastVitals: { time: '10:45 AM', heartRate: 110, spo2: 96, systolicBP: 128, diastolicBP: 82, temperature: 37.3 },
        riskLevel: RiskLevel.High,
        lastAlert: { id: 'a2', type: AlertType.HIGH_HEART_RATE, value: '115 BPM', threshold: '>100 BPM', timestamp: new Date(Date.now() - 600000), status: 'new' },
        vitalsHistory: generatePatientHistory(),
        prescriptions: mockPrescriptions.filter(p => p.patientId === 'patient-robert-jones'),
        appointments: mockAppointments.filter(a => a.patientId === 'patient-robert-jones'),
        voiceNotes: mockVoiceNotes['patient-robert-jones'] || [],
    },
    {
        id: 'patient-mary-williams',
        name: 'Mary Williams',
        age: 76,
        avatarUrl: 'https://picsum.photos/id/1014/100',
        lastVitals: { time: '10:50 AM', heartRate: 78, spo2: 99, systolicBP: 118, diastolicBP: 78, temperature: 36.9 },
        riskLevel: RiskLevel.Low,
        vitalsHistory: generatePatientHistory(),
        prescriptions: mockPrescriptions.filter(p => p.patientId === 'patient-mary-williams'),
        appointments: mockAppointments.filter(a => a.patientId === 'patient-mary-williams'),
        voiceNotes: mockVoiceNotes['patient-mary-williams'] || [],
    },
     {
        id: 'patient-sarah-doe',
        name: 'Sarah Doe',
        age: 68,
        avatarUrl: 'https://picsum.photos/id/1025/100',
        lastVitals: generateNewVitals(),
        riskLevel: RiskLevel.Low,
        vitalsHistory: generatePatientHistory(),
        sharedNotes: mockSharedNotes['patient-sarah-doe'] || []
    }
];


// --- New Mock Data for Features ---

export const mockMedications: Medication[] = [
    { id: 'med1', name: 'Lisinopril', dosage: '10mg', frequency: 'Once a day', time: ['08:00'], status: 'taken' },
    { id: 'med2', name: 'Metformin', dosage: '500mg', frequency: 'Twice a day', time: ['08:00', '20:00'], status: 'due' },
    { id: 'med3', name: 'Atorvastatin', dosage: '20mg', frequency: 'Once a day', time: ['20:00'], status: 'due' },
    { id: 'med4', name: 'Aspirin', dosage: '81mg', frequency: 'Once a day', time: ['08:00'], status: 'skipped' },
];

export const mockLabReports: LabReport[] = [
    { id: 'rep1', name: 'Annual Blood Panel', type: 'Blood Test', date: new Date('2024-06-15'), summary: 'All markers within normal range. Slightly elevated cholesterol, recommend diet monitoring.' },
    { id: 'rep2', name: 'Resting ECG', type: 'ECG', date: new Date('2024-05-20'), summary: 'Normal sinus rhythm. No significant abnormalities detected.' },
    { id: 'rep3', name: 'Knee MRI', type: 'MRI Scan', date: new Date('2024-03-10'), summary: 'Minor cartilage wear consistent with age. No acute injuries.' },
];

export const mockLifestyleData: LifestyleData = {
    steps: { current: 6540, goal: 8000 },
    sleep: { hours: 7.5, goal: 8 },
    calories: { current: 1850, goal: 2000 },
};

export const mockGamificationData: GamificationData = {
    points: 1250,
    badges: [
        { id: 'b1', nameKey: 'gamification.badges.earlyBird.name', descriptionKey: 'gamification.badges.earlyBird.description', icon: 'Medication', earned: true, earnedDate: new Date('2024-07-10') },
        { id: 'b2', nameKey: 'gamification.badges.stepMaster.name', descriptionKey: 'gamification.badges.stepMaster.description', icon: 'Steps', earned: true, earnedDate: new Date('2024-07-15') },
        { id: 'b3', nameKey: 'gamification.badges.wellRested.name', descriptionKey: 'gamification.badges.wellRested.description', icon: 'Sleep', earned: true, earnedDate: new Date('2024-07-20') },
        { id: 'b4', nameKey: 'gamification.badges.firstScan.name', descriptionKey: 'gamification.badges.firstScan.description', icon: 'Scan', earned: true, earnedDate: new Date('2024-07-05') },
        { id: 'b5', nameKey: 'gamification.badges.aiCurious.name', descriptionKey: 'gamification.badges.aiCurious.description', icon: 'AIChat', earned: false },
        { id: 'b6', nameKey: 'gamification.badges.perfectWeek.name', descriptionKey: 'gamification.badges.perfectWeek.description', icon: 'Calendar', earned: false },
    ]
};