
import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { mockGamificationData } from '../data/mockData';
import type { Badge } from '../types';

const PageHeader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-white tracking-tight">{t('gamification.header')}</h1>
            <p className="text-slate-400 mt-1">{t('gamification.subHeader')}</p>
        </div>
    </div>
);

const BadgeIcon = ({ name, className }: { name: string; className?: string }) => {
    const icons: { [key: string]: React.ReactNode } = {
        Medication: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M10 2a.75.75 0 01.75.75v.518a3.75 3.75 0 012.385 2.113l.36.623a.75.75 0 01-.65 1.125H6.156a.75.75 0 01-.65-1.125l.36-.623A3.75 3.75 0 018.25 3.268V2.75A.75.75 0 0110 2z" /><path fillRule="evenodd" d="M3.75 7.5A1.75 1.75 0 002 9.25v5A1.75 1.75 0 003.75 16h12.5A1.75 1.75 0 0018 14.25v-5A1.75 1.75 0 0016.25 7.5H3.75zm.75 2.5a.75.75 0 000 1.5h11a.75.75 0 000-1.5h-11z" clipRule="evenodd" /></svg>,
        Steps: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.47 5.47a.75.75 0 011.06 0L8 6.94l1.47-1.47a.75.75 0 111.06 1.06L9.06 8l1.47 1.47a.75.75 0 11-1.06 1.06L8 9.06l-1.47 1.47a.75.75 0 01-1.06-1.06L6.94 8 5.47 6.53a.75.75 0 010-1.06z" clipRule="evenodd" /></svg>,
        Sleep: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9.53 2.47a.75.75 0 01.94 0l7 7a.75.75 0 01-1.06 1.06L10 4.06 3.53 10.53a.75.75 0 01-1.06-1.06l7-7z" clipRule="evenodd" /></svg>,
        Scan: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" /><path fillRule="evenodd" d="M.664 10.59a1.651 1.651 0 010-1.186A10.004 10.004 0 0110 3c4.257 0 7.893 2.66 9.336 6.41.147.381.146.804 0 1.186A10.004 10.004 0 0110 17c-4.257 0-7.893-2.66-9.336-6.41zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" /></svg>,
        AIChat: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 2c-1.717 0-3.417.34-5.015.966a.75.75 0 00-.516.906l.163.543a.75.75 0 00.906.516A6.983 6.983 0 0110 4c1.42 0 2.76.42 3.962 1.15a.75.75 0 00.906-.516l.163-.543a.75.75 0 00-.516-.906A8.48 8.48 0 0010 2zM3.473 6.912a.75.75 0 00-.516-.906l-.543-.163a.75.75 0 00-.906.516C.34 8.583 0 10.283 0 12c0 1.717.34 3.417.966 5.015a.75.75 0 00.906.516l.543-.163a.75.75 0 00.516-.906A6.983 6.983 0 014 12c0-1.42.42-2.76 1.15-3.962a.75.75 0 00-.676-1.126zM10 6a4 4 0 100 8 4 4 0 000-8z" clipRule="evenodd" /></svg>,
        Calendar: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.75 2a.75.75 0 01.75.75V4h7V2.75a.75.75 0 011.5 0V4h.25A2.75 2.75 0 0118 6.75v8.5A2.75 2.75 0 0115.25 18H4.75A2.75 2.75 0 012 15.25v-8.5A2.75 2.75 0 014.75 4H5V2.75A.75.75 0 015.75 2zM4.5 8.25a.75.75 0 000 1.5h11a.75.75 0 000-1.5h-11z" clipRule="evenodd" /></svg>,
    };
    return <div className={className}>{icons[name] || null}</div>;
};


const BadgeCard = ({ badge, t }: { badge: Badge, t: (key: string, options?: any) => string }) => {
    const isEarned = badge.earned;
    const badgeColor = isEarned ? 'bg-cyan-500/10 border-cyan-500/30' : 'bg-slate-700/40 border-slate-700';
    const textColor = isEarned ? 'text-white' : 'text-slate-400';
    const iconColor = isEarned ? 'text-cyan-400' : 'text-slate-500';

    return (
        <div className={`border rounded-lg p-4 flex flex-col items-center text-center transition-all duration-300 ${badgeColor} ${!isEarned ? 'grayscale hover:grayscale-0' : ''}`}>
            <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-3 ${isEarned ? 'bg-slate-700' : 'bg-slate-800'}`}>
                <BadgeIcon name={badge.icon} className={`w-8 h-8 ${iconColor}`} />
            </div>
            <h4 className={`font-bold text-lg ${textColor}`}>{t(badge.nameKey)}</h4>
            <p className="text-sm text-slate-400 flex-grow">{t(badge.descriptionKey)}</p>
            {isEarned && badge.earnedDate && (
                <p className="text-xs text-cyan-400 mt-2">{t('gamification.earnedOn', { date: badge.earnedDate.toLocaleDateString() })}</p>
            )}
        </div>
    );
};

const Gamification = (): React.ReactNode => {
    const { t } = useLanguage();
    const { points, badges } = mockGamificationData;

    const earnedBadges = badges.filter(b => b.earned);
    const lockedBadges = badges.filter(b => !b.earned);

    return (
        <>
            <PageHeader t={t} />
            <div className="space-y-8">
                <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg p-6 shadow-lg text-center animate-fadeInUp animation-delay-100">
                    <h2 className="text-lg font-semibold text-slate-300">{t('gamification.pointsTitle')}</h2>
                    <p className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 my-2">
                        {points.toLocaleString()}
                    </p>
                    <p className="text-slate-400 font-semibold">PTS</p>
                </div>

                <div className="animate-fadeInUp animation-delay-200">
                    <h3 className="text-2xl font-bold text-white mb-4">{t('gamification.earnedBadges')}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {earnedBadges.map(badge => (
                            <BadgeCard key={badge.id} badge={badge} t={t} />
                        ))}
                    </div>
                </div>

                 <div className="animate-fadeInUp animation-delay-300">
                    <h3 className="text-2xl font-bold text-white mb-4">{t('gamification.lockedBadges')}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                         {lockedBadges.map(badge => (
                            <BadgeCard key={badge.id} badge={badge} t={t} />
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
};

export default Gamification;