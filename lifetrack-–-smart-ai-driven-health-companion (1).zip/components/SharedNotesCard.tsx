
import React, { useState } from 'react';
import { Patient, User, UserRole } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { useUser } from '../contexts/UserContext';
import { patientDataService } from '../services/patientDataService';
import { ICONS } from '../constants';
import { formatDistanceToNow } from 'date-fns';

interface SharedNotesCardProps {
    patient: Patient;
    maxHeight?: string;
}

const getRoleBadgeStyle = (role: UserRole) => {
    switch (role) {
        case 'Doctor':
            return 'bg-cyan-500/20 text-cyan-300';
        case 'Caregiver':
            return 'bg-indigo-500/20 text-indigo-300';
        case 'Patient':
            return 'bg-green-500/20 text-green-300';
        default:
            return 'bg-slate-500/20 text-slate-300';
    }
};

const SharedNotesCard = ({ patient, maxHeight = 'max-h-96' }: SharedNotesCardProps): React.ReactNode => {
    const { t } = useLanguage();
    const { user } = useUser();
    const [newNote, setNewNote] = useState('');

    const handleAddNote = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newNote.trim() || !user) return;
        patientDataService.addSharedNote(patient.id, newNote, user);
        setNewNote('');
    };

    return (
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg h-full flex flex-col">
            <div className="p-6 border-b border-slate-700/50">
                 <h3 className="text-lg font-semibold text-white flex items-center">
                    <div className="mr-3">{ICONS.sharedNotes}</div>
                    {t('sharedNotes.cardTitle')}
                </h3>
            </div>
            
            <div className={`flex-grow p-6 space-y-4 overflow-y-auto ${maxHeight}`}>
                {patient.sharedNotes && patient.sharedNotes.length > 0 ? (
                    patient.sharedNotes.map(note => (
                        <div key={note.id} className="flex items-start space-x-3">
                            <div className={`mt-1 text-xs font-bold px-2 py-0.5 rounded-full whitespace-nowrap ${getRoleBadgeStyle(note.authorRole)}`}>
                                {note.authorRole}
                            </div>
                            <div className="flex-1 bg-slate-700/40 rounded-lg p-3">
                                <div className="flex justify-between items-baseline">
                                    <p className="text-sm font-semibold text-white">{note.authorName}</p>
                                    <p className="text-xs text-slate-400">
                                        {formatDistanceToNow(note.timestamp, { addSuffix: true })}
                                    </p>
                                </div>
                                <p className="text-sm text-slate-300 mt-1">{note.text}</p>
                            </div>
                        </div>
                    ))
                ) : (
                     <div className="text-center py-8 text-slate-500">
                        <p>No shared notes yet.</p>
                    </div>
                )}
            </div>

            <div className="p-4 bg-slate-800/60 border-t border-slate-700/50">
                <form onSubmit={handleAddNote} className="flex items-center space-x-2">
                    <input
                        type="text"
                        value={newNote}
                        onChange={(e) => setNewNote(e.target.value)}
                        placeholder={t('sharedNotes.addNotePlaceholder')}
                        className="flex-grow bg-slate-700 border border-slate-600 rounded-lg py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                    <button
                        type="submit"
                        disabled={!newNote.trim()}
                        className="bg-cyan-500 text-white font-bold p-2 rounded-lg hover:bg-cyan-600 transition-colors disabled:bg-slate-600 disabled:cursor-not-allowed"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.428A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
                    </button>
                </form>
            </div>
        </div>
    );
};

export default SharedNotesCard;
