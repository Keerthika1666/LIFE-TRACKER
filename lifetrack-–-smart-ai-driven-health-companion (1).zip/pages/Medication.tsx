


import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { mockMedications } from '../data/mockData';
import { Medication as MedicationType } from '../types';

const PageHeader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{t('medication.header')}</h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">{t('medication.subHeader')}</p>
        </div>
    </div>
);

const statusStyles = {
    due: { icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z', color: 'text-yellow-500 dark:text-yellow-400', bg: 'bg-yellow-500/10' },
    taken: { icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z', color: 'text-green-500 dark:text-green-400', bg: 'bg-green-500/10' },
    skipped: { icon: 'M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636', color: 'text-red-500 dark:text-red-400', bg: 'bg-red-500/10' },
};

// Fix: Completed the MedicationCard component function definition and implementation.
const MedicationCard = ({ med, onUpdateStatus, t }: { med: MedicationType, onUpdateStatus: (id: string, status: 'taken' | 'skipped') => void, t: (key: string, options?: any) => string }) => {
    const styles = statusStyles[med.status];
    
    return (
        <div className={`rounded-lg shadow-lg p-5 flex flex-col justify-between transition-all duration-300 ${styles.bg}`}>
            <div>
                <div className="flex justify-between items-start">
                    <div>
                        <h3 className="text-xl font-bold text-slate-800 dark:text-white">{med.name}</h3>
                        <p className="text-slate-500 dark:text-slate-400">{med.dosage} &bull; {med.frequency}</p>
                    </div>
                    <div className={`text-2xl ${styles.color}`}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={styles.icon} /></svg>
                    </div>
                </div>
                <div className="mt-4 flex items-center space-x-2">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-400" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.414-1.414L11 9.586V6z" clipRule="evenodd" /></svg>
                     <p className="text-slate-600 dark:text-slate-300 font-semibold">{med.time.join(', ')}</p>
                </div>
            </div>
            
            <div className="mt-5 border-t border-slate-200 dark:border-slate-700 pt-4">
                {med.status === 'due' ? (
                    <div className="flex space-x-2">
                        <button onClick={() => onUpdateStatus(med.id, 'skipped')} className="w-full py-2 px-3 text-sm font-semibold bg-slate-200 dark:bg-slate-600/50 text-slate-700 dark:text-slate-200 rounded-md hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors">{t('medication.actions.skip')}</button>
                        <button onClick={() => onUpdateStatus(med.id, 'taken')} className="w-full py-2 px-3 text-sm font-semibold bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors">{t('medication.actions.take')}</button>
                    </div>
                ) : (
                    <p className={`text-center font-bold text-lg ${styles.color}`}>{t(`medication.status.${med.status}`)}</p>
                )}
            </div>
        </div>
    );
};


const Medication = (): React.ReactNode => {
    const { t } = useLanguage();
    const [medications, setMedications] = useState<MedicationType[]>(mockMedications);

    const handleUpdateStatus = (id: string, status: 'taken' | 'skipped') => {
        setMedications(meds => meds.map(med => med.id === id ? { ...med, status } : med));
    };

    const categorizeMeds = (meds: MedicationType[]) => {
        const morning: MedicationType[] = [];
        const evening: MedicationType[] = [];
        
        meds.forEach(med => {
            const isMorning = med.time.some(t => parseInt(t.split(':')[0], 10) < 12);
            if(isMorning) {
                morning.push(med);
            } else {
                evening.push(med);
            }
        });
        
        return { morning, evening };
    };

    const { morning, evening } = categorizeMeds(medications);

    return (
        <>
            <PageHeader t={t} />
            <div className="space-y-8">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4 animate-fadeInUp animation-delay-100">{t('medication.morning')}</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {morning.map((med, index) => (
                             <div key={med.id} className={`animate-fadeInUp`} style={{ animationDelay: `${200 + index * 100}ms` }}>
                                <MedicationCard med={med} onUpdateStatus={handleUpdateStatus} t={t} />
                            </div>
                        ))}
                    </div>
                </div>
                 <div>
                    <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4 animate-fadeInUp animation-delay-400">{t('medication.evening')}</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                         {evening.map((med, index) => (
                             <div key={med.id} className={`animate-fadeInUp`} style={{ animationDelay: `${500 + index * 100}ms` }}>
                                <MedicationCard med={med} onUpdateStatus={handleUpdateStatus} t={t} />
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
};

export default Medication;
