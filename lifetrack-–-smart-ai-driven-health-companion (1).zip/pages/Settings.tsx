


import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useSettings } from '../contexts/SettingsContext';
import { useUser } from '../contexts/UserContext';
import { useTheme } from '../contexts/ThemeContext';

const PageHeader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{t('settings.header')}</h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">{t('settings.subHeader')}</p>
        </div>
    </div>
);

const SettingsCard = ({ title, description, children, actionButton }: { title: string, description?: string, children: React.ReactNode, actionButton?: React.ReactNode}) => (
    <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg animate-fadeInUp">
        <div className="p-6 flex justify-between items-start">
            <div>
                <h3 className="text-xl font-bold text-slate-800 dark:text-white">{title}</h3>
                {description && <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">{description}</p>}
            </div>
            {actionButton}
        </div>
        <div className="bg-slate-100/80 dark:bg-slate-800/50 px-6 py-4">
            {children}
        </div>
    </div>
);

const ToggleSwitch = ({ label, enabled, setEnabled }: { label: string, enabled: boolean, setEnabled: (enabled: boolean) => void }) => (
    <div className="flex items-center justify-between py-3">
        <span className="text-slate-600 dark:text-slate-300">{label}</span>
        <button
            onClick={() => setEnabled(!enabled)}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 focus:ring-cyan-500 ${enabled ? 'bg-cyan-500' : 'bg-slate-400 dark:bg-slate-600'}`}
        >
            <span
                className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform duration-300 ${enabled ? 'translate-x-6' : 'translate-x-1'}`}
            />
        </button>
    </div>
);

const ThresholdSlider = ({ label, value, setValue, min, max, unit }: { label: string, value: number, setValue: (value: number) => void, min: number, max: number, unit: string}) => (
    <div className="py-3">
        <div className="flex justify-between items-center mb-2">
            <label className="text-slate-600 dark:text-slate-300">{label}</label>
            <span className="text-lg font-semibold text-cyan-600 dark:text-cyan-400">{value} {unit}</span>
        </div>
        <input
            type="range"
            min={min}
            max={max}
            value={value}
            onChange={(e) => setValue(Number(e.target.value))}
            className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
        />
    </div>
);

const ThresholdView = ({ label, value, unit }: { label: string, value: number, unit: string }) => (
     <div className="flex items-center justify-between py-4">
        <span className="text-slate-600 dark:text-slate-300">{label}</span>
        <span className="text-lg font-bold text-slate-800 dark:text-white">{value} {unit}</span>
    </div>
);


const Settings = (): React.ReactNode => {
    const { language, setLanguage, t } = useLanguage();
    const { theme, toggleTheme } = useTheme();
    const {
      heartRateThreshold, setHeartRateThreshold,
      spo2Threshold, setSpo2Threshold,
      smsAlerts, setSmsAlerts,
      emailAlerts, setEmailAlerts
    } = useSettings();
    const { user } = useUser();
    
    const [isEditingThresholds, setIsEditingThresholds] = useState(false);
    const [tempThresholds, setTempThresholds] = useState({ heartRate: heartRateThreshold, spo2: spo2Threshold });

    const handleEditThresholds = () => {
        setTempThresholds({ heartRate: heartRateThreshold, spo2: spo2Threshold });
        setIsEditingThresholds(true);
    };

    const handleSaveThresholds = () => {
        setHeartRateThreshold(tempThresholds.heartRate);
        setSpo2Threshold(tempThresholds.spo2);
        setIsEditingThresholds(false);
    };

    const handleCancelThresholds = () => {
        setIsEditingThresholds(false);
    };
    
    return (
        <>
            <PageHeader t={t} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                <SettingsCard title={t('settings.profile.title')} description={t('settings.profile.description')}>
                    <div className="space-y-4">
                        {user?.role === 'Doctor' ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="name" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('settings.profile.name')}</label>
                                    <input type="text" id="name" defaultValue={user?.name} className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm" />
                                </div>
                                <div>
                                    <label htmlFor="specialization" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('settings.profile.specialization')}</label>
                                    <input type="text" id="specialization" defaultValue="Cardiology" className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm" />
                                </div>
                                <div className="md:col-span-2">
                                    <label htmlFor="clinic" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('settings.profile.clinic')}</label>
                                    <input type="text" id="clinic" defaultValue="City General Hospital" className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm" />
                                </div>
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="name" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('settings.profile.name')}</label>
                                    <input type="text" id="name" defaultValue={user?.name} className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm" />
                                </div>
                                <div>
                                    <label htmlFor="dob" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('settings.profile.dob')}</label>
                                    <input type="date" id="dob" defaultValue="1965-07-15" className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm" />
                                </div>
                                <div>
                                    <label htmlFor="gender" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('settings.profile.gender')}</label>
                                    <select id="gender" className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm">
                                        <option>Male</option>
                                        <option>Female</option>
                                        <option>Other</option>
                                        <option>Prefer not to say</option>
                                    </select>
                                </div>
                                <div>
                                    <label htmlFor="phone" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('settings.profile.phone')}</label>
                                    <input type="tel" id="phone" defaultValue="+1 (555) 123-4567" className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm" />
                                </div>
                                <div className="md:col-span-2">
                                    <label htmlFor="email" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('settings.profile.email')}</label>
                                    <input type="email" id="email" defaultValue="john.doe@example.com" className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm" />
                                </div>
                                <div className="md:col-span-2">
                                    <label htmlFor="address" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('settings.profile.address')}</label>
                                    <textarea id="address" rows={3} defaultValue="123 Health St, Wellness City, 90210" className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm resize-none"></textarea>
                                </div>
                            </div>
                        )}
                        <div className="text-right pt-2">
                           <button className="px-4 py-2 text-sm font-medium bg-cyan-500 rounded-md hover:bg-cyan-600 transition-colors text-white">{t('common.saveChanges')}</button>
                        </div>
                    </div>
                </SettingsCard>

                <SettingsCard title={t('settings.alerts.title')} description={t('settings.alerts.description')}>
                    <div className="divide-y divide-slate-200 dark:divide-slate-700">
                        <ToggleSwitch label={t('settings.alerts.sms')} enabled={smsAlerts} setEnabled={setSmsAlerts} />
                        <ToggleSwitch label={t('settings.alerts.email')} enabled={emailAlerts} setEnabled={setEmailAlerts} />
                    </div>
                </SettingsCard>
                
                {user?.role === 'Patient' && (
                    <SettingsCard 
                        title={t('settings.thresholds.title')} 
                        description={t('settings.thresholds.description')}
                        actionButton={!isEditingThresholds && (
                            <button onClick={handleEditThresholds} className="px-4 py-2 text-sm font-medium bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-md hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors">{t('common.edit')}</button>
                        )}
                    >
                        {isEditingThresholds ? (
                            <>
                                <div className="divide-y divide-slate-200 dark:divide-slate-700">
                                    <ThresholdSlider label={t('settings.thresholds.hr')} value={tempThresholds.heartRate} setValue={(v) => setTempThresholds(t => ({...t, heartRate: v}))} min={80} max={140} unit={t('overview.units.bpm')} />
                                    <ThresholdSlider label={t('settings.thresholds.spo2')} value={tempThresholds.spo2} setValue={(v) => setTempThresholds(t => ({...t, spo2: v}))} min={85} max={95} unit={t('overview.units.percent')} />
                                </div>
                                <div className="flex justify-end space-x-3 pt-4">
                                    <button onClick={handleCancelThresholds} className="px-4 py-2 text-sm font-medium bg-slate-500 dark:bg-slate-600 text-white rounded-md hover:bg-slate-600 dark:hover:bg-slate-700 transition-colors">{t('common.cancel')}</button>
                                    <button onClick={handleSaveThresholds} className="px-4 py-2 text-sm font-medium bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors">{t('common.saveChanges')}</button>
                                </div>
                            </>
                        ) : (
                            <div className="divide-y divide-slate-200 dark:divide-slate-700">
                                <ThresholdView label={t('settings.thresholds.hr')} value={heartRateThreshold} unit={t('overview.units.bpm')} />
                                <ThresholdView label={t('settings.thresholds.spo2')} value={spo2Threshold} unit={t('overview.units.percent')} />
                            </div>
                        )}
                    </SettingsCard>
                )}

                <SettingsCard title={t('settings.app.title')} description={t('settings.app.description')}>
                    <div className="divide-y divide-slate-200 dark:divide-slate-700">
                       <div className="py-3 flex items-center justify-between">
                            <span className="text-slate-600 dark:text-slate-300">{t('settings.app.theme')}</span>
                            <div className="flex space-x-2">
                                <button onClick={() => theme === 'light' && toggleTheme()} className={`px-3 py-1 text-sm rounded-md ${theme === 'dark' ? 'bg-cyan-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600'}`}>{t('settings.app.themeDark')}</button>
                                <button onClick={() => theme === 'dark' && toggleTheme()} className={`px-3 py-1 text-sm rounded-md ${theme === 'light' ? 'bg-cyan-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600'}`}>{t('settings.app.themeLight')}</button>
                            </div>
                       </div>
                        <div className="py-3 flex items-center justify-between">
                            <span className="text-slate-600 dark:text-slate-300">{t('settings.app.language')}</span>
                             <select 
                                value={language}
                                onChange={(e) => setLanguage(e.target.value as 'en' | 'ta')}
                                className="bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md py-1 px-2 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 text-sm"
                            >
                                <option value="en">English</option>
                                <option value="ta">தமிழ்</option>
                            </select>
                        </div>
                    </div>
                </SettingsCard>

            </div>
        </>
    );
};

export default Settings;