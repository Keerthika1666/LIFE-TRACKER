import React from 'react';

interface CardProps {
    title: string;
    description: string;
    icon: React.ReactNode;
    children: React.ReactNode;
    animationDelay?: number;
}

const Card = ({ title, description, icon, children, animationDelay = 100 }: CardProps): React.ReactNode => {
    return (
        <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg animate-fadeInUp h-full flex flex-col" style={{ animationDelay: `${animationDelay}ms` }}>
            <div className="p-6 flex items-center space-x-4">
                 <div className="flex-shrink-0 w-12 h-12 bg-slate-100 dark:bg-slate-700 rounded-full flex items-center justify-center text-cyan-500 dark:text-cyan-400">
                    {icon}
                </div>
                <div>
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white">{title}</h3>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">{description}</p>
                </div>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/60 px-6 py-6 flex-grow flex flex-col">
                {children}
            </div>
        </div>
    );
};

export default Card;