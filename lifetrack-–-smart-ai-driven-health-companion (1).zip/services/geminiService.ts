

import { GoogleGenAI, Chat } from "@google/genai";
import type { Prediction, VitalData, Patient } from '../types';
import { RiskLevel } from '../types';

// Assume API_KEY is available in the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getHealthPrediction = async (latestVitals: VitalData): Promise<Prediction> => {
    // Simulate a brief network delay to allow the loading spinner to be visible
    await new Promise(resolve => setTimeout(resolve, 300 + Math.random() * 400));

    const { heartRate, spo2, temperature } = latestVitals;

    // --- Rule-based Risk Assessment ---
    // This logic mirrors the instructions previously sent to the AI model.
    // 0: Low, 1: Medium, 2: High
    let hrRisk = 0;
    if (heartRate > 120 || heartRate < 50) hrRisk = 2;
    else if (heartRate > 100 || heartRate < 60) hrRisk = 1;

    let spo2Risk = 0;
    if (spo2 <= 90) spo2Risk = 2;
    else if (spo2 <= 94) spo2Risk = 1;

    let tempRisk = 0;
    if (temperature > 38.5 || temperature < 35.0) tempRisk = 2;
    else if (temperature > 37.5 || temperature < 36.5) tempRisk = 1;

    const maxRisk = Math.max(hrRisk, spo2Risk, tempRisk);
    
    let riskLevel: RiskLevel = RiskLevel.Low;
    let prediction = 'Vitals appear stable and within normal ranges.';

    switch (maxRisk) {
        case 2: // High Risk
            riskLevel = RiskLevel.High;
            if (hrRisk === 2) prediction = `Heart rate at ${heartRate} BPM is critically abnormal.`;
            else if (spo2Risk === 2) prediction = `Oxygen saturation at ${spo2}% is critically low.`;
            else if (tempRisk === 2) prediction = `Body temperature at ${temperature}°C is at a critical level.`;
            break;
        case 1: // Medium Risk
            riskLevel = RiskLevel.Medium;
            if (hrRisk === 1) prediction = `Heart rate at ${heartRate} BPM is outside the optimal range.`;
            else if (spo2Risk === 1) prediction = `Oxygen saturation at ${spo2}% is slightly low.`;
            else if (tempRisk === 1) prediction = `Body temperature at ${temperature}°C is slightly abnormal.`;
            break;
        default: // Low Risk
            riskLevel = RiskLevel.Low;
            break;
    }

    return { riskLevel, prediction };
};


export const getPatientSummary = async (patient: Patient): Promise<string> => {
    // Summarize vitals to avoid a huge prompt
    const summarizeVitals = (history: VitalData[]) => {
        if (history.length === 0) return "No recent vitals history.";
        const vitals: Record<string, number[]> = {
            heartRate: [],
            spo2: [],
            temperature: []
        };
        history.forEach(v => {
            vitals.heartRate.push(v.heartRate);
            vitals.spo2.push(v.spo2);
            vitals.temperature.push(v.temperature);
        });

        const stats = (arr: number[]) => {
            if (arr.length === 0) return { min: 'N/A', max: 'N/A', avg: 'N/A' };
            const min = Math.min(...arr);
            const max = Math.max(...arr);
            const avg = Math.round(arr.reduce((a, b) => a + b) / arr.length);
            return { min, max, avg };
        };

        const hrStats = stats(vitals.heartRate);
        const spo2Stats = stats(vitals.spo2);
        const tempStats = stats(vitals.temperature);

        return `
- Heart Rate: Avg ${hrStats.avg}, Min ${hrStats.min}, Max ${hrStats.max} BPM.
- SpO₂: Avg ${spo2Stats.avg}, Min ${spo2Stats.min}, Max ${spo2Stats.max} %.
- Temperature: Avg ${tempStats.avg}, Min ${tempStats.min}, Max ${tempStats.max} °C.
        `;
    };

    const vitalsSummary = summarizeVitals(patient.vitalsHistory);
    const lastAlertInfo = patient.lastAlert ? `The most recent alert was for '${patient.lastAlert.type}' with a value of ${patient.lastAlert.value} on ${patient.lastAlert.timestamp.toLocaleString()}.` : "No significant alerts in the recent period.";

    const prompt = `
Generate a concise clinical summary for a doctor about the patient, ${patient.name}, a ${patient.age}-year-old.
Based on the data from the last 24 hours, provide a brief overview highlighting any notable trends, events, or potential concerns.
The current risk assessment for the patient is '${patient.riskLevel}'.

Patient Data:
- Vitals Summary (24h):
${vitalsSummary}
- Last Alert: ${lastAlertInfo}
- Current Vitals: Heart Rate: ${patient.lastVitals.heartRate} BPM, SpO₂: ${patient.lastVitals.spo2}%, BP: ${patient.lastVitals.systolicBP}/${patient.lastVitals.diastolicBP} mmHg, Temp: ${patient.lastVitals.temperature}°C.

Instructions:
- Be concise and professional.
- Use bullet points for key observations.
- Start with a one-sentence overview.
- Mention any vitals that are currently outside of normal ranges (e.g., HR > 100 or < 60, SpO2 < 95%).
- Conclude with a brief assessment or recommendation.
- Do not add any disclaimers like "I am not a doctor". The context is doctor-to-doctor communication.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction: "You are an expert medical AI assistant. Your role is to analyze patient data and provide clear, concise summaries for healthcare professionals.",
                temperature: 0.3,
            }
        });

        return response.text.trim();

    } catch (error: any) {
        console.error("Error fetching patient summary from Gemini API:", error);
        return 'Could not retrieve AI summary at this time. Please check the connection or API status.';
    }
};


class ChatService {
    private chat: Chat | null = null;

    startChatSession(latestVitals: VitalData | null) {
        const vitalsContext = latestVitals 
            ? `Here is the user's current vitals data for context: ${JSON.stringify(latestVitals)}. Use this data when answering relevant questions.`
            : "The user's vitals data is not available right now.";

        this.chat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: `You are an AI health assistant for the LifeTrack application. Your persona is helpful, empathetic, and reassuring.
- Provide clear, easy-to-understand health information. Use simple language.
- Structure your responses for maximum readability. Use paragraphs for explanations, bullet points (*) for lists, and bold text (**) for important terms.
- You MUST NOT provide medical advice. Your role is to explain health concepts and the user's data, not to diagnose or treat.
- ALWAYS end your responses with a disclaimer: "Remember, I am an AI assistant and not a medical professional. Please consult your doctor for any medical advice."
- The user's name is John Doe. Their current vitals are available for context: ${vitalsContext}.`,
            },
        });
    }

    async sendMessageStream(message: string) {
        if (!this.chat) {
            throw new Error("Chat session not started.");
        }
        return this.chat.sendMessageStream({ message });
    }
}
export const chatService = new ChatService();


// Service for Doctor to Patient chat, where AI role-plays as the patient.
const doctorChatSessions = new Map<string, Chat>();

const getDoctorPatientChatSession = (patient: Patient): Chat => {
    if (doctorChatSessions.has(patient.id)) {
        return doctorChatSessions.get(patient.id)!;
    }

    const systemInstruction = `You are role-playing as a patient named ${patient.name}, who is ${patient.age} years old. Their current health risk level is '${patient.riskLevel}'. Their most recent health alert was for '${patient.lastAlert?.type || 'nothing significant'}'. Your responses should be consistent with this profile. You are speaking with your doctor. Keep your responses conversational, brief, and not overly technical. Do not break character.`;

    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction,
        },
    });
    
    doctorChatSessions.set(patient.id, chat);
    return chat;
};

export const doctorChatService = {
    async sendMessage(patient: Patient, message: string) {
        const chat = getDoctorPatientChatSession(patient);
        return chat.sendMessageStream({ message });
    }
};

export const getDailyHealthTip = async (): Promise<string> => {
    const prompt = "Provide a concise, actionable, and encouraging health tip for the day suitable for an elderly user. Focus on topics like nutrition, light exercise, mental well-being, or hydration. Make it easy to understand.";

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction: "You are a friendly and wise AI health assistant providing daily wellness tips.",
                temperature: 0.8,
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error fetching health tip from Gemini API:", error);
        const fallbackTips = [
            "Remember to drink plenty of water throughout the day to stay hydrated.",
            "A short 10-minute walk can boost your energy and improve your mood.",
            "Try to get 7-8 hours of quality sleep each night for better health.",
            "Eating a balanced diet with fruits and vegetables is key to a healthy lifestyle.",
            "Take a few minutes to stretch your body, especially if you've been sitting for a while."
        ];
        const randomIndex = Math.floor(Math.random() * fallbackTips.length);
        return fallbackTips[randomIndex];
    }
};


export const getVoiceCommandResponse = async (command: string, vitals: VitalData | null): Promise<string> => {
    const vitalsContext = vitals ? `Current vitals for context: ${JSON.stringify(vitals)}` : "Vitals data is not available.";

    const prompt = `
        The user has issued a voice command: "${command}".
        ${vitalsContext}
        Based on this, provide a direct and helpful response as if you are a voice assistant in a health app.
        - If asked for data (e.g., "What is my current heart rate?"), extract it from the context and state it clearly.
        - If asked for a summary (e.g., "Summarize my health"), provide a brief, positive overview based on the vitals.
        - If asked for general advice, give a safe, generic wellness tip.
        - Keep the response conversational and relatively short.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction: "You are the voice of the LifeTrack AI Health Companion. Respond to user commands clearly and concisely.",
                temperature: 0.5,
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error processing voice command with Gemini API:", error);
        return "I'm sorry, I couldn't process that request right now.";
    }
};