

import React, { useState } from 'react';
import { Patient, Prescription } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface PrescriptionModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (prescription: Omit<Prescription, 'id' | 'patientName' | 'dateIssued' | 'status'>) => void;
    patient: Patient;
}

const PrescriptionModal = ({ isOpen, onClose, onSave, patient }: PrescriptionModalProps) => {
    const { t } = useLanguage();
    const [medicationName, setMedicationName] = useState('');
    const [dosage, setDosage] = useState('');
    const [frequency, setFrequency] = useState('');
    const [error, setError] = useState('');

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!medicationName.trim() || !dosage.trim() || !frequency.trim()) {
            setError('All fields are required.');
            return;
        }
        onSave({ patientId: patient.id, medicationName, dosage, frequency });
        // Reset form
        setMedicationName('');
        setDosage('');
        setFrequency('');
        setError('');
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-6 w-full max-w-md border border-slate-300 dark:border-slate-700 animate-fadeInUp" onClick={(e) => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-4">{t('doctor.prescriptions.modal.title')}</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('doctor.prescriptions.modal.patientLabel')}</label>
                            <input type="text" value={patient.name} readOnly className="mt-1 block w-full bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md py-2 px-3 text-slate-500 dark:text-slate-300 sm:text-sm" />
                        </div>
                         <div>
                            <label htmlFor="medication-name" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('doctor.prescriptions.modal.medicationLabel')}</label>
                            <input
                                type="text" id="medication-name" value={medicationName} onChange={(e) => setMedicationName(e.target.value)}
                                className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                                placeholder={t('doctor.prescriptions.modal.medicationPlaceholder')} autoFocus
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="dosage" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('doctor.prescriptions.modal.dosageLabel')}</label>
                                <input
                                    type="text" id="dosage" value={dosage} onChange={(e) => setDosage(e.target.value)}
                                    className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                                    placeholder={t('doctor.prescriptions.modal.dosagePlaceholder')}
                                />
                            </div>
                            <div>
                                <label htmlFor="frequency" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('doctor.prescriptions.modal.frequencyLabel')}</label>
                                <input
                                    type="text" id="frequency" value={frequency} onChange={(e) => setFrequency(e.target.value)}
                                    className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                                    placeholder={t('doctor.prescriptions.modal.frequencyPlaceholder')}
                                />
                            </div>
                        </div>
                        {error && <p className="text-red-500 dark:text-red-400 text-sm text-center">{error}</p>}
                    </div>
                     <div className="mt-6 flex justify-end space-x-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-white rounded-md hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors">
                            {t('common.cancel')}
                        </button>
                        <button type="submit" className="px-4 py-2 text-sm font-medium bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors">
                            {t('doctor.prescriptions.modal.send')}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default PrescriptionModal;