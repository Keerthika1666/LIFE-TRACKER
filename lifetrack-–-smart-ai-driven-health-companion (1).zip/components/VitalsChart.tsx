import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { VitalData } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { useTheme } from '../contexts/ThemeContext';

type VitalKey = keyof Pick<VitalData, 'heartRate' | 'spo2' | 'temperature'>;

interface VitalsChartProps {
  data: VitalData[];
  type?: 'combined' | 'single';
  vitalKey?: VitalKey;
  title?: string;
  latestValue?: number;
  unit?: string;
  threshold?: number;
  showSingleHeader?: boolean;
}

const vitalMeta: Record<VitalKey, { color: string, name: string, gradientId: string }> = {
    heartRate: { color: "#f43f5e", name: "Heart Rate", gradientId: "colorHeartRate" },
    spo2: { color: "#3b82f6", name: "SpO₂", gradientId: "colorSpo2" },
    temperature: { color: "#eab308", name: "Temperature", gradientId: "colorTemp" }
};


const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-200/80 dark:bg-slate-800/80 backdrop-blur-sm p-3 rounded-lg border border-slate-300 dark:border-slate-700 shadow-xl">
          <p className="label text-slate-600 dark:text-slate-300">{`${label}`}</p>
          {payload.map((pld: any) => (
             <p key={pld.dataKey} style={{ color: pld.color }} className="font-semibold">
                {`${pld.name}: ${pld.value}`}
             </p>
          ))}
        </div>
      );
    }
    return null;
};


const VitalsChart = ({ data, type = 'combined', vitalKey, title, latestValue, unit, threshold, showSingleHeader = true }: VitalsChartProps): React.ReactNode => {
  const { t } = useLanguage();
  const { theme } = useTheme();
  const [activeSeries, setActiveSeries] = useState({ heartRate: true, spo2: true, temperature: true });

  const handleLegendClick = (e: any) => {
    const { dataKey } = e;
    setActiveSeries(prev => ({ ...prev, [dataKey]: !prev[dataKey] }));
  };

  const axisColor = theme === 'dark' ? '#9ca3af' : '#475569';
  const gridColor = theme === 'dark' ? '#374151' : '#e2e8f0';
  const legendColor = theme === 'dark' ? '#d1d5db' : '#334155';
  const refLineColor = theme === 'dark' ? '#cbd5e1' : '#475569';
  
  if (type === 'single' && vitalKey) {
    const meta = vitalMeta[vitalKey];
    return (
       <div className="h-full w-full flex flex-col">
            {showSingleHeader && (
              <div className="flex justify-between items-baseline px-2">
                  <h4 className="text-md font-semibold text-slate-800 dark:text-white">{title}</h4>
                  <p className="text-2xl font-bold" style={{color: meta.color}}>
                      {latestValue}
                      <span className="text-lg font-normal text-slate-500 dark:text-slate-300 ml-1">{unit}</span>
                  </p>
              </div>
            )}
            <ResponsiveContainer width="100%" height="100%">
                 <AreaChart data={data} margin={{ top: showSingleHeader ? 15 : 5, right: 5, left: -25, bottom: -10 }}>
                    <defs>
                        <linearGradient id={meta.gradientId} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={meta.color} stopOpacity={0.8}/>
                            <stop offset="95%" stopColor={meta.color} stopOpacity={0}/>
                        </linearGradient>
                    </defs>
                    <YAxis stroke={axisColor} fontSize={10} domain={['dataMin - 5', 'dataMax + 5']} />
                    {threshold && (
                        <ReferenceLine y={threshold} label={{ value: `Threshold`, position: 'insideTopLeft', fontSize: 10, fill: refLineColor }} stroke={refLineColor} strokeDasharray="3 3" />
                    )}
                    <Area type="monotone" dataKey={vitalKey} stroke={meta.color} fillOpacity={1} fill={`url(#${meta.gradientId})`} strokeWidth={2} />
                 </AreaChart>
            </ResponsiveContainer>
       </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm p-4 rounded-lg shadow-lg h-96">
      <h3 className="text-lg font-semibold mb-4 text-slate-800 dark:text-white">{t('trends.chartTitle')}</h3>
      <ResponsiveContainer width="100%" height="90%">
        <AreaChart
          data={data}
          margin={{ top: 5, right: 20, left: -10, bottom: 5 }}
        >
            <defs>
                <linearGradient id="colorHeartRate" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorSpo2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#eab308" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                </linearGradient>
            </defs>
          <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
          <XAxis dataKey="time" stroke={axisColor} fontSize={12} tick={{ fill: axisColor }} />
          <YAxis stroke={axisColor} fontSize={12} tick={{ fill: axisColor }} />
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{ color: legendColor, fontSize: '14px', paddingTop: '10px', cursor: 'pointer' }} onClick={handleLegendClick} />
          <Area type="monotone" dataKey="heartRate" name={t('overview.vitals.heartRate')} stroke="#f43f5e" fillOpacity={1} fill="url(#colorHeartRate)" strokeWidth={2} hide={!activeSeries.heartRate} />
          <Area type="monotone" dataKey="spo2" name={`${t('overview.vitals.spo2')} (%)`} stroke="#3b82f6" fillOpacity={1} fill="url(#colorSpo2)" strokeWidth={2} hide={!activeSeries.spo2} />
          <Area type="monotone" dataKey="temperature" name={`${t('overview.vitals.temperature')} (°C)`} stroke="#eab308" fillOpacity={1} fill="url(#colorTemp)" strokeWidth={2} hide={!activeSeries.temperature} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default VitalsChart;