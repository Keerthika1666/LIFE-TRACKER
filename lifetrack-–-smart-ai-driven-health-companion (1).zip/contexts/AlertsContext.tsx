import React, { createContext, useState, useContext, useCallback, useMemo } from 'react';
import type { Alert } from '../types';
import { AlertType } from '../types';
import { mockFamilyContacts } from '../data/mockData';
import { useSettings } from './SettingsContext';
import { useUser } from './UserContext';
import { patientDataService } from '../services/patientDataService';

interface Toast {
    id: string;
    message: string;
}

interface ConfirmationState {
    isOpen: boolean;
    reason: string;
}

interface AlertsContextType {
  alerts: Alert[];
  newAlertCount: number;
  toastQueue: Toast[];
  confirmation: ConfirmationState;
  addAlert: (alertData: { type: AlertType; value: string; threshold: string }) => void;
  // FIX: Expose `addToast` in the context type so it can be used by other components.
  addToast: (message: string) => void;
  markAsViewed: (id: string) => void;
  clearNewAlertCount: () => void;
  dismissToast: (id: string) => void;
  initiateSOS: (reason: string) => void;
  confirmSOS: () => void;
  clearConfirmation: () => void;
}

const AlertsContext = createContext<AlertsContextType | undefined>(undefined);

export const AlertsProvider = ({ children }: { children: React.ReactNode }) => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [newAlertCount, setNewAlertCount] = useState(0);
  const [toastQueue, setToastQueue] = useState<Toast[]>([]);
  const [confirmation, setConfirmation] = useState<ConfirmationState>({ isOpen: false, reason: '' });
  const { smsAlerts, emailAlerts } = useSettings();
  const { user } = useUser();

  const addToast = useCallback((message: string) => {
    setToastQueue(prev => [...prev, { id: `toast-${Date.now()}`, message }]);
  }, []);

  const addAlert = useCallback((alertData: { type: AlertType; value: string; threshold: string }) => {
    const newAlert: Alert = {
      ...alertData,
      id: `alert-${Date.now()}`,
      timestamp: new Date(),
      status: 'new',
    };

    setAlerts(prev => [newAlert, ...prev]);
    setNewAlertCount(prev => prev + 1);
    addToast(`New Alert: ${newAlert.type}: ${newAlert.value}`);

  }, [addToast]);

  const initiateSOS = useCallback((reason: string) => {
      if (confirmation.isOpen) return; // Prevent multiple SOS modals
      setConfirmation({ isOpen: true, reason });
  }, [confirmation.isOpen]);

  const confirmSOS = useCallback(() => {
    setConfirmation({ isOpen: false, reason: '' });
    
    const reason = confirmation.reason || 'Manual SOS Triggered';
    const alertData = { type: AlertType.SOS_MANUAL, value: reason, threshold: 'N/A'};
    
    // Add alert to the current patient's local history
    addAlert(alertData);

    // Update the shared patient data service so the doctor's dashboard gets the alert
    if (user && user.role === 'Patient') {
        patientDataService.addPatientAlert(user.id, alertData);
    }
    
    // Simulate multi-channel alerts via toasts
    const notifications: string[] = [];
    
    if (smsAlerts) {
        mockFamilyContacts.forEach(contact => {
             notifications.push(`Notifying ${contact.name} via SMS...`);
        });
    }
    if (emailAlerts) {
        const doctor = mockFamilyContacts.find(c => c.relation.includes('Doctor'));
        if (doctor) {
            notifications.push(`Notifying ${doctor.name} via Email...`);
        }
    }
    notifications.push('Emergency services have been dispatched.');

    notifications.forEach((msg, index) => {
        setTimeout(() => addToast(msg), index * 1500);
    });

  }, [addAlert, addToast, smsAlerts, emailAlerts, confirmation.reason, user]);

  const clearConfirmation = useCallback(() => {
    setConfirmation({ isOpen: false, reason: '' });
  }, []);

  const markAsViewed = useCallback((id: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === id ? { ...alert, status: 'viewed' } : alert
    ));
  }, []);

  const clearNewAlertCount = useCallback(() => {
    setNewAlertCount(0);
  }, []);
  
  const dismissToast = useCallback((id: string) => {
    setToastQueue(prev => prev.filter(t => t.id !== id));
  }, []);

  const value = useMemo(() => ({
    alerts, newAlertCount, toastQueue, confirmation,
    addAlert, markAsViewed, clearNewAlertCount, dismissToast,
    initiateSOS, confirmSOS, clearConfirmation,
    // FIX: Add `addToast` to the context value object.
    addToast,
  }), [alerts, newAlertCount, toastQueue, confirmation, addAlert, markAsViewed, clearNewAlertCount, dismissToast, initiateSOS, confirmSOS, clearConfirmation, addToast]);

  return (
    <AlertsContext.Provider value={value}>
      {children}
    </AlertsContext.Provider>
  );
};

export const useAlerts = (): AlertsContextType => {
  const context = useContext(AlertsContext);
  if (context === undefined) {
    throw new Error('useAlerts must be used within an AlertsProvider');
  }
  return context;
};
