

import React, { useState } from 'react';
import { Contact } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { mockFamilyContacts } from '../data/mockData';
import CallModal from '../components/CallModal';
import MessageModal from '../components/MessageModal';

const PageHeader = ({ onAddContact, t }: { onAddContact: () => void, t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{t('family.header')}</h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">{t('family.subHeader')}</p>
        </div>
        <button onClick={onAddContact} className="px-4 py-2 text-sm font-medium bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" /></svg>
            <span>{t('family.addContact')}</span>
        </button>
    </div>
)

const ContactCard = ({ contact, index, onCall, onMessage, t }: { contact: Contact, index: number, onCall: (contact: Contact) => void, onMessage: (contact: Contact) => void, t: (key: string, options?: any) => string }) => {
    const animationDelay = 100 * (index + 1);
    return (
        <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg p-5 shadow-lg flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-5 animate-fadeInUp" style={{animationDelay: `${animationDelay}ms`}}>
            <div className="relative flex-shrink-0">
                <img src={contact.avatarUrl} alt={contact.name} className="w-20 h-20 rounded-full object-cover border-2 border-slate-300 dark:border-slate-600"/>
                <span className={`absolute bottom-1 right-1 block h-4 w-4 rounded-full border-2 border-white dark:border-slate-800 ${contact.status === 'Online' ? 'bg-green-500' : 'bg-slate-500'}`}></span>
            </div>
            <div className="flex-1 text-center sm:text-left">
                <h3 className="text-xl font-bold text-slate-800 dark:text-white">{contact.name}</h3>
                <div className="flex items-center justify-center sm:justify-start gap-x-2">
                    <p className="text-cyan-600 dark:text-cyan-400 font-medium">{contact.relation}</p>
                    {contact.age && (
                        <>
                            <span className="text-slate-400 dark:text-slate-500">&bull;</span>
                            <p className="text-slate-500 dark:text-slate-400 font-medium">{contact.age} yrs</p>
                        </>
                    )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{t('family.lastContact', { time: contact.lastContact })}</p>
            </div>
            <div className="flex space-x-2">
                <button onClick={() => onMessage(contact)} className="p-3 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-full hover:bg-cyan-500 hover:text-white dark:hover:text-white transition-colors" aria-label={`Message ${contact.name}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 5a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm3.707 2.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0l5-5a1 1 0 00-1.414-1.414L10 9.586 5.707 7.293z" /></svg>
                </button>
                <button onClick={() => onCall(contact)} className="p-3 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-full hover:bg-cyan-500 hover:text-white dark:hover:text-white transition-colors" aria-label={`Call ${contact.name}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" /></svg>
                </button>
            </div>
        </div>
    )
};

type AddContactData = {
    name: string;
    relation: Contact['relation'];
    age: string;
};

const AddContactModal = ({ isOpen, onClose, onSave, t }: { isOpen: boolean; onClose: () => void; onSave: (contactData: AddContactData) => void; t: (key: string) => string }) => {
    const [name, setName] = useState('');
    const [age, setAge] = useState('');
    const [relation, setRelation] = useState<Contact['relation'] | ''>('');
    const [error, setError] = useState('');

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const ageNum = parseInt(age, 10);
        if (!name.trim() || !relation) {
            setError(t('family.addModal.errorRequired'));
            return;
        }
        if (!age.trim() || isNaN(ageNum) || ageNum <= 0) {
            setError(t('family.addModal.errorAge'));
            return;
        }
        onSave({ name, relation, age });
        // Reset form for next time
        setName('');
        setAge('');
        setRelation('');
        setError('');
    };
    
    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-6 w-full max-w-md border border-slate-300 dark:border-slate-700 animate-fadeInUp" onClick={(e) => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-4">{t('family.addModal.title')}</h3>
                    <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="col-span-2 sm:col-span-1">
                                <label htmlFor="contact-name" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('family.addModal.nameLabel')}</label>
                                <input
                                    type="text"
                                    id="contact-name"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                                    placeholder={t('family.addModal.namePlaceholder')}
                                    autoFocus
                                />
                            </div>
                             <div className="col-span-2 sm:col-span-1">
                                <label htmlFor="contact-age" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('family.addModal.ageLabel')}</label>
                                <input
                                    type="number"
                                    id="contact-age"
                                    value={age}
                                    onChange={(e) => setAge(e.target.value)}
                                    className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                                    placeholder={t('family.addModal.agePlaceholder')}
                                />
                            </div>
                        </div>
                        <div>
                            <label htmlFor="contact-relation" className="block text-sm font-medium text-slate-500 dark:text-slate-400">{t('family.addModal.relationLabel')}</label>
                            <select
                                id="contact-relation"
                                value={relation}
                                onChange={(e) => setRelation(e.target.value as Contact['relation'])}
                                className="mt-1 block w-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                            >
                                <option value="" disabled>{t('family.addModal.selectRelation')}</option>
                                <option>Primary Doctor</option>
                                <option>Cardiologist</option>
                                <option>Specialist</option>
                                <option>Spouse</option>
                                <option>Mother</option>
                                <option>Father</option>
                                <option>Daughter</option>
                                <option>Son</option>
                                <option>Friend</option>
                                <option>Other Family</option>
                            </select>
                        </div>
                         {error && <p className="text-red-500 dark:text-red-400 text-sm text-center">{error}</p>}
                    </div>
                    <div className="mt-6 flex justify-end space-x-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-white rounded-md hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors">
                            {t('common.cancel')}
                        </button>
                        <button type="submit" className="px-4 py-2 text-sm font-medium bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors">
                            {t('common.saveChanges')}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const FamilyConnect = (): React.ReactNode => {
    const [contacts, setContacts] = useState<Contact[]>(mockFamilyContacts);
    const [callingContact, setCallingContact] = useState<Contact | null>(null);
    const [messagingContact, setMessagingContact] = useState<Contact | null>(null);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const { t } = useLanguage();

    const handleSaveContact = (contactData: AddContactData) => {
        const newContact: Contact = {
            id: `contact-${Date.now()}`,
            name: contactData.name,
            age: parseInt(contactData.age, 10),
            relation: contactData.relation,
            avatarUrl: `https://picsum.photos/seed/${Date.now()}/100`,
            status: 'Offline',
            lastContact: 'Just added',
        };
        setContacts(prevContacts => [...prevContacts, newContact]);
        setIsAddModalOpen(false);
    };

    return (
        <>
            <PageHeader onAddContact={() => setIsAddModalOpen(true)} t={t} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {contacts.map((contact, index) => (
                    <ContactCard 
                        key={contact.id} 
                        contact={contact} 
                        index={index} 
                        onCall={setCallingContact}
                        onMessage={setMessagingContact} 
                        t={t}
                    />
                ))}
            </div>
            <CallModal person={callingContact} onClose={() => setCallingContact(null)} />
            <MessageModal person={messagingContact} onClose={() => setMessagingContact(null)} />
            <AddContactModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} onSave={handleSaveContact} t={t} />
        </>
    );
};

export default FamilyConnect;