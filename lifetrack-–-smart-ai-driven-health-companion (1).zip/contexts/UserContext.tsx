
import React, { createContext, useState, useContext, useMemo, useCallback } from 'react';
import type { User, UserRole } from '../types';
import { mockPatientUser, mockDoctorUser, mockCaregiverUser } from '../data/mockData';

interface UserContextType {
  user: User | null;
  login: (role: UserRole) => void;
  logout: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  const login = useCallback((role: UserRole) => {
    if (role === 'Patient') {
      setUser(mockPatientUser);
    } else if (role === 'Doctor') {
      setUser(mockDoctorUser);
    } else if (role === 'Caregiver') {
      setUser(mockCaregiverUser);
    }
  }, []);

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const value = useMemo(() => ({
    user,
    login,
    logout,
  }), [user, login, logout]);

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};