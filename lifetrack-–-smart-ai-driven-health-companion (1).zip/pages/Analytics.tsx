
import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { useLanguage } from '../contexts/LanguageContext';
import { patientDataService } from '../services/patientDataService';
import { RiskLevel, AlertType } from '../types';

const PageHeader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-white tracking-tight">{t('doctor.analytics.header')}</h1>
            <p className="text-slate-400 mt-1">{t('doctor.analytics.subHeader')}</p>
        </div>
    </div>
);

const riskColors: { [key in RiskLevel]: string } = {
    [RiskLevel.Low]: '#22c55e', // green-500
    [RiskLevel.Medium]: '#eab308', // yellow-500
    [RiskLevel.High]: '#ef4444', // red-500
    [RiskLevel.Unknown]: '#64748b', // slate-500
};

const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-slate-800/80 backdrop-blur-sm p-3 rounded-lg border border-slate-700 shadow-xl">
                <p className="label text-slate-300">{`${payload[0].name} : ${payload[0].value}`}</p>
            </div>
        );
    }
    return null;
};

const Analytics = (): React.ReactNode => {
    const { t } = useLanguage();
    const patients = patientDataService.getPatients();

    const riskData = useMemo(() => {
        const counts = patients.reduce((acc, patient) => {
            acc[patient.riskLevel] = (acc[patient.riskLevel] || 0) + 1;
            return acc;
        }, {} as Record<RiskLevel, number>);

        return Object.entries(counts).map(([name, value]) => ({ name: name as RiskLevel, value }));
    }, [patients]);
    
    const alertData = useMemo(() => {
        const alertCounts = patients
            .filter(p => p.lastAlert)
            .reduce((acc, patient) => {
                const type = patient.lastAlert!.type;
                acc[type] = (acc[type] || 0) + 1;
                return acc;
            }, {} as Record<AlertType, number>);

        return Object.entries(alertCounts)
            .map(([name, count]) => ({ name, count }))
            .sort((a,b) => b.count - a.count);

    }, [patients]);

    return (
        <>
            <PageHeader t={t} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg p-6 h-96 animate-fadeInUp animation-delay-100">
                    <h3 className="text-lg font-semibold text-white mb-4">{t('doctor.analytics.riskDistribution')}</h3>
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={riskData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                outerRadius={120}
                                fill="#8884d8"
                                dataKey="value"
                                nameKey="name"
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                                {riskData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={riskColors[entry.name]} />
                                ))}
                            </Pie>
                            <Tooltip content={<CustomTooltip />} />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
                <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg p-6 h-96 animate-fadeInUp animation-delay-200">
                     <h3 className="text-lg font-semibold text-white mb-4">{t('doctor.analytics.alertTypes')}</h3>
                     <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={alertData} layout="vertical" margin={{ top: 5, right: 20, left: 80, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                            <XAxis type="number" stroke="#9ca3af" fontSize={12} />
                            <YAxis type="category" dataKey="name" stroke="#9ca3af" fontSize={10} width={120} />
                            <Tooltip content={<CustomTooltip />} />
                            <Bar dataKey="count" fill="#06b6d4" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </>
    );
};

export default Analytics;
