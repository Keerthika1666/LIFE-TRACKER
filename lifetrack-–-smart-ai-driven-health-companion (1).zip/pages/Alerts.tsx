

import React, { useEffect } from 'react';
import { useAlerts } from '../contexts/AlertsContext';
import { useLanguage } from '../contexts/LanguageContext';
import { ICONS } from '../constants';
import type { Alert } from '../types';

const PageHeader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{t('alerts.header')}</h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">{t('alerts.subHeader')}</p>
        </div>
    </div>
);

const getAlertStyles = (alert: Alert) => {
    const base = 'border-l-4 py-4 px-5 grid grid-cols-3 md:grid-cols-5 gap-4 items-center transition-colors duration-300';
    if (alert.status === 'new') {
        return `${base} bg-cyan-500/10 border-cyan-500 hover:bg-cyan-500/20`;
    }
    return `${base} bg-white dark:bg-slate-800/50 border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50`;
}

const AlertRow = ({ alert, onMarkAsViewed, t }: { alert: Alert, onMarkAsViewed: (id: string) => void, t: (key: string, options?: any) => string }) => {
    return (
        <div className={getAlertStyles(alert)} onClick={() => onMarkAsViewed(alert.id)}>
            <div className="md:col-span-2">
                <p className="font-bold text-slate-800 dark:text-white">{alert.type}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400 md:hidden">{alert.timestamp.toLocaleString()}</p>
            </div>
            <div className="text-center">
                <p className="text-slate-500 dark:text-slate-400 text-sm">{t('alerts.table.value')}</p>
                <p className="font-mono text-slate-800 dark:text-white">{alert.value}</p>
            </div>
            <div className="text-center">
                <p className="text-slate-500 dark:text-slate-400 text-sm">{t('alerts.table.threshold')}</p>
                <p className="font-mono text-slate-800 dark:text-white">{alert.threshold}</p>
            </div>
            <div className="hidden md:block text-right">
                 <p className="text-slate-600 dark:text-slate-300">{alert.timestamp.toLocaleString()}</p>
            </div>
        </div>
    )
}

const Alerts = (): React.ReactNode => {
    const { alerts, clearNewAlertCount, markAsViewed } = useAlerts();
    const { t } = useLanguage();

    useEffect(() => {
        // When the user visits the alerts page, clear the new alert counter in the sidebar
        clearNewAlertCount();
    }, [clearNewAlertCount]);

    return (
        <>
            <PageHeader t={t} />
            <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg animate-fadeInUp animation-delay-100">
                <div className="hidden md:grid grid-cols-5 gap-4 items-center p-5 text-sm font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                    <div className="col-span-2">{t('alerts.table.type')}</div>
                    <div className="text-center">{t('alerts.table.value')}</div>
                    <div className="text-center">{t('alerts.table.threshold')}</div>
                    <div className="text-right">{t('alerts.table.timestamp')}</div>
                </div>
                <div className="space-y-2 p-2">
                    {alerts.length > 0 ? (
                        alerts.map(alert => <AlertRow key={alert.id} alert={alert} onMarkAsViewed={markAsViewed} t={t} />)
                    ) : (
                        <div className="text-center py-16 px-6">
                            <div className="text-green-500 dark:text-green-400 mx-auto h-12 w-12">
                                {ICONS.alertSuccess}
                            </div>
                            <h3 className="mt-2 text-lg font-medium text-slate-800 dark:text-white">{t('alerts.empty.title')}</h3>
                            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{t('alerts.empty.description')}</p>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
};

export default Alerts;