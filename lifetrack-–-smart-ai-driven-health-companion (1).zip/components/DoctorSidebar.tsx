

import React from 'react';
import { ICONS } from '../constants';
import { useLanguage } from '../contexts/LanguageContext';
import { useUser } from '../contexts/UserContext';

type DoctorPage = 'dashboard' | 'analytics' | 'appointments' | 'prescriptions' | 'settings';

interface DoctorSidebarProps {
  activePage: DoctorPage;
  setActivePage: (page: DoctorPage) => void;
  onLogout: () => void;
}

const NavItem = ({ icon, label, page, activePage, setActivePage }: { icon: React.ReactNode, label: string, page: DoctorPage, activePage: DoctorPage, setActivePage: (page: DoctorPage) => void }) => {
  const isActive = activePage === page;
  return (
    <button
      onClick={() => setActivePage(page)}
      className={`relative flex items-center justify-center w-14 h-14 rounded-lg transition-all duration-300 group ${isActive ? 'bg-cyan-500 text-white shadow-[0_0_20px_theme(colors.brand-cyan)]' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-cyan-500 dark:hover:text-cyan-400'}`}
      aria-label={label}
      aria-current={isActive ? 'page' : undefined}
    >
      {icon}
      <span className="absolute left-20 p-2 px-3 text-sm text-white bg-slate-800 rounded-md shadow-lg transition-all duration-300 scale-0 group-hover:scale-100 whitespace-nowrap origin-left z-10">
        {label}
      </span>
    </button>
  );
};

const DoctorSidebar = ({ activePage, setActivePage, onLogout }: DoctorSidebarProps): React.ReactNode => {
  const { t } = useLanguage();
  const { user } = useUser();

  return (
    <aside className="fixed top-0 left-0 h-full w-24 bg-white/80 dark:bg-slate-800/50 backdrop-blur-sm z-20 flex flex-col items-center py-6 border-r border-slate-200 dark:border-slate-700">
      <div className="flex-shrink-0 flex items-center justify-center w-14 h-14 mb-8">
        <img src={user?.avatarUrl} alt="Doctor Avatar" className="w-14 h-14 rounded-full object-cover border-2 border-cyan-500" />
      </div>

      <nav className="flex flex-col items-center space-y-6">
        <NavItem icon={ICONS.family} label={t('doctor.sidebar.patients')} page="dashboard" activePage={activePage} setActivePage={setActivePage} />
        <NavItem icon={ICONS.analytics} label={t('doctor.sidebar.analytics')} page="analytics" activePage={activePage} setActivePage={setActivePage} />
        <NavItem icon={ICONS.appointments} label={t('doctor.sidebar.appointments')} page="appointments" activePage={activePage} setActivePage={setActivePage} />
        <NavItem icon={ICONS.prescriptions} label={t('doctor.sidebar.prescriptions')} page="prescriptions" activePage={activePage} setActivePage={setActivePage} />
      </nav>

      <div className="mt-auto flex flex-col items-center space-y-6">
        <NavItem icon={ICONS.settings} label={t('sidebar.settings')} page="settings" activePage={activePage} setActivePage={setActivePage} />
        <button onClick={onLogout} className="relative flex items-center justify-center w-14 h-14 rounded-lg text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-red-500 transition-colors duration-300 group" aria-label={t('sidebar.logout')}>
          {ICONS.logout}
          <span className="absolute left-20 p-2 px-3 text-sm text-white bg-slate-800 rounded-md shadow-lg transition-all duration-300 scale-0 group-hover:scale-100 whitespace-nowrap origin-left z-10">{t('sidebar.logout')}</span>
        </button>
      </div>
    </aside>
  );
};

export default DoctorSidebar;