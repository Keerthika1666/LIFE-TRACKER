import React from 'react';

const Dashboard = (): React.ReactNode => {
  return null;
};

export default Dashboard;
