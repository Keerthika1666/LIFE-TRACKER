
import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { patientDataService } from '../services/patientDataService';
import { Prescription, Patient } from '../types';
import { useAlerts } from '../contexts/AlertsContext';

const PageHeader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-white tracking-tight">{t('doctor.prescriptions.header')}</h1>
            <p className="text-slate-400 mt-1">{t('doctor.prescriptions.subHeader')}</p>
        </div>
    </div>
);

const statusStyles = {
    Active: 'bg-green-500/20 text-green-300',
    Completed: 'bg-slate-500/20 text-slate-300',
};

const PrescriptionForm = ({ onSave, t }: { onSave: (p: Omit<Prescription, 'id' | 'patientName' | 'dateIssued' | 'status'>) => void, t: (key: string) => string }) => {
    const allPatients = patientDataService.getPatients();
    const [patientId, setPatientId] = useState(allPatients.length > 0 ? allPatients[0].id : '');
    const [medicationName, setMedicationName] = useState('');
    const [dosage, setDosage] = useState('');
    const [frequency, setFrequency] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!patientId || !medicationName.trim() || !dosage.trim() || !frequency.trim()) {
            setError('All fields are required.');
            return;
        }
        onSave({ patientId, medicationName, dosage, frequency });
        setMedicationName('');
        setDosage('');
        setFrequency('');
        setError('');
    };

    return (
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg p-6 animate-fadeInUp animation-delay-100">
            <h3 className="text-lg font-semibold text-white mb-4">{t('doctor.prescriptions.writeNew')}</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                     <div>
                        <label htmlFor="patient-select" className="block text-sm font-medium text-slate-400">{t('doctor.prescriptions.modal.patientLabel')}</label>
                        <select
                            id="patient-select" value={patientId} onChange={(e) => setPatientId(e.target.value)}
                            className="mt-1 block w-full bg-slate-700 border border-slate-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                        >
                            {allPatients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="med-name" className="block text-sm font-medium text-slate-400">{t('doctor.prescriptions.modal.medicationLabel')}</label>
                        <input type="text" id="med-name" value={medicationName} onChange={e => setMedicationName(e.target.value)} placeholder={t('doctor.prescriptions.modal.medicationPlaceholder')} className="mt-1 w-full input-style" />
                    </div>
                    <div>
                        <label htmlFor="dosage" className="block text-sm font-medium text-slate-400">{t('doctor.prescriptions.modal.dosageLabel')}</label>
                        <input type="text" id="dosage" value={dosage} onChange={e => setDosage(e.target.value)} placeholder={t('doctor.prescriptions.modal.dosagePlaceholder')} className="mt-1 w-full input-style" />
                    </div>
                    <div>
                        <label htmlFor="frequency" className="block text-sm font-medium text-slate-400">{t('doctor.prescriptions.modal.frequencyLabel')}</label>
                        <input type="text" id="frequency" value={frequency} onChange={e => setFrequency(e.target.value)} placeholder={t('doctor.prescriptions.modal.frequencyPlaceholder')} className="mt-1 w-full input-style" />
                    </div>
                </div>
                {error && <p className="text-red-400 text-sm">{error}</p>}
                <div className="text-right">
                    <button type="submit" className="px-4 py-2 text-sm font-medium bg-cyan-500 rounded-md hover:bg-cyan-600 transition-colors">
                        {t('doctor.prescriptions.modal.send')}
                    </button>
                </div>
            </form>
        </div>
    );
};

const Prescriptions = (): React.ReactNode => {
    const { t } = useLanguage();
    const [prescriptions, setPrescriptions] = useState<Prescription[]>(patientDataService.getPrescriptions());
    const { addToast } = useAlerts();

    const handleSavePrescription = (data: Omit<Prescription, 'id' | 'patientName' | 'dateIssued' | 'status'>) => {
        patientDataService.addPatientPrescription(data.patientId, data);
        setPrescriptions(patientDataService.getPrescriptions()); // Refresh list
        const patientName = patientDataService.getPatients().find(p => p.id === data.patientId)?.name || 'the patient';
        addToast(t('doctor.prescriptions.sentToast', { patientName }));
    };

    return (
        <>
            <style>{`.input-style { background-color: #334155; border: 1px solid #475569; border-radius: 0.375rem; padding: 0.5rem 0.75rem; color: white; } .input-style:focus { outline: none; ring: 2px; ring-color: #06b6d4; border-color: #06b6d4; }`}</style>
            <PageHeader t={t} />
            <div className="space-y-6">
                <PrescriptionForm onSave={handleSavePrescription} t={t} />

                <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg animate-fadeInUp animation-delay-200">
                    <div className="p-4 border-b border-slate-700">
                        <h3 className="text-lg font-semibold text-white">{t('doctor.prescriptions.recent')}</h3>
                    </div>
                    <div className="overflow-x-auto">
                         <table className="w-full text-sm text-left text-slate-300">
                            <thead className="text-xs text-slate-400 uppercase bg-slate-800/60">
                                <tr>
                                    <th scope="col" className="px-6 py-3">{t('doctor.prescriptions.patient')}</th>
                                    <th scope="col" className="px-6 py-3">{t('doctor.prescriptions.medication')}</th>
                                    <th scope="col" className="px-6 py-3">{t('doctor.prescriptions.dosage')}</th>
                                    <th scope="col" className="px-6 py-3">{t('doctor.prescriptions.dateIssued')}</th>
                                    <th scope="col" className="px-6 py-3 text-center">{t('doctor.prescriptions.status')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {prescriptions.length > 0 ? prescriptions.map(p => (
                                    <tr key={p.id} className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors">
                                        <td className="px-6 py-4 font-medium text-white whitespace-nowrap">{p.patientName}</td>
                                        <td className="px-6 py-4">{p.medicationName}</td>
                                        <td className="px-6 py-4">{p.dosage}</td>
                                        <td className="px-6 py-4">{p.dateIssued.toLocaleDateString()}</td>
                                        <td className="px-6 py-4 text-center">
                                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusStyles[p.status]}`}>
                                                {p.status}
                                            </span>
                                        </td>
                                    </tr>
                                )) : (
                                    <tr>
                                        <td colSpan={5} className="text-center py-10 text-slate-500">{t('doctor.prescriptions.noPrescriptions')}</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Prescriptions;
