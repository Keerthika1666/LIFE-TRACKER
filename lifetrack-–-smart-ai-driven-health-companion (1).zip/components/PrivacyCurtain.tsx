

import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';

interface PrivacyCurtainProps {
    onResume: () => void;
}

const PrivacyCurtain = ({ onResume }: PrivacyCurtainProps): React.ReactNode => {
    const { t } = useLanguage();
    return (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-center justify-center animate-fadeInUp">
            <div className="text-center p-8 bg-white/80 dark:bg-slate-800/50 border border-slate-300 dark:border-slate-700 rounded-lg shadow-2xl">
                <div className="mx-auto h-16 w-16 text-cyan-500 dark:text-cyan-400">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
                    </svg>
                </div>
                <h2 className="mt-4 text-2xl font-bold text-slate-800 dark:text-white">{t('privacy.title')}</h2>
                <p className="mt-2 text-slate-600 dark:text-slate-300">{t('privacy.description')}</p>
                <button
                    onClick={onResume}
                    className="mt-6 px-6 py-3 bg-cyan-500 text-white font-semibold rounded-lg hover:bg-cyan-600 transition-colors"
                >
                    {t('privacy.resume')}
                </button>
            </div>
        </div>
    );
};

export default PrivacyCurtain;