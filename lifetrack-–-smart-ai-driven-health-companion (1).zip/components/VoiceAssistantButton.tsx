
import React, { useState } from 'react';
import { ICONS } from '../constants';
import VoiceAssistantModal from './VoiceAssistantModal';

const VoiceAssistantButton = (): React.ReactNode => {
    const [isModalOpen, setIsModalOpen] = useState(false);

    return (
        <>
            <button
                onClick={() => setIsModalOpen(true)}
                className="fixed bottom-20 right-6 z-30 w-16 h-16 bg-gradient-to-br from-brand-cyan to-brand-blue rounded-full shadow-lg text-white flex items-center justify-center transition-transform duration-300 hover:scale-110 hover:shadow-cyan-500/50 active:scale-100"
                aria-label="Open AI Voice Assistant"
            >
                {ICONS.voiceAssistant}
            </button>
            <VoiceAssistantModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
        </>
    );
};

export default VoiceAssistantButton;
