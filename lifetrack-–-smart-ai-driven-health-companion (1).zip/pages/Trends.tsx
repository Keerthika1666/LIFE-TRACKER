import React, { useState, useEffect, useMemo } from 'react';
import { useVitalsData } from '../hooks/useVitalsData';
import VitalsChart from '../components/VitalsChart';
import { ICONS } from '../constants';
import type { VitalData } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

const StatCard = ({ label, value, icon, unit }: {label: string; value: string | number; icon: React.ReactNode; unit: string;}) => (
    <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg p-5 shadow-lg flex items-center space-x-4">
        <div className="p-3 rounded-full bg-slate-100 dark:bg-slate-700 text-cyan-500 dark:text-cyan-400">
            {icon}
        </div>
        <div>
            <p className="text-slate-500 dark:text-slate-400 text-sm">{label}</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-white">
                {value} <span className="text-lg font-normal text-slate-600 dark:text-slate-300">{unit}</span>
            </p>
        </div>
    </div>
);

const generateHistoricalData = (numPoints: number, varianceMultiplier: number): VitalData[] => {
    const data: VitalData[] = [];
    const baseTime = new Date();
    for (let i = numPoints - 1; i >= 0; i--) {
        // Simulate time going back in 30 minute intervals to keep data points readable
        const time = new Date(baseTime.getTime() - i * 30 * 60 * 1000);
        data.push({
            time: time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            heartRate: Math.round(75 + (Math.random() - 0.5) * 10 * varianceMultiplier),
            spo2: Math.round(98 - Math.random() * varianceMultiplier),
            systolicBP: Math.round(120 + (Math.random() - 0.5) * 15 * varianceMultiplier),
            diastolicBP: Math.round(80 + (Math.random() - 0.5) * 10 * varianceMultiplier),
            temperature: parseFloat((37.0 + (Math.random() - 0.5) * 0.3 * varianceMultiplier).toFixed(1)),
        });
    }
    return data;
};

type TimeRange = '24h' | '7d' | '30d';
type TimeRangeKey = 'day' | 'week' | 'month';

const timeRangeMap: { [key in TimeRange]: TimeRangeKey } = {
    '24h': 'day',
    '7d': 'week',
    '30d': 'month'
};


const PageHeader = ({ timeRange, setTimeRange, t }: { timeRange: TimeRange; setTimeRange: (range: TimeRange) => void, t: (key: string) => string }) => {
    const timeRanges: TimeRange[] = ['24h', '7d', '30d'];
    return (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 animate-fadeInUp">
            <div>
                <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{t('trends.header')}</h1>
                <p className="text-slate-500 dark:text-slate-400 mt-1">{t('trends.subHeader')}</p>
            </div>
            <div className="flex items-center space-x-2 mt-4 sm:mt-0 bg-slate-200 dark:bg-slate-800 p-1 rounded-lg">
                 {timeRanges.map(range => (
                     <button 
                        key={range}
                        onClick={() => setTimeRange(range)} 
                        className={`px-4 py-2 text-sm font-medium rounded-md transition-colors duration-300 ${timeRange === range ? 'bg-cyan-500 text-white shadow-md' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'}`}
                    >
                        {t(`trends.timeRanges.${timeRangeMap[range]}`)}
                    </button>
                ))}
            </div>
        </div>
    )
};

const Trends = (): React.ReactNode => {
    const { vitalsHistory } = useVitalsData();
    const [timeRange, setTimeRange] = useState<TimeRange>('24h');
    const [displayData, setDisplayData] = useState<VitalData[]>(vitalsHistory);
    const { t } = useLanguage();

    useEffect(() => {
        let data: VitalData[];
        switch (timeRange) {
            case '7d':
                data = generateHistoricalData(100, 1.5);
                break;
            case '30d':
                data = generateHistoricalData(200, 2.0);
                break;
            case '24h':
            default:
                data = vitalsHistory;
                break;
        }
        setDisplayData(data);
    }, [timeRange, vitalsHistory]);

    // Calculate stats from the currently displayed data
    const stats = useMemo(() => {
        if (displayData.length === 0) {
            return {
                avgHeartRate: '0',
                avgSpo2: '0.0',
                maxTemp: '0.0',
                avgBloodPressure: '0/0',
            };
        }
        const avgHeartRate = (displayData.reduce((acc, v) => acc + v.heartRate, 0) / displayData.length).toFixed(0);
        const avgSpo2 = (displayData.reduce((acc, v) => acc + v.spo2, 0) / displayData.length).toFixed(1);
        const maxTemp = Math.max(...displayData.map(v => v.temperature)).toFixed(1);
        const avgSystolicBP = (displayData.reduce((acc, v) => acc + v.systolicBP, 0) / displayData.length).toFixed(0);
        const avgDiastolicBP = (displayData.reduce((acc, v) => acc + v.diastolicBP, 0) / displayData.length).toFixed(0);
        const avgBloodPressure = `${avgSystolicBP}/${avgDiastolicBP}`;
        
        return { avgHeartRate, avgSpo2, maxTemp, avgBloodPressure };
    }, [displayData]);

    return (
        <>
            <PageHeader timeRange={timeRange} setTimeRange={setTimeRange} t={t} />
            <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-fadeInUp animation-delay-100">
                    <StatCard label={t('trends.stats.avgHr')} value={stats.avgHeartRate} icon={ICONS.heartRate} unit={t('overview.units.bpm')} />
                    <StatCard label={t('trends.stats.avgSpo2')} value={stats.avgSpo2} icon={ICONS.spo2} unit={t('overview.units.percent')} />
                    <StatCard label={t('trends.stats.peakTemp')} value={stats.maxTemp} icon={ICONS.temperature} unit={t('overview.units.celsius')} />
                    <StatCard label={t('trends.stats.avgBp')} value={stats.avgBloodPressure} icon={ICONS.bloodPressure} unit={t('overview.units.mmhg')} />
                </div>
                <div className="animate-fadeInUp animation-delay-200">
                    <VitalsChart data={displayData} />
                </div>
            </div>
        </>
    );
};

export default Trends;