import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useUser } from '../contexts/UserContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Patient, RiskLevel, AlertType } from '../types';
import { ICONS } from '../constants';
import Sparkline from '../components/Sparkline';
import CallModal from '../components/CallModal';
import MessageModal from '../components/MessageModal';
import NewAlertsModal from '../components/NewAlertsModal';
import { patientDataService } from '../services/patientDataService';

const riskStyles: { [key in RiskLevel]: { pill: string; text: string; dot: string; } } = {
    [RiskLevel.Low]: { pill: 'bg-green-500/10 text-green-500 dark:text-green-400', text: 'text-green-500 dark:text-green-400', dot: 'bg-green-500' },
    [RiskLevel.Medium]: { pill: 'bg-yellow-500/10 text-yellow-500 dark:text-yellow-400', text: 'text-yellow-500 dark:text-yellow-400', dot: 'bg-yellow-500' },
    [RiskLevel.High]: { pill: 'bg-red-500/10 text-red-500 dark:text-red-400', text: 'text-red-500 dark:text-red-400', dot: 'bg-red-500' },
    [RiskLevel.Unknown]: { pill: 'bg-slate-500/10 text-slate-500 dark:text-slate-400', text: 'text-slate-500 dark:text-slate-400', dot: 'bg-slate-500' },
};

const StatCard = ({ icon, label, value, colorClass }: { icon: React.ReactNode, label: string, value: string | number, colorClass: string }) => (
    <div className="bg-white dark:bg-slate-800/60 p-5 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700/50 flex items-center space-x-4 h-full">
        <div className={`p-3 rounded-lg bg-slate-100 dark:bg-slate-900 ${colorClass}`}>
            {icon}
        </div>
        <div>
            <p className="text-slate-500 dark:text-slate-400 text-sm">{label}</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-white">{value}</p>
        </div>
    </div>
);

const ActionsMenu = ({ patient, onCall, onMessage, onSelect, t, isOpen, setOpenMenuId }: { patient: Patient, onCall: (p: Patient) => void, onMessage: (p: Patient) => void, onSelect: (p: Patient) => void, t: (key: string) => string, isOpen: boolean, setOpenMenuId: (id: string | null) => void }) => {
    const menuRef = useRef<HTMLDivElement>(null);
    const hasNewAlert = patient.lastAlert?.status === 'new';

    useEffect(() => {
        if (!isOpen) {
            return;
        }

        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setOpenMenuId(null);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [isOpen, setOpenMenuId]);

    const handleAction = (e: React.MouseEvent, action: () => void) => {
        e.stopPropagation();
        action();
        setOpenMenuId(null);
    };

    return (
        <div className="relative" ref={menuRef}>
            <button
                onClick={(e) => { e.stopPropagation(); setOpenMenuId(isOpen ? null : patient.id); }}
                className={`p-2 text-slate-500 dark:text-slate-400 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-white transition-colors ${isOpen ? 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-white' : ''}`}
                aria-haspopup="true"
                aria-expanded={isOpen}
                aria-label={t('doctor.actions')}
            >
                {ICONS.ellipsis}
            </button>
            {isOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md shadow-lg z-10 animate-fadeInUp" style={{animationDuration: '150ms'}}>
                    <ul className="py-1">
                        {hasNewAlert && (
                            <>
                                <li><button onClick={(e) => handleAction(e, () => patientDataService.acknowledgePatientAlert(patient.id))} className="font-bold block w-full text-left px-4 py-2 text-sm text-yellow-600 dark:text-yellow-400 hover:bg-slate-100 dark:hover:bg-slate-700">{t('doctor.acknowledgeAlert')}</button></li>
                                <li className="border-t border-slate-200 dark:border-slate-700 my-1"></li>
                            </>
                        )}
                        <li><button onClick={(e) => handleAction(e, () => onCall(patient))} className="block w-full text-left px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700">{t('doctor.callPatient')}</button></li>
                        <li><button onClick={(e) => handleAction(e, () => onMessage(patient))} className="block w-full text-left px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700">{t('doctor.sendMessage')}</button></li>
                        <li className="border-t border-slate-200 dark:border-slate-700 my-1"></li>
                        <li><button onClick={(e) => handleAction(e, () => onSelect(patient))} className="block w-full text-left px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700">{t('doctor.viewDetails')}</button></li>
                    </ul>
                </div>
            )}
        </div>
    );
};

const PatientListItem = ({ patient, onSelect, index, onCall, onMessage, openMenuId, setOpenMenuId }: { patient: Patient, onSelect: (patient: Patient) => void, index: number, onCall: (p: Patient) => void, onMessage: (p: Patient) => void, openMenuId: string | null, setOpenMenuId: (id: string | null) => void }) => {
    const { t } = useLanguage();
    const hasNewAlert = patient.lastAlert?.status === 'new';
    const isSosAlert = hasNewAlert && patient.lastAlert?.type === AlertType.SOS_MANUAL;
    const riskStyle = riskStyles[patient.riskLevel];
    const clickTimeout = useRef<number | null>(null);

    // Clean up timer if component unmounts
    useEffect(() => {
        return () => {
            if (clickTimeout.current) {
                clearTimeout(clickTimeout.current);
            }
        };
    }, []);

    const handleRowClick = (event: React.MouseEvent) => {
        // We use event.detail to distinguish single from double clicks.
        if (event.detail === 1) {
            clickTimeout.current = window.setTimeout(() => {
                onSelect(patient); // Navigate on single click
            }, 250); // 250ms delay to wait for a potential double click
        }
    };

    const handleRowDoubleClick = () => {
        // If a double click occurs, clear the single click timer
        if (clickTimeout.current) {
            clearTimeout(clickTimeout.current);
        }
        // And perform the double click action: open the menu
        setOpenMenuId(patient.id === openMenuId ? null : patient.id);
    };

    return (
        <div 
            onClick={handleRowClick}
            onDoubleClick={handleRowDoubleClick}
            className={`grid grid-cols-12 gap-4 items-center bg-white dark:bg-slate-800/40 backdrop-blur-sm rounded-lg p-3 shadow-md border transition-all duration-300 hover:bg-slate-50 dark:hover:bg-slate-700/50 hover:shadow-cyan-500/10 hover:border-cyan-500/50 cursor-pointer animate-fadeInUp ${
                isSosAlert
                ? 'border-red-500/80 animate-pulse-glow-red' 
                : 'border-slate-200 dark:border-slate-700/50'
            }`}
            style={{ animationDelay: `${index * 60}ms` }}
        >
            {/* Patient Info */}
            <div className="col-span-12 sm:col-span-6 md:col-span-3 flex items-center space-x-3">
                <img src={patient.avatarUrl} alt={patient.name} className="w-12 h-12 rounded-full object-cover" />
                <div className="min-w-0">
                    <p className="text-md font-bold text-slate-800 dark:text-white truncate">{patient.name}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{t('doctor.patientDetail.subHeader', { age: patient.age })}</p>
                </div>
            </div>

            {/* Risk Level */}
            <div className="col-span-6 sm:col-span-3 md:col-span-2">
                 <div className={`flex items-center space-x-2 py-1 px-3 rounded-full text-xs font-semibold ${riskStyle.pill}`}>
                    <span className={`h-2 w-2 rounded-full ${riskStyle.dot}`}></span>
                    <span>{patient.riskLevel} Risk</span>
                </div>
            </div>

            {/* Last Alert */}
            <div className="col-span-6 sm:col-span-3 md:col-span-2 text-xs">
                 {patient.lastAlert ? (
                    <p className={`truncate flex items-center font-semibold ${isSosAlert ? 'text-red-500 dark:text-red-400' : hasNewAlert ? 'text-yellow-500 dark:text-yellow-400' : 'text-slate-500 dark:text-slate-400'}`}>
                       {hasNewAlert && <span className="relative flex h-2 w-2 mr-2"><span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isSosAlert ? 'bg-red-400' : 'bg-yellow-400'}`}></span><span className={`relative inline-flex rounded-full h-2 w-2 ${isSosAlert ? 'bg-red-500' : 'bg-yellow-500'}`}></span></span>}
                        {patient.lastAlert.type}
                    </p>
                ) : (
                    <p className="text-green-500 dark:text-green-400 flex items-center">{t('doctor.vitalsStable')}</p>
                )}
            </div>
            
            {/* Vitals with Sparklines */}
            <div className="col-span-6 sm:col-span-4 md:col-span-2 flex items-center space-x-2">
                <div className="w-10 text-center">
                    <p className="font-bold text-slate-800 dark:text-white">{patient.lastVitals.heartRate}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">BPM</p>
                </div>
                <div className="w-20 h-10">
                    <Sparkline data={patient.vitalsHistory} dataKey="heartRate" strokeColor="#f43f5e" fillColor="#f43f5e" />
                </div>
            </div>

            <div className="col-span-6 sm:col-span-4 md:col-span-2 flex items-center space-x-2">
                <div className="w-10 text-center">
                    <p className="font-bold text-slate-800 dark:text-white">{patient.lastVitals.spo2}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">%</p>
                </div>
                <div className="w-20 h-10">
                    <Sparkline data={patient.vitalsHistory} dataKey="spo2" strokeColor="#3b82f6" fillColor="#3b82f6" />
                </div>
            </div>

            {/* Action */}
            <div className="col-span-12 sm:col-span-4 md:col-span-1 flex justify-end">
                <ActionsMenu 
                    patient={patient} 
                    onCall={onCall} 
                    onMessage={onMessage} 
                    onSelect={onSelect} 
                    t={t}
                    isOpen={patient.id === openMenuId}
                    setOpenMenuId={setOpenMenuId}
                />
            </div>
        </div>
    );
};

const PatientListHeader = ({ t }: { t: (key: string) => string }) => {
    return (
        <div className="hidden md:grid grid-cols-12 gap-4 items-center px-3 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
            <div className="col-span-3">{t('common.patientName').replace('John Doe', 'Patient')}</div>
            <div className="col-span-2">Risk Status</div>
            <div className="col-span-2">Last Alert</div>
            <div className="col-span-2">Heart Rate</div>
            <div className="col-span-2">SpO₂</div>
            <div className="col-span-1 text-right">Action</div>
        </div>
    );
};

const SOSBanner = ({ patient, onAcknowledge }: { patient: Patient, onAcknowledge: (id: string) => void }) => (
    <div className="bg-red-900/50 border-l-4 border-red-500 text-red-300 p-4 rounded-lg mb-6 flex flex-col sm:flex-row justify-between items-center animate-fadeInUp">
        <div className="flex items-center mb-2 sm:mb-0">
            <div className="text-red-400 mr-3">{ICONS.alertWarning}</div>
            <div>
                <p className="font-bold">SOS Alert Triggered by {patient.name}</p>
                <p className="text-sm">Reason: {patient.lastAlert?.value}</p>
            </div>
        </div>
        <button 
            onClick={() => onAcknowledge(patient.id)}
            className="text-xs bg-red-500/50 hover:bg-red-500/80 text-white font-bold py-1 px-3 rounded w-full sm:w-auto"
        >
            Acknowledge
        </button>
    </div>
);

const DoctorDashboard = ({ onSelectPatient }: { onSelectPatient: (patient: Patient) => void }): React.ReactNode => {
    const { user } = useUser();
    const { t } = useLanguage();
    const [filter, setFilter] = useState<RiskLevel | 'All'>('All');
    const [searchQuery, setSearchQuery] = useState('');
    const [patients, setPatients] = useState<Patient[]>([]);
    const [callingPatient, setCallingPatient] = useState<Patient | null>(null);
    const [messagingPatient, setMessagingPatient] = useState<Patient | null>(null);
    const [openMenuId, setOpenMenuId] = useState<string | null>(null);
    const [isAlertsModalOpen, setIsAlertsModalOpen] = useState(false);

    useEffect(() => {
        setPatients(patientDataService.getPatients());
        const unsubscribe = patientDataService.subscribe((updatedPatients) => {
            setPatients([...updatedPatients]);
        });
        return () => unsubscribe();
    }, []);

    const stats = useMemo(() => ({
        total: patients.length,
        highRisk: patients.filter(p => p.riskLevel === RiskLevel.High).length,
        newAlerts: patients.filter(p => p.lastAlert?.status === 'new').length,
    }), [patients]);

    const newAlertsPatients = useMemo(() => 
        patients
            .filter(p => p.lastAlert?.status === 'new')
            .sort((a, b) => new Date(b.lastAlert!.timestamp).getTime() - new Date(a.lastAlert!.timestamp).getTime()),
    [patients]);
    
    const processedPatients = useMemo(() => {
        const filtered = patients.filter(p => {
            const matchesFilter = filter === 'All' || p.riskLevel === filter;
            const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
            return matchesFilter && matchesSearch;
        });

        filtered.sort((a, b) => {
            const aHasNew = a.lastAlert?.status === 'new';
            const bHasNew = b.lastAlert?.status === 'new';
            if (aHasNew && !bHasNew) return -1;
            if (!aHasNew && bHasNew) return 1;
            return a.name.localeCompare(b.name);
        });

        return filtered;
    }, [filter, searchQuery, patients]);
    
    const sosAlertPatient = useMemo(() => 
        patients.find(p => p.lastAlert?.status === 'new' && p.lastAlert?.type === AlertType.SOS_MANUAL), 
        [patients]
    );

    return (
        <>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 animate-fadeInUp">
                <div>
                    <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{t('doctor.header')}</h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">{t('doctor.subHeader', { doctorName: user?.name })}</p>
                </div>
            </div>

            {sosAlertPatient && <SOSBanner patient={sosAlertPatient} onAcknowledge={patientDataService.acknowledgePatientAlert} />}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6 animate-fadeInUp animation-delay-100">
                <StatCard icon={ICONS.family} label={t('doctor.stats.totalPatients')} value={stats.total} colorClass="text-cyan-500 dark:text-cyan-400" />
                <StatCard icon={ICONS.alertWarning} label={t('doctor.stats.highRisk')} value={stats.highRisk} colorClass="text-yellow-500 dark:text-yellow-400" />
                <div 
                    onDoubleClick={() => stats.newAlerts > 0 && setIsAlertsModalOpen(true)}
                    className={stats.newAlerts > 0 ? "cursor-pointer" : ""} 
                    title={stats.newAlerts > 0 ? t('doctor.alertsTooltip') : undefined}
                >
                    <StatCard 
                        icon={ICONS.alerts} 
                        label={t('doctor.stats.newAlerts')} 
                        value={stats.newAlerts} 
                        colorClass={stats.newAlerts > 0 ? "text-red-500 dark:text-red-400" : "text-slate-500 dark:text-slate-400"} 
                    />
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg shadow-lg p-4 mb-6 flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4 animate-fadeInUp animation-delay-200">
                <div className="flex-1 w-full sm:w-auto">
                    <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500 dark:text-slate-400">{ICONS.search}</span>
                        <input 
                            type="text"
                            placeholder={t('doctor.searchPlaceholder')}
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full bg-slate-100 dark:bg-slate-700/50 border border-slate-300 dark:border-slate-600 rounded-md py-2 pl-10 pr-4 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        />
                    </div>
                </div>
                <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-slate-600 dark:text-slate-300 hidden md:block">{t('doctor.filterBy')}</span>
                    {(['All', ...Object.values(RiskLevel)] as const).filter(l => l !== RiskLevel.Unknown).map(level => (
                         <button key={level} onClick={() => setFilter(level)} className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors duration-300 ${filter === level ? 'bg-cyan-500 text-white shadow-md' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`}>
                            {level}
                        </button>
                    ))}
                </div>
            </div>

            <div className="mt-8 animate-fadeInUp animation-delay-300">
                <PatientListHeader t={t}/>
                <div className="space-y-3 mt-2">
                    {processedPatients.length > 0 ? (
                        processedPatients.map((patient, index) => (
                            <PatientListItem 
                                key={patient.id} 
                                patient={patient} 
                                onSelect={onSelectPatient} 
                                index={index}
                                onCall={setCallingPatient}
                                onMessage={setMessagingPatient}
                                openMenuId={openMenuId}
                                setOpenMenuId={setOpenMenuId}
                            />
                        ))
                    ) : (
                        <div className="text-center py-16 text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800/40 rounded-lg">
                            <p className="font-semibold">No Patients Found</p>
                            <p className="text-sm mt-1">Try adjusting your search or filter criteria.</p>
                        </div>
                    )}
                </div>
            </div>
            <CallModal person={callingPatient} onClose={() => setCallingPatient(null)} />
            <MessageModal person={messagingPatient} onClose={() => setMessagingPatient(null)} />
            <NewAlertsModal
                isOpen={isAlertsModalOpen}
                onClose={() => setIsAlertsModalOpen(false)}
                alerts={newAlertsPatients}
                onSelectPatient={(patient) => {
                    onSelectPatient(patient);
                    setIsAlertsModalOpen(false);
                }}
            />
        </>
    );
};

export default DoctorDashboard;