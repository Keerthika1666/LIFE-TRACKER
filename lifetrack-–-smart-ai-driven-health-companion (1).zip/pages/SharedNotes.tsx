
import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useUser } from '../contexts/UserContext';
import { patientDataService } from '../services/patientDataService';
import SharedNotesCard from '../components/SharedNotesCard';
import { Patient } from '../types';

interface SharedNotesProps {
    // patient prop is for Caregiver view. Patient view gets its own data.
    patient?: Patient; 
}

const PageHeader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-white tracking-tight">{t('sharedNotes.header')}</h1>
            <p className="text-slate-400 mt-1">{t('sharedNotes.subHeader')}</p>
        </div>
    </div>
);

const SharedNotes = ({ patient: caregiverPatient }: SharedNotesProps): React.ReactNode => {
    const { t } = useLanguage();
    const { user } = useUser();

    // Determine which patient's data to show
    let patient: Patient | undefined;
    if (user?.role === 'Patient') {
        patient = patientDataService.getPatients().find(p => p.id === user.id);
    } else if (user?.role === 'Caregiver') {
        patient = caregiverPatient;
    }

    if (!patient) {
        return <div>Loading patient data...</div>;
    }

    return (
        <>
            <PageHeader t={t} />
            <div className="animate-fadeInUp animation-delay-100 h-[calc(100vh-200px)]">
                <SharedNotesCard patient={patient} maxHeight="max-h-full" />
            </div>
        </>
    );
};

export default SharedNotes;
