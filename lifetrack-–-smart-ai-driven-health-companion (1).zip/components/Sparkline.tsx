import React from 'react';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';
import type { VitalData } from '../types';

interface SparklineProps {
    data: VitalData[];
    dataKey: keyof Pick<VitalData, 'heartRate' | 'spo2'>;
    strokeColor: string;
    fillColor: string;
}

const Sparkline = ({ data, dataKey, strokeColor, fillColor }: SparklineProps): React.ReactNode => {
    const gradientId = `color-${dataKey}-${Math.random()}`;
    return (
        <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
                <defs>
                    <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={fillColor} stopOpacity={0.4}/>
                        <stop offset="95%" stopColor={fillColor} stopOpacity={0}/>
                    </linearGradient>
                </defs>
                <Area 
                    type="monotone" 
                    dataKey={dataKey} 
                    stroke={strokeColor} 
                    fill={`url(#${gradientId})`} 
                    strokeWidth={2} 
                    dot={false}
                />
            </AreaChart>
        </ResponsiveContainer>
    );
};

export default Sparkline;
