

import React, { useState, useEffect, useRef } from 'react';
import { useAlerts } from '../contexts/AlertsContext';
import { useLanguage } from '../contexts/LanguageContext';

const COUNTDOWN_SECONDS = 30;

const ConfirmationModal = (): React.ReactNode => {
    const { confirmation, confirmSOS, clearConfirmation } = useAlerts();
    const [countdown, setCountdown] = useState(COUNTDOWN_SECONDS);
    const intervalRef = useRef<number | null>(null);
    const { t } = useLanguage();

    useEffect(() => {
        if (confirmation.isOpen) {
            setCountdown(COUNTDOWN_SECONDS);
            intervalRef.current = window.setInterval(() => {
                setCountdown(prev => {
                    if (prev <= 1) {
                        if (intervalRef.current) clearInterval(intervalRef.current);
                        confirmSOS();
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        }

        return () => {
            if (intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [confirmation.isOpen, confirmSOS]);

    if (!confirmation.isOpen) return null;

    const progress = (countdown / COUNTDOWN_SECONDS) * 100;

    return (
        <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-fadeInUp">
            <div className="w-full max-w-lg text-center">
                <div className="relative w-48 h-48 mx-auto mb-8">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                        <circle className="text-slate-700" strokeWidth="8" stroke="currentColor" fill="transparent" r="56" cx="60" cy="60" />
                        <circle 
                            className="text-red-500" 
                            strokeWidth="8" 
                            strokeDasharray="352" 
                            strokeDashoffset={352 - (progress / 100) * 352}
                            strokeLinecap="round" 
                            stroke="currentColor" 
                            fill="transparent" 
                            r="56" cx="60" cy="60" 
                            style={{ transition: 'stroke-dashoffset 1s linear' }}
                        />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center text-5xl font-bold text-white">{countdown}</div>
                </div>

                <h2 className="text-3xl sm:text-4xl font-bold text-white">{t('sos.confirm.title')}</h2>
                <p className="text-lg text-slate-300 mt-2">{confirmation.reason}</p>
                <p className="text-slate-400 mt-4 max-w-md mx-auto">{t('sos.confirm.description')}</p>
                
                <div className="flex flex-col sm:flex-row gap-4 mt-10 justify-center">
                    <button
                        onClick={confirmSOS}
                        className="px-8 py-4 bg-red-600 text-white font-bold rounded-lg text-lg hover:bg-red-700 transition-colors"
                    >
                        {t('sos.confirm.yes')}
                    </button>
                    <button
                        onClick={clearConfirmation}
                        className="px-8 py-4 bg-slate-600 text-white font-bold rounded-lg text-lg hover:bg-slate-700 transition-colors"
                    >
                        {t('sos.confirm.no')}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ConfirmationModal;