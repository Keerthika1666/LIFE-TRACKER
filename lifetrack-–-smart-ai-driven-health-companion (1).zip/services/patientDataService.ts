
import { Patient, Alert, AlertType, RiskLevel, Prescription, Appointment, VoiceNote, SharedNote, User, UserRole } from '../types';
import { mockPatients as initialPatients, mockPrescriptions, mockAppointments } from '../data/mockData';

// This is our in-memory "database" to simulate a backend
let patients: Patient[] = initialPatients;
let prescriptions: Prescription[] = mockPrescriptions;
let appointments: Appointment[] = mockAppointments;


// Simple listener pattern to notify subscribers of changes
type Listener = (patients: Patient[]) => void;
const listeners: Listener[] = [];

const notifyListeners = () => {
  listeners.forEach(listener => listener(patients));
};

export const patientDataService = {
  getPatients: (): Patient[] => {
    return patients;
  },

  getPrescriptions: (): Prescription[] => {
      return prescriptions;
  },
  
  getAppointments: (): Appointment[] => {
      return appointments;
  },

  addPatientAlert: (patientId: string, alertData: { type: AlertType; value: string; threshold: string }) => {
    const newAlert: Alert = {
      ...alertData,
      id: `alert-${Date.now()}`,
      timestamp: new Date(),
      status: 'new',
    };

    patients = patients.map(p => {
      if (p.id === patientId) {
        // When an SOS is triggered, also update the risk level to High
        const newRiskLevel = alertData.type === AlertType.SOS_MANUAL ? RiskLevel.High : p.riskLevel;
        return { ...p, lastAlert: newAlert, riskLevel: newRiskLevel };
      }
      return p;
    });

    notifyListeners();
  },

  acknowledgePatientAlert: (patientId: string) => {
    patients = patients.map(p => {
      if (p.id === patientId && p.lastAlert && p.lastAlert.status === 'new') {
        return { ...p, lastAlert: { ...p.lastAlert, status: 'viewed' as 'viewed' } };
      }
      return p;
    });
    notifyListeners();
  },

  addPatientPrescription: (patientId: string, data: Omit<Prescription, 'id' | 'patientName' | 'dateIssued' | 'status'>) => {
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;
    
    const newPrescription: Prescription = {
        ...data,
        id: `presc-${Date.now()}`,
        patientId,
        patientName: patient.name,
        dateIssued: new Date(),
        status: 'Active',
    };
    prescriptions = [newPrescription, ...prescriptions];
    patients = patients.map(p => p.id === patientId ? { ...p, prescriptions: [newPrescription, ...(p.prescriptions || [])] } : p);
    notifyListeners();
  },

  addPatientAppointment: (patientId: string, data: Omit<Appointment, 'id' | 'patientName' | 'status'>) => {
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    const newAppointment: Appointment = {
        ...data,
        id: `appt-${Date.now()}`,
        patientId,
        patientName: patient.name,
        status: 'Scheduled',
    };
    appointments = [newAppointment, ...appointments];
    patients = patients.map(p => p.id === patientId ? { ...p, appointments: [newAppointment, ...(p.appointments || [])] } : p);
    notifyListeners();
  },

  addPatientVoiceNote: (patientId: string, voiceNote: Omit<VoiceNote, 'id'>) => {
    const newVoiceNote: VoiceNote = {
      ...voiceNote,
      id: `vn-${Date.now()}`,
    };
    patients = patients.map(p => {
      if (p.id === patientId) {
        const updatedNotes = [newVoiceNote, ...(p.voiceNotes || [])];
        return { ...p, voiceNotes: updatedNotes };
      }
      return p;
    });
    notifyListeners();
  },

  addSharedNote: (patientId: string, noteText: string, author: User) => {
    const newNote: SharedNote = {
        id: `sn-${Date.now()}`,
        authorId: author.id,
        authorName: author.name,
        authorRole: author.role,
        timestamp: new Date(),
        text: noteText,
    };
    patients = patients.map(p => {
        if (p.id === patientId) {
            const updatedNotes = [newNote, ...(p.sharedNotes || [])];
            return { ...p, sharedNotes: updatedNotes };
        }
        return p;
    });
    notifyListeners();
  },

  subscribe: (listener: Listener) => {
    listeners.push(listener);
    // Return an unsubscribe function
    return () => {
      const index = listeners.indexOf(listener);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    };
  }
};