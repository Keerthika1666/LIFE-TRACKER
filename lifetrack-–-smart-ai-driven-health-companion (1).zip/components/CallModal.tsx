

import React from 'react';
import type { Contact, Patient } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface CallModalProps {
    person: (Contact | Patient) | null;
    onClose: () => void;
}

const CallModal = ({ person, onClose }: CallModalProps) => {
    const { t } = useLanguage();
    if (!person) return null;

    const relation = 'relation' in person ? person.relation : 'Patient';

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-6 w-full max-w-sm border border-slate-300 dark:border-slate-700 animate-fadeInUp" onClick={(e) => e.stopPropagation()}>
                <div className="flex flex-col items-center text-center">
                    <img src={person.avatarUrl} alt={person.name} className="w-24 h-24 rounded-full object-cover border-4 border-cyan-500 mb-4"/>
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white">{t('family.callModal.title')}</h3>
                    <p className="text-slate-600 dark:text-slate-300 mt-1">{t('family.callModal.connecting', { name: person.name, relation: relation })}</p>
                    <div className="bg-slate-100 dark:bg-slate-700/50 p-3 rounded-md mt-4 text-sm text-slate-500 dark:text-slate-400 w-full">
                        <p>{t('family.callModal.info')}</p>
                    </div>
                    <button onClick={onClose} className="mt-6 w-full px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 transition-colors">
                        {t('family.callModal.endCall')}
                    </button>
                </div>
            </div>
        </div>
    )
}

export default CallModal;