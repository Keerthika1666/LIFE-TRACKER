

import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { ICONS } from '../constants';
import { getVoiceCommandResponse } from '../services/geminiService';
import { useVitalsData } from '../hooks/useVitalsData';

interface VoiceAssistantModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const VoiceAssistantModal = ({ isOpen, onClose }: VoiceAssistantModalProps): React.ReactNode => {
    const { t } = useLanguage();
    const { latestVitals } = useVitalsData();
    const [status, setStatus] = useState<'idle' | 'listening' | 'thinking' | 'responding'>('idle');
    const [response, setResponse] = useState('');

    useEffect(() => {
        if (isOpen) {
            setStatus('listening');
            setResponse('');
        }
    }, [isOpen]);

    if (!isOpen) return null;

    const handleCommand = async (command: string) => {
        setStatus('thinking');
        const aiResponse = await getVoiceCommandResponse(command, latestVitals);
        setResponse(aiResponse);
        setStatus('responding');
    };

    const suggestionPrompts = [
        t('voice.s1'),
        t('voice.s2'),
        t('voice.s3')
    ];

    const ListeningState = () => (
        <div className="text-center">
            <div className="relative w-24 h-24 mx-auto">
                <div className="absolute inset-0 bg-cyan-500/20 rounded-full animate-pulse"></div>
                <div className="absolute inset-2 bg-cyan-500/30 rounded-full animate-pulse [animation-delay:0.5s]"></div>
                <div className="absolute inset-4 bg-cyan-500 rounded-full flex items-center justify-center text-white">
                    {ICONS.voiceAssistant}
                </div>
            </div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-white mt-6">{t('voice.listening')}</h3>
            <p className="text-slate-500 dark:text-slate-400 mt-2">{t('voice.prompt')}</p>
            <div className="mt-6 space-y-2">
                {suggestionPrompts.map(prompt => (
                     <button key={prompt} onClick={() => handleCommand(prompt)} className="w-full p-3 bg-slate-200 dark:bg-slate-700/80 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors text-left">
                        “{prompt}”
                    </button>
                ))}
            </div>
        </div>
    );

    const ThinkingState = () => (
        <div className="text-center">
            <div className="relative w-24 h-24 mx-auto">
                 <div className="absolute inset-0 rounded-full border-2 border-cyan-500/50"></div>
                 <div className="absolute inset-0 rounded-full border-t-2 border-cyan-400 animate-spin"></div>
            </div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-white mt-6">{t('voice.thinking')}</h3>
        </div>
    );
    
    const RespondingState = () => (
        <div className="text-center">
            <div className="text-cyan-500 dark:text-cyan-400 w-16 h-16 mx-auto mb-4">{ICONS.sparkles}</div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-4">{t('voice.responseTitle')}</h3>
            <p className="text-slate-600 dark:text-slate-300 text-lg leading-relaxed">{response}</p>
            <button onClick={() => setStatus('listening')} className="mt-8 px-5 py-2 text-sm font-medium bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors">
                {t('voice.askAnother')}
            </button>
        </div>
    );

    const renderContent = () => {
        switch(status) {
            case 'listening': return <ListeningState />;
            case 'thinking': return <ThinkingState />;
            case 'responding': return <RespondingState />;
            default: return null;
        }
    }


    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-6 w-full max-w-lg border border-slate-300 dark:border-slate-700 animate-fadeInUp" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-end">
                     <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white text-2xl font-bold">&times;</button>
                </div>
                <div className="min-h-[300px] flex items-center justify-center px-4">
                    {renderContent()}
                </div>
            </div>
        </div>
    );
};

export default VoiceAssistantModal;