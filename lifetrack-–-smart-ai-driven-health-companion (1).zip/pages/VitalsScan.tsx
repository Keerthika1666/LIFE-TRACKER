

import React, { useState, useRef, useEffect, useCallback } from 'react';
import Card from '../components/Card';
import { useLanguage } from '../contexts/LanguageContext';

const PageHeader = ({ t }: { t: (key: string) => string }) => (
    <div className="flex items-center justify-between mb-6 animate-fadeInUp">
        <div>
            <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{t('vitalsScan.header')}</h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">{t('vitalsScan.subHeader')}</p>
        </div>
    </div>
);

const HeartRateScanner = ({ t }: { t: (key: string, options?: any) => string }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const graphCanvasRef = useRef<HTMLCanvasElement>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const processingTimeoutRef = useRef<number | null>(null);
    const measurementsRef = useRef<number[]>([]);
    const timestampsRef = useRef<number[]>([]);
    const animationFrameRef = useRef<number | null>(null);

    const [status, setStatus] = useState<'idle' | 'requesting' | 'scanning' | 'error' | 'success'>('idle');
    const [bpm, setBpm] = useState(0);
    const [progress, setProgress] = useState(0);
    const [errorMessage, setErrorMessage] = useState('');
    const [showVideo, setShowVideo] = useState(false);
    const [liveSignalData, setLiveSignalData] = useState<number[]>([]);

    const drawGraph = useCallback(() => {
        if (!graphCanvasRef.current || liveSignalData.length < 2) return;
        const canvas = graphCanvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const width = canvas.width;
        const height = canvas.height;
        
        ctx.clearRect(0, 0, width, height);
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 2;

        const min = Math.min(...liveSignalData);
        const max = Math.max(...liveSignalData);
        const range = max - min < 1 ? 1 : max - min;
        
        ctx.beginPath();
        for (let i = 0; i < liveSignalData.length; i++) {
            const x = (i / (liveSignalData.length - 1)) * width;
            const y = height - ((liveSignalData[i] - min) / range) * height;
            if (i === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        }
        ctx.stroke();
        
        animationFrameRef.current = requestAnimationFrame(drawGraph);
    }, [liveSignalData]);

    useEffect(() => {
        animationFrameRef.current = requestAnimationFrame(drawGraph);
        return () => {
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
        };
    }, [drawGraph]);

    const stopScan = useCallback(() => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        if (processingTimeoutRef.current) {
            clearTimeout(processingTimeoutRef.current);
            processingTimeoutRef.current = null;
        }
        measurementsRef.current = [];
        timestampsRef.current = [];
        setLiveSignalData([]);
        if (videoRef.current) {
            videoRef.current.srcObject = null;
        }
        setShowVideo(false);
    }, []);

    useEffect(() => {
        return () => stopScan();
    }, [stopScan]);
    
    const processHeartRate = useCallback(() => {
        stopScan();
        const measurements = measurementsRef.current;
        const timestamps = timestampsRef.current;
        const MIN_DATA_POINTS = 200; // Need at least ~7s of data at 30fps

        if (measurements.length < MIN_DATA_POINTS) {
            setErrorMessage(t('vitalsScan.hr.errorNotEnoughData'));
            setStatus('error');
            return;
        }

        // 1. Detrend the signal
        const movingAverage = (data: number[], size: number) => {
            const smoothed = [];
            for (let i = 0; i < data.length; i++) {
                const start = Math.max(0, i - Math.floor(size / 2));
                const end = Math.min(data.length, i + Math.ceil(size / 2));
                const subset = data.slice(start, end);
                const avg = subset.reduce((a, b) => a + b) / subset.length;
                smoothed.push(avg);
            }
            return smoothed;
        };

        const trend = movingAverage(measurements, 30); // 1-second window
        const detrended = measurements.map((val, i) => val - trend[i]);

        // 2. Find peaks
        const stdDev = Math.sqrt(detrended.map(x => Math.pow(x, 2)).reduce((a, b) => a + b) / detrended.length);
        const peakThreshold = stdDev * 0.6;
        const minPeakDistance = 10; // at 30fps, this is ~180 BPM max
        
        const peakIndices: number[] = [];
        for (let i = 1; i < detrended.length - 1; i++) {
            if (detrended[i] > peakThreshold && detrended[i] > detrended[i - 1] && detrended[i] > detrended[i + 1]) {
                if (peakIndices.length === 0 || i - peakIndices[peakIndices.length - 1] > minPeakDistance) {
                    peakIndices.push(i);
                }
            }
        }
        
        if (peakIndices.length < 5) { // Need at least 5 peaks for a stable reading
            setErrorMessage(t('vitalsScan.hr.errorUnstable'));
            setStatus('error');
            return;
        }

        // 3. Calculate intervals and validate
        const intervals = [];
        for (let i = 1; i < peakIndices.length; i++) {
            intervals.push(timestamps[peakIndices[i]] - timestamps[peakIndices[i - 1]]);
        }
        const avgInterval = intervals.reduce((a, b) => a + b) / intervals.length;
        const intervalStdDev = Math.sqrt(intervals.map(x => Math.pow(x - avgInterval, 2)).reduce((a, b) => a + b) / intervals.length);

        if ((intervalStdDev / avgInterval) > 0.3) { // If beat-to-beat variation is > 30%, it's too noisy
             setErrorMessage(t('vitalsScan.hr.errorSignalNoisy'));
             setStatus('error');
             return;
        }
        
        const calculatedBpm = 60000 / avgInterval;

        if (calculatedBpm < 40 || calculatedBpm > 200) {
            setErrorMessage(t('vitalsScan.hr.errorUnrealistic', { bpm: Math.round(calculatedBpm) }));
            setStatus('error');
            return;
        }

        setBpm(Math.round(calculatedBpm));
        setStatus('success');
    }, [stopScan, t]);

    const startScan = async () => {
        stopScan();
        setStatus('requesting');
        setErrorMessage('');
        setBpm(0);
        setProgress(0);

        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: 'user',
                    width: { ideal: 640 },
                    height: { ideal: 480 },
                },
            });
            
            streamRef.current = stream;
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                
                videoRef.current.onloadeddata = () => {
                    videoRef.current?.play();
                    setShowVideo(true);
                    setStatus('scanning');
    
                    const TARGET_SAMPLES = 450; // ~15 seconds at 30fps
                    const sampleRate = 30;
                    const MAX_SCAN_TIME = 20000; // 20 seconds timeout
                    const startTime = Date.now();
    
                    const processFrame = () => {
                        if (Date.now() - startTime > MAX_SCAN_TIME || measurementsRef.current.length >= TARGET_SAMPLES) {
                            setProgress(100);
                            processHeartRate();
                            return;
                        }
    
                        if (videoRef.current && canvasRef.current) {
                            const video = videoRef.current;
                            const canvas = canvasRef.current;
                            const context = canvas.getContext('2d', { willReadFrequently: true });
                            
                            if (context && video.readyState >= video.HAVE_METADATA && video.videoWidth > 0) {
                                canvas.width = video.videoWidth;
                                canvas.height = video.videoHeight;
                                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                                
                                const roiWidth = canvas.width / 2;
                                const roiHeight = canvas.height / 2;
                                const sx = (canvas.width - roiWidth) / 2;
                                const sy = (canvas.height - roiHeight) / 4;
                                const imageData = context.getImageData(sx, sy, roiWidth, roiHeight);
        
                                const data = imageData.data;
                                let g = 0;
                                for (let i = 0; i < data.length; i += 4) {
                                    g += data[i + 1];
                                }
                                const avgGreen = g / (data.length / 4);
                                if (isFinite(avgGreen)) {
                                    measurementsRef.current.push(avgGreen);
                                    timestampsRef.current.push(Date.now());
                                    setLiveSignalData(prev => [...prev.slice(-150), avgGreen]);
                                    setProgress((measurementsRef.current.length / TARGET_SAMPLES) * 100);
                                }
                            }
                        }
                        
                        processingTimeoutRef.current = window.setTimeout(processFrame, 1000 / sampleRate);
                    };

                    processFrame();
                };
            }
        } catch (err) {
            console.error('Camera access error:', err);
            let userMessage = t('vitalsScan.hr.errorGeneric');
            if (err instanceof Error) {
                if (err.name === 'NotFoundError') userMessage = t('vitalsScan.hr.errorNotFound');
                else if (err.name === 'NotAllowedError') userMessage = t('vitalsScan.hr.errorNotAllowed');
            }
            setErrorMessage(userMessage);
            setStatus('error');
        }
    };
    
    const isScanning = status === 'scanning' || status === 'requesting';

    const getStatusMessage = () => {
        switch (status) {
            case 'idle': case 'error': return t('vitalsScan.hr.statusIdle');
            case 'requesting': return t('vitalsScan.hr.statusRequesting');
            case 'scanning': return t('vitalsScan.hr.statusScanning');
            case 'success': return t('vitalsScan.hr.statusSuccess');
            default: return '';
        }
    }

    return (
        <div className="text-center flex-grow flex flex-col justify-between">
            <div className="flex-grow">
                <div className="relative w-40 h-40 sm:w-48 sm:h-48 mx-auto my-2 rounded-full overflow-hidden bg-slate-200 dark:bg-slate-900 flex items-center justify-center">
                    <video ref={videoRef} playsInline muted className={`w-full h-full object-cover transition-opacity duration-500 scale-150 ${showVideo ? 'opacity-100' : 'opacity-0'}`} />
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="w-3/4 h-5/6 border-4 border-black/20 dark:border-white/30 rounded-[50%]"></div>
                    </div>
                     {!showVideo && status !== 'success' && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 dark:text-slate-500">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                             <p className="text-xs mt-2">{t('vitalsScan.hr.cameraPreview')}</p>
                        </div>
                     )}
                     {isScanning && (
                         <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
                                <circle className="text-slate-700/50" strokeWidth="5" stroke="currentColor" fill="transparent" r="45" cx="50" cy="50" />
                                <circle className="text-cyan-500" strokeWidth="5" strokeDasharray="283" strokeDashoffset={283 - (progress / 100) * 283} strokeLinecap="round" stroke="currentColor" fill="transparent" r="45" cx="50" cy="50" style={{transition: 'stroke-dashoffset 0.3s ease'}} />
                            </svg>
                            <span className="absolute text-2xl font-bold text-white">{Math.round(progress)}%</span>
                        </div>
                     )}
                </div>
                
                {isScanning && (
                    <div className="h-16 w-full px-4 my-2">
                         <p className="text-xs text-cyan-500 dark:text-cyan-400 mb-1">{t('vitalsScan.hr.liveSignal')}</p>
                         <canvas ref={graphCanvasRef} className="w-full h-12 bg-slate-100 dark:bg-slate-900/50 rounded-md" width="300" height="50"></canvas>
                    </div>
                )}

                <div className="min-h-[60px] flex flex-col justify-center items-center mt-2">
                    {status === 'success' ? (
                        <div className="animate-fadeInUp">
                            <p className="text-slate-500 dark:text-slate-400 text-lg">{t('vitalsScan.hr.estimatedHr')}</p>
                            <p className="text-6xl font-bold text-cyan-500 dark:text-cyan-400 my-1">{bpm}</p>
                            <p className="text-2xl text-slate-600 dark:text-slate-300">{t('overview.units.bpm')}</p>
                        </div>
                    ) : (
                         <p className="text-slate-600 dark:text-slate-300 px-4">{getStatusMessage()}</p>
                    )}
                    {errorMessage && <p className="text-red-500 dark:text-red-400 text-sm mt-2 px-4">{errorMessage}</p>}
                </div>

            </div>
            
            <button
                onClick={isScanning ? stopScan : startScan}
                disabled={status === 'requesting'}
                className={`w-full mt-4 px-4 py-3 text-lg font-bold text-white rounded-md transition-all duration-300 ${isScanning ? 'bg-red-600 hover:bg-red-700' : 'bg-cyan-500 hover:bg-cyan-600'} disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed`}
            >
                {isScanning ? t('vitalsScan.hr.cancel') : (status === 'success' || status === 'error' ? t('vitalsScan.hr.scanAgain') : t('vitalsScan.hr.start'))}
            </button>

            <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
        </div>
    );
};

const LocationTemperature = ({ t }: { t: (key: string, options?: any) => string }) => {
    const [temp, setTemp] = useState<number | null>(null);
    const [city, setCity] = useState('');
    const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
    const [errorMessage, setErrorMessage] = useState('');

    const fetchTemperature = useCallback(() => {
        setStatus('loading');
        setErrorMessage('');
        if (!navigator.geolocation) {
            setErrorMessage(t('vitalsScan.temp.errorGeolocation'));
            setStatus('error');
            return;
        }

        navigator.geolocation.getCurrentPosition(async (position) => {
            const { latitude, longitude } = position.coords;
            const apiUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true`;
            try {
                const response = await fetch(apiUrl);
                if (!response.ok) throw new Error('Failed to fetch weather data.');
                const data = await response.json();
                
                const geoApiUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`;
                const geoResponse = await fetch(geoApiUrl);
                if (!geoResponse.ok) throw new Error('Failed to fetch location data.');
                const geoData = await geoResponse.json();

                setTemp(data.current_weather.temperature);
                setCity(geoData.address.city || geoData.address.town || 'your location');
                setStatus('success');
            } catch (err: any) {
                setErrorMessage(t('vitalsScan.temp.errorFetch'));
                setStatus('error');
            }
        }, () => {
            setErrorMessage(t('vitalsScan.temp.errorPermission'));
            setStatus('error');
        });
    }, [t]);

    useEffect(() => {
        fetchTemperature();
    }, [fetchTemperature]);

    return (
        <div className="text-center flex-grow flex flex-col justify-between">
            <div className="flex-grow flex items-center justify-center">
                {status === 'success' && (
                    <div className="animate-fadeInUp">
                        <p className="text-slate-500 dark:text-slate-400 text-lg">{t('vitalsScan.temp.title')}</p>
                        <p className="text-6xl font-bold text-cyan-500 dark:text-cyan-400 my-2">{temp}°C</p>
                        <p className="text-lg text-slate-600 dark:text-slate-300 capitalize">{t('vitalsScan.temp.inLocation', { city })}</p>
                    </div>
                )}
                {status === 'idle' && (
                    <p className="text-slate-600 dark:text-slate-300 animate-fadeInUp">{t('vitalsScan.temp.prompt')}</p>
                )}
                {status === 'loading' && (
                    <div className="flex flex-col items-center justify-center animate-fadeInUp">
                         <div className="relative h-16 w-16 mb-4">
                            <div className="absolute inset-0 rounded-full border-2 border-cyan-500/50"></div>
                            <div className="absolute inset-0 rounded-full border-t-2 border-cyan-400 animate-spin"></div>
                        </div>
                        <p className="text-slate-500 dark:text-slate-400">{t('vitalsScan.temp.loading')}</p>
                    </div>
                )}
                {status === 'error' && (
                    <p className="text-red-500 dark:text-red-400 text-sm animate-fadeInUp">{errorMessage}</p>
                )}
            </div>

            <button
                onClick={fetchTemperature}
                disabled={status === 'loading'}
                className="w-full mt-6 px-4 py-3 text-lg font-bold text-white bg-cyan-500 rounded-md hover:bg-cyan-600 transition-colors disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed"
            >
                {status === 'success' || status === 'error' ? t('vitalsScan.temp.refresh') : t('vitalsScan.temp.get')}
            </button>
        </div>
    );
}

const VitalsScan = (): React.ReactNode => {
    const { t } = useLanguage();
    return (
        <>
            <PageHeader t={t} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card 
                    title={t('vitalsScan.hr.title')} 
                    description={t('vitalsScan.hr.description')}
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>}
                    animationDelay={100}
                >
                    <HeartRateScanner t={t} />
                </Card>
                <Card 
                    title={t('vitalsScan.temp.title')}
                    description={t('vitalsScan.temp.description')}
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>}
                    animationDelay={200}
                >
                    <LocationTemperature t={t} />
                </Card>
            </div>
        </>
    );
};

export default VitalsScan;