

import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { mockLifestyleData } from '../data/mockData';

const ProgressRing = ({ percentage, color, label, value, goal, unit }: { percentage: number, color: string, label: string, value: number | string, goal: number, unit: string }) => {
    const radius = 50;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (percentage / 100) * circumference;

    return (
        <div className="flex flex-col items-center">
            <div className="relative w-28 h-28">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                    <circle className="text-slate-200 dark:text-slate-700" strokeWidth="10" stroke="currentColor" fill="transparent" r="50" cx="60" cy="60" />
                    <circle 
                        className={color}
                        strokeWidth="10" 
                        strokeDasharray={circumference} 
                        strokeDashoffset={offset}
                        strokeLinecap="round" 
                        stroke="currentColor" 
                        fill="transparent" 
                        r="50" cx="60" cy="60" 
                        style={{ transition: 'stroke-dashoffset 0.5s ease' }}
                    />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-2xl font-bold text-slate-800 dark:text-white">{value}</span>
                    <span className="text-xs text-slate-500 dark:text-slate-400">/ {goal.toLocaleString()}{unit}</span>
                </div>
            </div>
            <p className="mt-2 text-sm font-semibold text-slate-600 dark:text-slate-300">{label}</p>
        </div>
    );
};


const LifestyleCard = (): React.ReactNode => {
    const { t } = useLanguage();
    const data = mockLifestyleData;
    
    const stepsPercentage = (data.steps.current / data.steps.goal) * 100;
    const sleepPercentage = (data.sleep.hours / data.sleep.goal) * 100;
    const caloriesPercentage = (data.calories.current / data.calories.goal) * 100;

    return (
        <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg p-6 shadow-lg h-full">
             <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-4">{t('overview.lifestyle.title')}</h3>
             <div className="grid grid-cols-3 gap-4">
                <ProgressRing 
                    percentage={stepsPercentage} 
                    color="text-cyan-500 dark:text-cyan-400" 
                    label={t('overview.lifestyle.steps')} 
                    value={data.steps.current.toLocaleString()} 
                    goal={data.steps.goal}
                    unit=""
                />
                 <ProgressRing 
                    percentage={sleepPercentage} 
                    color="text-indigo-500 dark:text-indigo-400" 
                    label={t('overview.lifestyle.sleep')} 
                    value={data.sleep.hours} 
                    goal={data.sleep.goal}
                    unit="h"
                />
                 <ProgressRing 
                    percentage={caloriesPercentage} 
                    color="text-rose-500 dark:text-rose-400" 
                    label={t('overview.lifestyle.calories')} 
                    value={data.calories.current.toLocaleString()} 
                    goal={data.calories.goal}
                    unit="kcal"
                />
             </div>
        </div>
    );
};

export default LifestyleCard;