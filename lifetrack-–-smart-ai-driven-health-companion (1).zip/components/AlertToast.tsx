

import React, { useEffect, useState } from 'react';
import { useAlerts } from '../contexts/AlertsContext';
import { ICONS } from '../constants';

const AlertToast = (): React.ReactNode => {
    const { toastQueue, dismissToast } = useAlerts();
    const [visibleToast, setVisibleToast] = useState<any>(null);

    useEffect(() => {
        if (toastQueue.length > 0 && !visibleToast) {
            const nextToast = toastQueue[0];
            setVisibleToast({ ...nextToast, isVisible: true });

            const timer = setTimeout(() => {
                setVisibleToast((current: any) => current ? { ...current, isVisible: false } : null);
                setTimeout(() => {
                    dismissToast(nextToast.id);
                    setVisibleToast(null);
                }, 300); // Animation duration
            }, 5000); // Auto-dismiss after 5 seconds

            return () => clearTimeout(timer);
        }
    }, [toastQueue, visibleToast, dismissToast]);

    if (!visibleToast) {
        return null;
    }
    
    const isSosAlert = visibleToast.message.includes('SOS');
    const toastStyle = isSosAlert 
      ? { border: 'border-red-500', icon: ICONS.alertWarning, iconColor: 'text-red-500 dark:text-red-400', title: 'SOS Alert Triggered' }
      : { border: 'border-cyan-500', icon: ICONS.alertInfo, iconColor: 'text-cyan-500 dark:text-cyan-400', title: 'Notification' };

    return (
        <div 
            className={`fixed top-5 right-5 z-50 w-full max-w-sm p-4 rounded-lg shadow-2xl transition-all duration-300 ease-in-out bg-white dark:bg-slate-800 border-l-4 ${toastStyle.border} ${visibleToast.isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}`}
            role="alert"
        >
            <div className="flex items-center">
                <div className={`flex-shrink-0 ${toastStyle.iconColor}`}>
                    {toastStyle.icon}
                </div>
                <div className="ml-3 text-sm font-medium text-slate-800 dark:text-white">
                    <p className="font-bold">{toastStyle.title}</p>
                    <p className="text-slate-600 dark:text-slate-300">{visibleToast.message}</p>
                </div>
            </div>
        </div>
    );
};

export default AlertToast;