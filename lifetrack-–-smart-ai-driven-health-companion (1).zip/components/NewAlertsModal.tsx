import React from 'react';
import { Patient } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { formatDistanceToNow } from 'date-fns';

interface NewAlertsModalProps {
    isOpen: boolean;
    onClose: () => void;
    alerts: Patient[];
    onSelectPatient: (patient: Patient) => void;
}

const NewAlertsModal = ({ isOpen, onClose, alerts, onSelectPatient }: NewAlertsModalProps) => {
    const { t } = useLanguage();
    if (!isOpen) return null;

    const handlePatientClick = (patient: Patient) => {
        onSelectPatient(patient);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-6 w-full max-w-lg border border-slate-300 dark:border-slate-700 animate-fadeInUp" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white">{t('doctor.stats.newAlerts')}</h3>
                    <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white text-2xl font-bold">&times;</button>
                </div>
                {alerts.length > 0 ? (
                    <div className="space-y-3 max-h-[60vh] overflow-y-auto">
                        {alerts.map(patient => (
                            <div
                                key={patient.id}
                                onClick={() => handlePatientClick(patient)}
                                className="flex items-center space-x-4 p-3 bg-slate-100 dark:bg-slate-700/50 rounded-lg cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                            >
                                <img src={patient.avatarUrl} alt={patient.name} className="w-12 h-12 rounded-full object-cover" />
                                <div className="flex-grow">
                                    <p className="font-bold text-slate-800 dark:text-white">{patient.name}</p>
                                    <p className="text-sm text-yellow-500 dark:text-yellow-400">{patient.lastAlert?.type}</p>
                                </div>
                                <div className="text-right text-xs text-slate-500 dark:text-slate-400">
                                    {patient.lastAlert && formatDistanceToNow(new Date(patient.lastAlert.timestamp), { addSuffix: true })}
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-slate-500 dark:text-slate-400 text-center py-8">{t('doctor.noNewAlerts')}</p>
                )}
            </div>
        </div>
    );
};

export default NewAlertsModal;