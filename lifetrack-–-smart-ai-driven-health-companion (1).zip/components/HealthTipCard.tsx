


import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { getDailyHealthTip } from '../services/geminiService';
import { ICONS } from '../constants';

const HealthTipCard = (): React.ReactNode => {
    const { t } = useLanguage();
    const [tip, setTip] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const fetchTip = async () => {
        setIsLoading(true);
        const result = await getDailyHealthTip();
        setTip(result);
        setIsLoading(false);
    };

    useEffect(() => {
        fetchTip();
    }, []);

    return (
        <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-lg p-6 shadow-lg h-full flex flex-col justify-between">
            <div>
                <div className="flex items-center mb-3">
                    <div className="text-cyan-500 dark:text-cyan-400 mr-3">{ICONS.sparkles}</div>
                    <h3 className="text-lg font-semibold text-slate-800 dark:text-white">{t('overview.healthTip.title')}</h3>
                </div>
                 <div className="min-h-[80px]">
                    {isLoading ? (
                        <div className="flex items-center justify-center h-full">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500 dark:border-cyan-400"></div>
                        </div>
                    ) : tip ? (
                        <p className="text-slate-600 dark:text-slate-300">{tip}</p>
                    ) : (
                        <p className="text-slate-500 dark:text-slate-400">{t('overview.healthTip.prompt')}</p>
                    )}
                </div>
            </div>
            <button
                onClick={fetchTip}
                disabled={isLoading}
                className="w-full mt-4 px-4 py-2 text-sm font-bold text-white bg-cyan-500/90 dark:bg-cyan-500/80 rounded-md hover:bg-cyan-500 transition-colors disabled:bg-slate-400 dark:disabled:bg-slate-600"
            >
                {isLoading ? t('overview.healthTip.loading') : (tip ? t('overview.healthTip.newTip') : t('overview.healthTip.getTip'))}
            </button>
        </div>
    );
};

export default HealthTipCard;